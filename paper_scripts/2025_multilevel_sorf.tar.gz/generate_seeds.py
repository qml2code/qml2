# Make four random seeds corresponding to the 4 k-folds.
import numpy as np

for _ in range(4):
    print(np.random.randint(1, 1048576))
