# K.Karan: I realized in post-processing that the script messed up the calculation for two SMILES
# containing "\" symbol. Didn't think it warranted fixing; the calculations for two SMILES were later done
# automatically anyway during other procedures needed for learning curve building.
import os
import subprocess
import time

from rdkit import Chem

from qml2.dataset_formats.FreeSolv import get_free_solvation_energies


def sum_nuclear_charges(SMILES):
    rdkit_obj = Chem.MolFromSmiles(SMILES)
    current_nuclear_charges = [a.GetAtomicNum() for a in rdkit_obj.GetAtoms()]
    return sum(current_nuclear_charges)


containing_folder = os.environ["DATA"] + "/FreeSolv/FreeSolv-0.51"

all_data = get_free_solvation_energies(containing_folder=containing_folder)

all_SMILES = list(all_data.keys())

all_SMILES.sort(key=lambda x: sum_nuclear_charges(x), reverse=True)

nCPUs = 8

base_command = ["spython", "--OMP_NUM_THREADS=" + str(nCPUs), "--CPUs=" + str(nCPUs)]

workdir = "savefile_data"

os.mkdir(workdir)
os.chdir(workdir)

for i, SMILES in enumerate(all_SMILES):
    for script, prefix in [
        ("generate_savefile.py", "calc"),
        ("generate_savefile_pair.py", "calc_pair"),
    ]:
        time.sleep(1)
        subprocess.run(base_command + ["../" + script, prefix + "_" + str(i), SMILES])
