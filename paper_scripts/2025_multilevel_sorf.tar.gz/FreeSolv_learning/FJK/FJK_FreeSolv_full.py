import json
import os
import random
import sys

import numpy as np

from qml2.basic_utils import now
from qml2.cheminfo.scaffolds import ACYCLIC_POLICIES, scaffold_group_ids
from qml2.data import conversion_coefficient
from qml2.dataset_formats.FreeSolv import get_free_solvation_energies
from qml2.ensemble import Ensemble
from qml2.models.kfolds import frequency_ordered_group_split, group_index_lists
from qml2.models.learning_curves import learning_curve_from_predictions
from qml2.models.loss_functions import MAE, RMSE
from qml2.multilevel_sorf.base_constructors import get_transform_list_dict2datatype
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import ProcessedRepresentationListCalc
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    EnsembleRepresentationCalc,
    MinConformerRepresentationCalc,
    fjk_concatenated_pair_ensemble_list_dict2datatype,
)
from qml2.multilevel_sorf.processed_object_constructors.fjk import (
    FJKRepresentationCalc,
    concatenated_pair_rep_def,
)
from qml2.orb_ml.representations import OML_rep_params
from qml2.parallelization import embarrassingly_parallel

# The min-conformer counterpart of fjk_concatenated_pair_ensemble_list_dict2datatype:
# one representation per molecule rather than a weighted list of conformers, so exactly one
# level shallower. Built here rather than imported because qml2 names only the local_dn_rep
# analogue, and this script has to keep working as the single file spython copies into its
# job directory.
fjk_concatenated_pair_conformers_list_dict2data = get_transform_list_dict2datatype(
    concatenated_pair_rep_def + ["list"]
)


def use_fjk_representation():
    """Whether to fall back to FJK; FJD is the default.

    FJD replaces FJK's exchange slot with two dipole-derived channels. FJK is what the
    paper used, so it stays reachable with --fjk, but it is no longer what you get by
    default. The flag is stripped from sys.argv, so every positional argument below keeps
    the meaning it had.

    Parsed by hand rather than with argparse because spython copies this file, on its own,
    into the job directory and runs it there -- so it has to keep working with no sibling
    modules, and the positional interface the launchers already use has to survive.
    """
    selected = "--fjk" in sys.argv
    if selected:
        sys.argv = [argument for argument in sys.argv if argument != "--fjk"]
    print("REPRESENTATION:", "FJK" if selected else "FJD")
    return selected


def use_min_conformer():
    """Whether to represent each molecule by ONE conformer instead of the whole ensemble.

    The min-conformer counterpart of the ensemble runs, matching what aSLATM, FCHL19 and CM
    already have as separate `min_conformer/` scripts. `Ensemble` sorts its conformers by
    weight, so the one taken is the highest-weighted -- the lowest free energy -- and the
    weighted sum over conformers disappears from the SORF stack along with the level it
    summed over.

    The savefile folder is deliberately NOT renamed. The ab initio results are per conformer
    and identical either way, so a --min_conf run reads the savefiles the ensemble run
    already wrote and costs no new calculation. Giving it its own folder would throw that
    away and recompute every conformer in order to use one of them.

    Stripped from sys.argv like --fjk, so the positional arguments keep their meaning.
    """
    selected = "--min_conf" in sys.argv
    if selected:
        sys.argv = [argument for argument in sys.argv if argument != "--min_conf"]
    print("CONFORMERS:", "minimum-energy only" if selected else "full ensemble")
    return selected


def use_delta_ml_reference():
    """Whether to learn the residual against the calculated solvation energy.

    The Slater pair here is one molecule in two environments -- gas phase and solvent -- so
    the conformer-weighted energy difference between its two determinants IS a calculated
    hydration free energy: GFN2 with ALPB by default, HF with SMD under --fjk. With
    --delta-ml the model is trained on what that calculation misses rather than on the
    experimental value itself.

    Stripped from sys.argv like --fjk, so the positional arguments keep their meaning.
    """
    selected = "--delta-ml" in sys.argv
    if selected:
        sys.argv = [argument for argument in sys.argv if argument != "--delta-ml"]
    print("DELTA-ML REFERENCE:", "calculated solvation energy" if selected else "none")
    return selected


def ensemble_solvation_energy(ensemble):
    """One ensemble's conformer-weighted E(solvated) - E(gas), in kcal/mol.

    kcal/mol because that is the unit of FreeSolv's experimental column, which this is
    subtracted from. The determinants are ordered gas first and solvated second (see
    comp_extra_kwargs below), so the difference already carries the sign convention of a
    hydration free energy and needs no flip.

    Nothing is recalculated: run_calcs() finds every conformer in the savefiles and only
    unpickles them, so the cost is IO. It also means the ensemble passed in must be the one
    built against the learning curve's own savefile folder -- hence taking the ensemble
    rather than rebuilding one from the SMILES.
    """
    ensemble.run_calcs()
    return ensemble.mean_calculated_energy_diff() * conversion_coefficient["au_kcal"]


# The grouping the split is built on. Verified non-degenerate for these seeds by
# scaffolds/scaffold_distribution_*.py: four distinct randomized draws, none of which
# reproduces the deterministic one.
SCAFFOLD_ACYCLIC = "skeleton"
# What --pool-acyclic selects instead: every ring-free molecule in one group. Named here beside
# the default rather than written into the flag handling, because both are qml2's vocabulary and
# not ours -- hence the check below, which turns a renamed or mistyped policy into an error at
# import instead of one raised from inside scaffold_group_ids after the dataset has been read.
# qml2 offers no per-policy constant to use directly, only the tuple of the valid ones.
SCAFFOLD_ACYCLIC_POOLED = "pool"
assert {SCAFFOLD_ACYCLIC, SCAFFOLD_ACYCLIC_POOLED} <= set(ACYCLIC_POLICIES), (
    f"acyclic policies {SCAFFOLD_ACYCLIC!r}/{SCAFFOLD_ACYCLIC_POOLED!r} are not both in qml2's "
    f"ACYCLIC_POLICIES={ACYCLIC_POLICIES}"
)
SCAFFOLD_INCLUDE_CHIRALITY = False
TRAIN_FRACTION = 0.8


def scaffold_split_mode():
    """Replace the learning curve with a single 80/20 scaffold split, or not.

    --fo_scaffold   frequency-ordered split, deterministic: the reference point, comparable
                    with the scaffold-split literature.
    --rfo_scaffold  same frequency ordering, but same-size groups shuffled with the seed, so
                    several seeds give an ensemble with genuine error bars.

    Stripped from sys.argv like --fjk and --delta-ml, so the positional arguments keep their
    meaning.
    """
    flags = ("--fo_scaffold", "--rfo_scaffold")
    selected = [flag for flag in flags if flag in sys.argv]
    assert len(selected) < 2, "pass at most one of " + ", ".join(flags)
    if not selected:
        return None
    sys.argv = [argument for argument in sys.argv if argument not in selected]
    return selected[0].lstrip("-")


def acyclic_policy():
    """How the ring-free molecules are grouped: by skeleton as usual, or all into one pool.

    --pool-acyclic  one group for every molecule that has no ring -- the MoleculeNet/DeepChem
                    convention -- instead of SCAFFOLD_ACYCLIC's grouping by generic carbon
                    skeleton.

    Not cosmetic on FreeSolv: half the dataset (320 of 642) is ring-free, so pooled they are a
    single group larger than any scaffold group, and the frequency-ordered split puts it whole
    into training. The test set is then entirely ring-containing, which separates it further
    from training (ECFP4 median nearest-neighbour similarity 0.25 against 0.35 by skeleton)
    while no longer sampling half of the dataset's chemistry at all. That trade is worth
    measuring, which is why the flag exists, and is why it is not the default.

    Stripped from sys.argv like --fjk and --delta-ml, so the positional arguments keep their
    meaning.
    """
    if "--pool-acyclic" not in sys.argv:
        return SCAFFOLD_ACYCLIC
    sys.argv = [argument for argument in sys.argv if argument != "--pool-acyclic"]
    return SCAFFOLD_ACYCLIC_POOLED


def main():
    scaffold_mode = scaffold_split_mode()
    acyclic = acyclic_policy()
    if acyclic != SCAFFOLD_ACYCLIC:
        if scaffold_mode is None:
            raise SystemExit(
                "--pool-acyclic changes how a SCAFFOLD split is grouped, and this run has no "
                "scaffold split. Pass --fo_scaffold with it, or drop it. An error rather than a "
                "no-op because the run would otherwise be an ordinary learning curve sitting in "
                "a directory whose name claims an acyclic policy."
            )
        if scaffold_mode == "rfo_scaffold":
            raise SystemExit(
                "--pool-acyclic with --rfo_scaffold is degenerate on FreeSolv. Pooled, the "
                "ring-free molecules form one unsplittable group of 320 out of 642, which leaves "
                "the tie shuffling almost nothing to reorder: all four paper seeds return the "
                "SAME split, and it is identical to the one --fo_scaffold gives. Four seeds "
                "would buy four identical runs and an error bar of exactly zero. Use "
                "--fo_scaffold, which is the honest single number for this policy."
            )
    use_fjk = use_fjk_representation()
    delta_ml = use_delta_ml_reference()
    min_conf = use_min_conformer()
    if len(sys.argv) > 1:
        seed = int(sys.argv[1])
    else:
        seed = 274658

    if len(sys.argv) > 2:
        simple_shifts_str = sys.argv[2]
        assert simple_shifts_str in ["True", "False"]
        simple_shifts = simple_shifts_str == "True"
    else:
        simple_shifts = False

    print("SEED:", seed, "SIMPLE SHIFTS:", simple_shifts, "SCAFFOLD SPLIT:", scaffold_mode)
    if scaffold_mode == "fo_scaffold":
        print("NOTE: the seed does not enter a deterministic split; it only names the job.")

    random.seed(seed)

    containing_folder = os.environ["DATA"] + "/FreeSolv/MobleyLab-FreeSolv-9d8a809"

    solvent = "water"
    r_cut = 0.05
    num_conformers = 32

    if use_fjk:
        use_Huckel = True
        # --delta-ml has nothing usable to subtract on this branch: use_Huckel sets
        # mf.max_cycle = -1 (qml2/orb_ml/aux_classes.py), so the stored e_tot is the energy
        # of the Huckel GUESS and not a converged HF one -- 75 kcal/mol above converged for
        # water/6-311G. A difference of two such energies is not a solvation energy: over 16
        # FreeSolv molecules it regresses on experiment with slope 0.04, where the GFN2 pair
        # gives 0.95. Refused rather than warned about, because the damage would otherwise
        # only show up after the learning curve had already been built.
        if delta_ml:
            raise SystemExit(
                "--delta-ml is unavailable under --fjk while use_Huckel is True: the saved "
                "energies are Huckel-guess energies, not converged HF ones, so their "
                "difference is not a solvation energy. Drop --fjk to use the GFN2 pair, or "
                "set use_Huckel = False here and regenerate the savefiles."
            )
        basis = "6-311G"  # "sto-3g"
        method_str = f"FJK_pair_Huckel_{str(use_Huckel)}_basis_{basis}"
        max_angular_momentum = 1
        comp_extra_kwargs_base = {
            "use_Huckel": use_Huckel,
            "basis": basis,
            "localization_procedure": "Boys",
        }
    else:
        # The tight-binding flavour: no basis and no Huckel guess to name, and
        # Pipek-Mezey because IAO/IBO is ill-posed on GFN2's valence-only occupied space.
        method_str = "FJD_pair"
        max_angular_momentum = 2
        comp_extra_kwargs_base = {
            "localization_procedure": "Pipek-Mezey",
            "calc_type": "gfn2-xtb",
            "software": "tblite",
        }

    savefile_folder = (
        containing_folder
        + f"/savefiles_{method_str}_r_cut_{str(r_cut)}_solvent_{solvent}_nconfs_{str(num_conformers)}"
    )
    # Printed so it can be compared against what savefile_creation_fjd/generate_savefiles.py
    # resolves: if the two disagree, every cached calculation is invisible to this script.
    print("SAVEFILE FOLDER:", savefile_folder)

    try:
        os.mkdir(savefile_folder)
    except FileExistsError:
        print("savefile folder already created")

    # Import all data .
    all_data = get_free_solvation_energies(containing_folder=containing_folder)

    all_SMILES = sorted(list(all_data.keys()))
    assert len(all_SMILES) == 642

    # NOTE: the total number of molecules is 642
    training_set_size = 514
    nfeatures = 32768

    if scaffold_mode is None:
        random.shuffle(all_SMILES)
        training_group_ids = None
    else:
        # The deterministic split breaks ties between equal-size groups by smallest member
        # index, so it is only reproducible against a FIXED input order -- shuffling per seed
        # would make "deterministic" name a different split every time. The SMILES therefore
        # stay sorted, and --rfo_scaffold varies only the order WITHIN blocks of equal-size
        # groups, through its own rng.
        group_ids = scaffold_group_ids(
            all_SMILES,
            acyclic=acyclic,
            include_chirality=SCAFFOLD_INCLUDE_CHIRALITY,
        )
        randomized = scaffold_mode == "rfo_scaffold"
        train_indices, test_indices = frequency_ordered_group_split(
            group_ids,
            int(round(TRAIN_FRACTION * len(all_SMILES))),
            shuffle_ties=randomized,
            rng=np.random.default_rng(seed) if randomized else None,
        )
        # Reorder the dataset so the training molecules come first, which lets everything
        # below keep using the plain [:training_set_size] slicing.
        order = list(train_indices) + list(test_indices)
        all_SMILES = [all_SMILES[index] for index in order]
        group_ids = group_ids[order]
        training_set_size = len(train_indices)
        assert not (
            set(group_ids[:training_set_size].tolist())
            & set(group_ids[training_set_size:].tolist())
        ), "a scaffold group straddles the split, so it cannot partition the training set"
        training_group_ids = group_index_lists(group_ids[:training_set_size])
        print(
            f"SCAFFOLD SPLIT: {scaffold_mode}"
            f" train/test={training_set_size}/{len(all_SMILES) - training_set_size}"
            f" groups_in_train={len(training_group_ids)}"
        )

    # For now running without statistical errors
    # The first determinant is the molecule in gas phase and the second the solvated one,
    # so the energy difference has the same sign as the experimental hydration free energy.
    comp_extra_kwargs = {
        **comp_extra_kwargs_base,
        # NOTE: with "software": "tblite" this does NOT select SMD. The keyword is passed to
        # tblite's own ALPB model -- calculator.add("alpb-solvation", solvent) in
        # qml2/orb_ml/tblite_interface -- so what these runs used is ALPB, not SMD. A naming
        # oversight, not an attempt at a solvent model tblite does not have; see README.txt note 1.
        "second_oml_comp_kwargs": {"smd_solvent": solvent},
    }

    ensemble_kwargs = {
        "base_class_name": "OML_Slater_pair",
        "compound_kwargs": comp_extra_kwargs,
        "num_conformers": num_conformers,
        "r_cut": r_cut,
    }

    ensembles = []
    quant_vals = []
    all_nuclear_charges = []

    for SMILES in all_SMILES:
        changed_SMILES = SMILES.replace("/", "_")
        ensemble = Ensemble(
            SMILES=SMILES,
            savefile_prefix=savefile_folder + "/" + changed_SMILES,
            **ensemble_kwargs,
        )
        current_nuclear_charges = ensemble.get_nuclear_charges()

        ensembles.append(ensemble)
        quant_vals.append(all_data[SMILES][0])
        all_nuclear_charges.append(current_nuclear_charges)

    print("Number of usable ensembles:", len(ensembles))

    quant_vals = np.array(quant_vals)

    if delta_ml:
        # Computed over the ensembles rather than read from a file, and in parallel because
        # it means unpickling every savefile.
        print(">>>started delta-ML reference:", now())
        baselines = np.array(embarrassingly_parallel(ensemble_solvation_energy, ensembles, ()))
        print(">>>finished delta-ML reference:", now())
        correlation = np.corrcoef(quant_vals, baselines)[0, 1]
        print(f"delta-ML reference vs experiment: Pearson {correlation:+.4f}")
        # The model learns the residual from here on. This leaves the learning curves
        # directly comparable with the runs that do not use a reference: the baseline is a
        # per-molecule constant, so it cancels between a prediction and its reference and the
        # errors are the same whether they are measured on residuals or on absolutes.
        quant_vals = quant_vals - baselines

    rep_params = OML_rep_params(
        max_angular_momentum=max_angular_momentum, fjd_coup_mats=not use_fjk
    )

    orb_rep_calculator = FJKRepresentationCalc(
        oml_rep_params=rep_params, concatenate_components=True
    )

    if min_conf:
        ensemble_orb_rep_calculator = MinConformerRepresentationCalc(orb_rep_calculator)
    else:
        ensemble_orb_rep_calculator = EnsembleRepresentationCalc(orb_rep_calculator)

    parallel_calculator = ProcessedRepresentationListCalc(ensemble_orb_rep_calculator)

    processed_ensemble_slater_pair_dicts = parallel_calculator(ensembles)

    if min_conf:
        processed_slater_pairs = fjk_concatenated_pair_conformers_list_dict2data(
            processed_ensemble_slater_pair_dicts
        )
    else:
        processed_slater_pairs = fjk_concatenated_pair_ensemble_list_dict2datatype(
            processed_ensemble_slater_pair_dicts
        )

    component_bounds = parallel_calculator.component_bounds

    print(component_bounds)

    max_component_bound = parallel_calculator.max_component_bound()
    print(max_component_bound)

    init_size = nfeatures
    assert init_size >= max_component_bound
    print("SORF init_size", init_size)

    nfeature_stacks = nfeatures // init_size

    print("nfeature_stacks:", nfeature_stacks)

    training_slater_pairs = processed_slater_pairs[:training_set_size]
    training_quantities = quant_vals[:training_set_size]
    training_nuclear_charges = all_nuclear_charges[:training_set_size]

    test_slater_pairs = processed_slater_pairs[training_set_size:]
    test_quantities = quant_vals[training_set_size:]
    test_nuclear_charges = all_nuclear_charges[training_set_size:]

    ntransforms = 3

    function_definition_list = [
        "resize",
        "rescaling",
        "unscaled_sorf",
        "weighted_component_sum",
        "normalization",
        "sorf",
        "weighted_component_sum",
        "concatenation",
    ]

    parameter_list = [
        {"output_size": init_size},
        {"resc_bounds": parallel_calculator.component_bounds},
        {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
        {},
        {},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
        {},
        {"num_components": 2},
    ]

    if not min_conf:
        # The conformer level: a weighted sum over the ensemble's conformers.
        # --min_conf keeps one conformer per molecule, so there is nothing to sum.
        function_definition_list.append("weighted_component_sum")
        parameter_list.append({})

    function_definition_list += [
        "component_sum",
    ]
    parameter_list += [
        {},
    ]

    model = MultilevelSORFModel(
        function_definition_list,
        parameter_list,
        # The quantities are shifted either way now; `simple_shifts` selects HOW the shift
        # is optimized -- fitted directly to the training quantities when True, or against
        # the model's leave-one-out errors when False.
        intensive_quantity_shift=False,
        extensive_quantity_shift=True,
        simple_quantity_shift=simple_shifts,
    )

    training_set_sizes = [50, 100, 200, 400, training_set_size]

    # nperturbations = 4
    # initial_guess_perturbations = (
    #    np.random.random((nperturbations, model.get_nhyperparameters())) - 0.5
    # )
    # initial_guess_perturbations[0, :] = 0.0
    # initial_guess_perturbations = None#
    # smallest_training_set_size = training_set_sizes[0]
    # model.assign_training_set(
    #    training_slater_pairs[:smallest_training_set_size],
    #    training_quantities[:smallest_training_set_size],
    #    training_nuclear_charges=training_nuclear_charges[:smallest_training_set_size],
    #    init_thread_assignments=True,
    # )
    # print(">>>started hyperparameter optimization:", now())
    # model.optimize_hyperparameters(initial_guess_perturbations=initial_guess_perturbations)
    # print(">>>finished hyperparameter optimization:", now())

    if scaffold_mode is not None:
        print(">>>started group-based hyperparameter optimization:", now())
        model.assign_training_set(
            training_slater_pairs,
            training_quantities,
            training_group_ids=training_group_ids,
            training_nuclear_charges=training_nuclear_charges,
        )
        model.optimize_hyperparameters()
        print(">>>finished group-based hyperparameter optimization:", now())
        model.fit(
            training_slater_pairs,
            training_quantities,
            training_nuclear_charges=training_nuclear_charges,
        )
        predictions = model.get_all_predictions(
            test_slater_pairs, all_query_nuclear_charges=test_nuclear_charges
        )
        errors = predictions - test_quantities
        # Names the run inside the file: collating one number per job across modes, seeds and
        # methods is otherwise guesswork about which directory it came from. The seed is
        # recorded even for the deterministic mode, where it does not enter the split, so that
        # every file has the same fields.
        run_description = (
            f"mode={scaffold_mode} seed={seed} simple_shifts={simple_shifts}"
            f" acyclic={acyclic} include_chirality={SCAFFOLD_INCLUDE_CHIRALITY}"
            f" train={training_set_size} test={len(test_quantities)}"
        )
        for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
            value = float(loss(errors))
            print(f"{loss_name}: {value}")
            with open(f"scaffold_split_{loss_name}.txt", "w") as error_file:
                print(f"# {loss_name} {run_description}", file=error_file)
                print(value, file=error_file)

        # Per-molecule predictions AND references, so the split can be re-analysed (per-scaffold
        # errors, the worst offenders, a parity plot) without rerunning the fit and without a
        # second lookup into the dataset. Keyed by SMILES rather than by index because the index
        # only means something relative to this split's ordering, which the scaffold modes
        # permute; the two maps therefore share their keys.
        test_SMILES = all_SMILES[training_set_size:]
        assert len(test_SMILES) == len(predictions)
        assert len(set(test_SMILES)) == len(test_SMILES), "SMILES keys must be unique"
        predictions_file = "scaffold_split_predictions.json"
        with open(predictions_file, "w") as json_file:
            json.dump(
                {
                    "description": run_description,
                    "predictions": {
                        SMILES: float(value) for SMILES, value in zip(test_SMILES, predictions)
                    },
                    "references": {
                        SMILES: float(value) for SMILES, value in zip(test_SMILES, test_quantities)
                    },
                },
                json_file,
                indent=2,
                sort_keys=True,
            )
        print(f"PREDICTIONS: {predictions_file} ({len(test_SMILES)} molecules)")
        return

    print(">>>started learning curve building:", now())
    all_predictions = model.learning_curve_predictions(
        training_slater_pairs,
        training_quantities,
        test_slater_pairs,
        training_set_sizes,
        max_subset_num=1,
        training_nuclear_charges=training_nuclear_charges,
        test_nuclear_charges=test_nuclear_charges,
        init_thread_assignments=True,
        hyperparameter_reoptimization=True,
        rng=random,
    )
    print(">>>finished learning curve building:", now())
    for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
        mean_MAEs, _ = learning_curve_from_predictions(
            all_predictions, test_quantities, error_loss_function=loss
        )
        with open(f"learning_curve_{loss_name}.txt", "w") as f:
            for ntr, mean_MAE_val in zip(training_set_sizes, mean_MAEs):
                print(ntr, mean_MAE_val, file=f)


if __name__ == "__main__":
    main()
