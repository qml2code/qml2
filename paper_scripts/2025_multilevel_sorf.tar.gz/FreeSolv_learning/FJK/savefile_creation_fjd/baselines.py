"""Physical and trivial baselines for this dataset, on the SAME splits the ML scripts use.

    python baselines.py                     # all CSVs into the current directory
    python baselines.py --out-dir DIR       # write them into DIR instead
    python baselines.py --quiet             # only the PARAMETERS:/SUMMARY: blocks

What this answers: every learning curve and every scaffold MAE in the manuscript needs a floor to
be read against -- how much of the accuracy is the representation, and how much was already in the
composition or in the GFN2-xTB number the delta-ML starts from. The baselines here are fit on the
training split and evaluated on the test split, so they drop straight into the same tables as the
ML rows.

COMPUTES NO CHEMISTRY. The xTB quantity is read from `FJD_pair_baseline.json` beside this file,
which `generate_savefiles.py pair` wrote (and `print_baseline_table.py` regenerates from finished
savefiles). That file is not an approximation of what the ML uses -- it is bit-for-bit the number
`--delta-ml` subtracts, which is why nothing is recomputed here: with this dataset's dml runs,
`max|delta_ml_reference - predicted_value| == 0`. Everything below is closed-form least squares, so
this is safe on a login node and takes seconds.

THE SPLITS ARE THE ML's SPLITS, replayed rather than stored. The learning scripts keep no index
arrays, but they do seed one global RNG and consume it in a known order, and the seeds are
synchronized across every run, so the partitions are reproducible exactly:

    random.seed(seed)                       # the only seeding, at the top of main()
    all_SMILES = sorted(all_data.keys())    # the canonical order; the dataset is the authority
    random.shuffle(all_SMILES)              # random split; train = the first `train_size`

and for a scaffold split the SMILES stay sorted while
`frequency_ordered_group_split(group_ids, train_size, shuffle_ties=..., rng=...)` does the work,
drawing from its own `np.random.default_rng(seed)` when ties are shuffled and from nothing at all
when they are not. qml2 never imports Python's `random`, and the learning scripts touch it in
exactly three places, so no hidden draw can slide between those calls and desynchronize this replay.
It is checked, not assumed: `assert_splits_match_the_ml_runs()` compares every regenerated test
block against the per-molecule JSONs the ML runs left behind, and refuses to write anything if one
disagrees.

The learning-curve points are replayed the same way, from the one place that draws them
(`MultilevelSORFModel.learning_curve_predictions` with `max_subset_num=1`): the training index list
is shuffled in place once per training set size -- cumulatively, each shuffle starting from the
previous permutation -- and the first `size` entries are that point's training set. A baseline that
instead took `[:size]` of the unshuffled block would be fit on different molecules than the ML row
it is printed next to.

Outputs (units are in a header comment in each file; every row carries `dataset`, so the LES and
FreeSolv copies concatenate):

    baselines_errors.csv            one row per (baseline, split_type, train_size, seed)
    baselines_summary.csv           the same with seeds collapsed to mean +- std: the table-ready form
    coeffs.csv                      fitted per-element and xTB coefficients, for the record
    per_molecule_quantities.csv     label, xTB proxy and atom counts per molecule
    baseline_predictions.csv        per-molecule predictions, in-sample and held-out
"""

import csv
import json
import os
import random
import sys
from collections import Counter

# Everything dataset-specific comes from the sibling module -- the subdirectory under $DATA, the
# quantity loader, the unit and the description of both. Importing it is what keeps this file
# identical in the LES and FreeSolv copies, exactly as it does for print_baseline_table.py.
import generate_savefiles as gs
import numpy as np

from qml2.cheminfo.scaffolds import ACYCLIC_POLICIES, scaffold_group_ids
from qml2.models.kfolds import frequency_ordered_group_split

# ----------------------------------------------------------------------------------------------
# These MUST agree with the learning scripts; they are the split, not a preference. The seeds are
# the synchronized set used by every run of every representation, which is what makes one baseline
# row comparable to all of them.
SEEDS = (274658, 20786, 109790, 478390)
TRAIN_FRACTION = 0.8
SCAFFOLD_ACYCLIC = "skeleton"
# The policy the acyclic_pool runs use instead: every ring-free molecule in ONE group, which is the
# MoleculeNet/DeepChem convention. It is a separate split rather than a variant of the same one --
# the frequency-ordered split puts that whole group in training, so the test set contains no
# ring-free molecule at all, and on FreeSolv that is half the dataset. A baseline computed under
# the by-skeleton grouping is therefore NOT a valid floor for a pooled run, which is why this
# exists. Both names are qml2's vocabulary, hence the check.
SCAFFOLD_ACYCLIC_POOLED = "pool"
assert {SCAFFOLD_ACYCLIC, SCAFFOLD_ACYCLIC_POOLED} <= set(ACYCLIC_POLICIES), (
    f"acyclic policies {SCAFFOLD_ACYCLIC!r}/{SCAFFOLD_ACYCLIC_POOLED!r} are not both in qml2's "
    f"ACYCLIC_POLICIES={ACYCLIC_POLICIES}"
)
SCAFFOLD_INCLUDE_CHIRALITY = False
# The learning curve's smaller points; the largest is the full training block, appended below.
LEARNING_CURVE_SIZES = [50, 100, 200, 400]
# Every split the ML pipeline runs. `freq_deterministic_pool` is the same frequency-ordered split
# under SCAFFOLD_ACYCLIC_POOLED; there is deliberately no pooled randomized-tie entry, since that
# combination is degenerate and the learning scripts refuse it.
SPLIT_TYPES = ("random", "freq_random_tie", "freq_deterministic", "freq_deterministic_pool")
# ----------------------------------------------------------------------------------------------

BASELINE_JSON = "FJD_pair_baseline.json"

# A tiny ridge on every fit, scaled to the design matrix rather than absolute. It is not there to
# regularize: it is there so a fit stays defined when a column is degenerate, which happens for
# real here -- LES has exactly one germanium atom in the whole dataset, so most training splits
# contain no Ge at all and the dressed-atom matrix loses that column's rank. The alternative,
# dropping the column, leaves no coefficient for a test molecule that does contain it.
RIDGE_SCALE = 1e-8

# Which baselines this dataset's table leads with. The rest are still computed and written -- they
# cost nothing and answer the obvious follow-up -- but are marked secondary, because the asymmetry
# is physical: FreeSolv's hydration free energy is extensive, so its baselines are composition
# terms plus an extensive xTB term and NO intercept; LES's oxidation potential is intensive and
# referenced to SCE, so its baseline is an intercept (the reference-electrode offset) plus a slope
# on the IP, and a dressed-atom sum would wrongly grow with molecule size.
DATASET_PROFILES = {
    "literature_electrochemical_stability": {
        "proxy_symbol": "IP_xTB",
        "proxy_name": "ip",
        # An oxidation potential is INTENSIVE: it does not grow when the molecule does. A
        # dressed-atom sum therefore cannot represent it even in principle -- two copies of a
        # molecule would be predicted to oxidize at twice the potential -- so those baselines are
        # not computed here rather than computed and quietly ignored.
        "quantity_nature": "intensive",
        "primary": ("mean", "xtb_ip_linear", "xtb_ip_linear_dml"),
    },
    "FreeSolv/MobleyLab-FreeSolv-9d8a809": {
        "proxy_symbol": "dGsolv_xTB",
        "proxy_name": "dgsolv",
        # A hydration free energy is EXTENSIVE, which is what makes the dressed-atom form the
        # right one here and an intercept the wrong one: a constant term is size-independent, so
        # the prediction for two non-interacting fragments would not be the sum of theirs.
        "quantity_nature": "extensive",
        "primary": ("mean", "dressed_atom", "dressed_atom_plus_xtb", "dressed_atom_plus_xtb_dml"),
    },
}


def dataset_profile():
    """The dataset this copy of the script sits next to, identified by the sibling module."""
    try:
        return DATASET_PROFILES[gs.DATASET_SUBDIR]
    except KeyError:
        raise SystemExit(
            f"no baseline profile for dataset {gs.DATASET_SUBDIR!r}.\n"
            "Add one to DATASET_PROFILES: the proxy's symbol, a short name for the column, and "
            "which baselines that dataset's table leads with."
        )


def applicable_specs(proxy_name, quantity_nature):
    """`(kept, skipped)` -- the baselines whose functional form suits this dataset's quantity.

    The split is not a preference about which numbers are interesting, it is about which models
    are expressible. A dressed-atom sum is extensive by construction and an intercept-plus-slope
    is intensive by construction, so each is meaningless on the other kind of target: running them
    anyway produces a row that looks like a baseline, carries a number nobody should quote, and
    invites exactly the comparison it fails. `mean` and the uncalibrated proxy survive everywhere
    because neither fits a functional form at all -- one is a constant and the other is the xTB
    quantity as it stands, which already has the target's own nature.
    """
    kept, skipped = [], []
    for name, spec in baseline_specs(proxy_name):
        requires = spec.get("requires")
        (kept if requires in (None, quantity_nature) else skipped).append((name, spec))
    return kept, skipped


def baseline_specs(proxy_name):
    """Every baseline, as (name, how to build its design matrix).

    `counts` adds one column per element, `proxy` the xTB quantity as a FITTED column, `intercept`
    a constant column. `mean` and the uncalibrated proxy are not fits at all and carry no design
    matrix.

    `offset` is the delta-ML shape, and it is not the same thing as `proxy`: the fit is done on the
    residual `label - proxy` and the proxy is added back at prediction time, so it enters the model
    at a coefficient of exactly 1 instead of one chosen by least squares. That is what `--delta-ml`
    does -- it subtracts the xTB reference outright and learns what is left -- so these are the
    floors the delta-ML rows must be read against. The free-slope variants are a strictly larger
    model class (they can always fall back to a slope of 1), which makes them the wrong comparison
    for a delta-ML row and the right one for a plain row.
    """
    return [
        # The trivial floor: the training mean, which any model must beat to have learned anything.
        # No functional form to be wrong about: a constant, for either kind of quantity.
        ("mean", {"kind": "mean"}),
        # Composition alone -- the dressed-atom quantity shift used by itself, with no ML on top.
        (
            "dressed_atom",
            {
                "kind": "fit",
                "counts": True,
                "proxy": False,
                "intercept": False,
                "requires": "extensive",
            },
        ),
        # The physical floor for an intensive target: the intercept is the reference-electrode
        # offset and is required. Not computed for an extensive one, where a constant term would
        # break additivity -- see applicable_specs.
        (
            f"xtb_{proxy_name}_linear",
            {
                "kind": "fit",
                "counts": False,
                "proxy": True,
                "intercept": True,
                "requires": "intensive",
            },
        ),
        # Composition plus the xTB number, all extensive, no intercept. The gain over
        # `dressed_atom` is exactly what the xTB calculation adds at the linear level.
        (
            "dressed_atom_plus_xtb",
            {
                "kind": "fit",
                "counts": True,
                "proxy": True,
                "intercept": False,
                "requires": "extensive",
            },
        ),
        # The proxy with no calibration whatsoever. Honest to report, misleading to promote: an
        # uncalibrated continuum model looks bad for a reason that is not about the chemistry.
        # Also formless -- the proxy exactly as it comes, so it inherits the target's nature.
        (f"xtb_{proxy_name}_raw", {"kind": "raw"}),
        # The delta-ML floors: the proxy at unit weight plus the shift that delta-ML's own
        # quantity shift would fit, and nothing else. `simple_shifts` corresponds to the constant
        # below, the dressed-atom shift to the per-element version.
        (
            f"xtb_{proxy_name}_linear_dml",
            {
                "kind": "fit",
                "counts": False,
                "proxy": False,
                "intercept": True,
                "offset": True,
                "requires": "intensive",
            },
        ),
        (
            "dressed_atom_plus_xtb_dml",
            {
                "kind": "fit",
                "counts": True,
                "proxy": False,
                "intercept": False,
                "offset": True,
                "requires": "extensive",
            },
        ),
    ]


# ==============================================================================================
# The splits, replayed exactly as the learning scripts make them.
# ==============================================================================================


def train_size_for(nmolecules):
    """The learning scripts' `training_set_size`: 474 of 592 for LES, 514 of 642 for FreeSolv."""
    return int(round(TRAIN_FRACTION * nmolecules))


def ordered_split(sorted_SMILES, mode, seed):
    """`(ordered_SMILES, train_size)` for one split, with training molecules first.

    This is the learning scripts' own sequence, in their order, including the seeding -- see the
    module docstring. The returned list is the dataset reordered so that `[:train_size]` is the
    training block and `[train_size:]` the test block, which is how every script downstream of the
    split slices it.
    """
    smiles = list(sorted_SMILES)
    # Seeded here and not by the caller, because WHERE this happens is part of the contract: the
    # learning scripts seed once, before touching the data, and every later draw inherits it.
    random.seed(seed)
    if mode == "random":
        random.shuffle(smiles)
        return smiles, train_size_for(len(smiles))

    # The grouping policy is part of the split's identity, not a separate knob: only the
    # deterministic mode has a pooled counterpart, because pooling leaves the tie shuffling nothing
    # to reorder (every seed returns the same split) and the learning scripts refuse that
    # combination outright.
    acyclic = SCAFFOLD_ACYCLIC_POOLED if mode.endswith("_pool") else SCAFFOLD_ACYCLIC
    group_ids = scaffold_group_ids(
        smiles, acyclic=acyclic, include_chirality=SCAFFOLD_INCLUDE_CHIRALITY
    )
    randomized = mode == "freq_random_tie"
    train_indices, test_indices = frequency_ordered_group_split(
        group_ids,
        train_size_for(len(smiles)),
        shuffle_ties=randomized,
        # The tie shuffling draws from its own generator, not the global one, so the deterministic
        # mode is reproducible against the FIXED sorted order and the randomized mode varies only
        # within blocks of equal-size groups.
        rng=np.random.default_rng(seed) if randomized else None,
    )
    order = list(train_indices) + list(test_indices)
    return [smiles[index] for index in order], len(train_indices)


def learning_curve_subsets(train_size, sizes):
    """Training subsets per learning-curve point, as `learning_curve_predictions` draws them.

    Must be called immediately after `ordered_split(..., "random", seed)` and before anything else
    consumes the global RNG, because it continues that same stream. The shuffles are cumulative --
    the list is permuted in place once per size, each time from the previous permutation -- and
    `max_subset_num=1` in the learning scripts means the point's training set is simply the first
    `size` entries of the permutation standing at that moment.
    """
    indices = list(range(train_size))
    subsets = []
    for size in sizes:
        random.shuffle(indices)
        assert size <= train_size, f"curve point {size} exceeds the training block {train_size}"
        subsets.append(list(indices[:size]))
    return subsets


def assert_splits_match_the_ml_runs(sorted_SMILES, learning_root, quiet=False):
    """Check the replay against the per-molecule JSONs the ML runs left, and say how many agreed.

    The point of this function is that nothing else here is trustworthy without it. A split that is
    off by one molecule still produces plausible MAEs, and the error would be invisible in the
    output; so every ML run that recorded which molecules it tested is compared against, and a
    single disagreement is fatal. Runs are matched by the seed in their directory name, with the
    seedless directories being the deterministic scaffold split.
    """
    import glob

    checked = Counter()
    # Which seeds were actually compared against a run, as opposed to merely listed in SEEDS. A
    # seed matches runs by the suffix of their directory name, so a seed that is simply wrong
    # matches nothing and would otherwise be skipped in silence -- leaving the baselines fit on a
    # split no ML row ever used, which is the failure this whole function exists to prevent.
    seeds_compared = set()
    # The globs are per mode rather than one shape for all, because the pooled runs sit at a
    # different depth: they live directly under acyclic_pool/, with the policy in the job name
    # instead of in a directory level of their own.
    for mode, patterns, filename, key in (
        ("random", ("*/data_*", "*/*/data_*"), "test_predictions.json", "molecules"),
        (
            "freq_random_tie",
            ("*/*rfo_scaffold*/data_*", "*/*/*rfo_scaffold*/data_*"),
            "scaffold_split_predictions.json",
            "predictions",
        ),
        (
            "freq_deterministic",
            ("*/*fo_scaffold*/data_*", "*/*/*fo_scaffold*/data_*"),
            "scaffold_split_predictions.json",
            "predictions",
        ),
        (
            "freq_deterministic_pool",
            ("acyclic_pool/data_*",),
            "scaffold_split_predictions.json",
            "predictions",
        ),
    ):
        matched = []
        for pattern in patterns:
            matched.extend(glob.glob(f"{learning_root}/{pattern}/{filename}"))
        for path in matched:
            directory = os.path.basename(os.path.dirname(path))
            seeds_in_name = [seed for seed in SEEDS if directory.endswith(f"_{seed}")]
            if mode.startswith("freq_deterministic"):
                if seeds_in_name or "rfo_scaffold" in path:
                    continue  # a seeded run, or the randomized mode caught by this glob
                # The pooled runs carry acyclic_pool in their name; the by-skeleton deterministic
                # mode must not claim them, or it would compare its own split against theirs.
                if ("acyclic_pool" in path) != (mode == "freq_deterministic_pool"):
                    continue
                seed = SEEDS[0]  # names the job only; it does not enter a deterministic split
            else:
                if not seeds_in_name:
                    continue
                if mode == "random" and ("scaffold" in path or "scaffold" in directory):
                    continue
                seed = seeds_in_name[0]
            with open(path) as handle:
                recorded = list(json.load(handle)[key])
            ordered, train_size = ordered_split(sorted_SMILES, mode, seed)
            if recorded != ordered[train_size:]:
                raise SystemExit(
                    f"REPLAYED SPLIT DOES NOT MATCH THE ML RUN at {path}\n"
                    f"  mode={mode} seed={seed}: {len(recorded)} molecules recorded, "
                    f"{len(ordered) - train_size} replayed, "
                    f"{len(set(recorded) ^ set(ordered[train_size:]))} differing\n"
                    "Nothing was written. Either the learning scripts' split changed or qml2's "
                    "splitter did; until they agree these baselines are not on the ML's splits."
                )
            checked[mode] += 1
            if not mode.startswith("freq_deterministic"):
                # The deterministic split does not consume its seed, so a run of it says nothing
                # about whether that seed is the one the ML used.
                seeds_compared.add(seed)

    unchecked = [seed for seed in SEEDS if seed not in seeds_compared]
    if unchecked and seeds_compared:
        raise SystemExit(
            f"these seeds match no ML run here: {unchecked}\n"
            f"  (compared successfully against {sorted(seeds_compared)})\n"
            "A seed that matches nothing is never checked, so the baselines would be fit on a "
            "split no ML row used. Either SEEDS disagrees with the runs on disk, or those runs "
            "have not been done yet. Nothing was written."
        )
    if not quiet:
        print("SPLIT REPLAY checked against the ML runs on disk:")
        for mode in SPLIT_TYPES:
            if checked[mode]:
                print(
                    f"  {mode:20s}: {checked[mode]:4d} runs, every test block identical in order"
                )
            else:
                # Not the same thing as agreement, and the distinction matters most exactly here:
                # a dataset whose learning-curve runs predate the per-molecule JSON has nothing to
                # compare against for the very split its curves are drawn on. The replay is still
                # the same code path with the same constants -- which IS verified wherever those
                # runs exist -- but on this dataset that is an argument, not a measurement.
                print(
                    f"  {mode:20s}:    0 runs recorded their test molecules here --"
                    " NOT verified on this dataset"
                )
    return checked


# ==============================================================================================
# The data: the experimental label, the xTB proxy, and the atom counts.
# ==============================================================================================


def atom_counts(all_SMILES):
    """`(counts, elements)`: the atom-count matrix and its column elements, hydrogens included.

    From the SMILES rather than from the stored conformers, which is both cheaper and exactly
    reproducible: the ML's geometries are generated from these same SMILES, so their composition
    is the same, and reading 1200 pickles to recount it would make this script depend on the
    savefiles being on whichever machine it runs.
    """
    from rdkit import Chem, RDLogger

    RDLogger.DisableLog("rdApp.*")
    per_molecule = []
    for SMILES in all_SMILES:
        molecule = Chem.MolFromSmiles(SMILES)
        if molecule is None:
            raise SystemExit(f"RDKit cannot parse {SMILES!r}, so its atom counts are unknown")
        per_molecule.append(Counter(atom.GetSymbol() for atom in Chem.AddHs(molecule).GetAtoms()))
    elements = sorted({element for counts in per_molecule for element in counts})
    matrix = np.array(
        [[counts.get(element, 0) for element in elements] for counts in per_molecule], dtype=float
    )
    return matrix, elements


def load_quantities(containing_folder, json_path):
    """`(all_SMILES, labels, proxy, excluded)` -- the dataset in its canonical order.

    The dataset is the authority on which molecules exist and in what order, because that order is
    what the splits are built on; the JSON only supplies the xTB number. A molecule the JSON does
    not cover is reported and excluded from every fit and every metric, but is NOT removed before
    the split: the ML split it in, so dropping it earlier would shift every molecule after it into
    a different block and quietly change the partition.
    """
    all_data = gs.load_dataset(containing_folder)
    all_SMILES = sorted(all_data.keys())
    with open(json_path) as handle:
        baseline = json.load(handle)

    labels = np.array([float(np.atleast_1d(all_data[SMILES])[0]) for SMILES in all_SMILES])
    proxy = np.full(len(all_SMILES), np.nan)
    excluded = []
    for index, SMILES in enumerate(all_SMILES):
        entry = baseline.get(SMILES)
        if entry is None or entry.get("predicted_value") is None:
            excluded.append(SMILES)
            continue
        proxy[index] = float(entry["predicted_value"])
        # The JSON carries the label too; if the two disagree, one of them is from another version
        # of the dataset and every number downstream is suspect.
        recorded = entry.get("experimental_value")
        if recorded is not None and not np.isclose(recorded, labels[index], atol=1e-8, rtol=0):
            raise SystemExit(
                f"{SMILES}: label {labels[index]} from the dataset but {recorded} in "
                f"{os.path.basename(json_path)} -- they must be the same quantity"
            )
    if not np.isfinite(labels).all():
        raise SystemExit("the dataset has a non-finite experimental value")
    return all_SMILES, labels, proxy, excluded


# ==============================================================================================
# The fits. Closed-form least squares, with a ridge that only ever rescues a degenerate column.
# ==============================================================================================


def design_matrix(spec, counts, proxy, elements, proxy_symbol):
    """`(X, terms)` for one baseline, or `(None, [])` when it is not a fit."""
    columns, terms = [], []
    if spec.get("intercept"):
        columns.append(np.ones(len(proxy)))
        terms.append("intercept")
    if spec.get("counts"):
        columns.extend(counts[:, index] for index in range(counts.shape[1]))
        terms.extend(elements)
    if spec.get("proxy"):
        columns.append(proxy)
        terms.append(proxy_symbol)
    return np.column_stack(columns), terms


def fit_ridged(X, y):
    """`(coefficients, degenerate_terms)` by least squares with the §5 ridge.

    The ridge is applied always and is scaled to the matrix, so for a well-conditioned fit it is
    numerically irrelevant (1e-8 of the mean diagonal) and for a rank-deficient one it is the
    reason a coefficient exists at all. Which columns were degenerate is returned so the caller can
    record it rather than discover it in a plot.
    """
    gram = X.T @ X
    ncol = X.shape[1]
    ridge = RIDGE_SCALE * np.trace(gram) / ncol
    degenerate = [index for index in range(ncol) if not np.any(X[:, index])]
    if np.linalg.matrix_rank(gram) < ncol:
        degenerate.append("rank")
    coefficients = np.linalg.solve(gram + ridge * np.eye(ncol), X.T @ y)
    if not np.isfinite(coefficients).all():
        raise SystemExit("a baseline fit produced a non-finite coefficient")
    return coefficients, degenerate


def predict(name, spec, train, test, data):
    """`(predictions_on_test, terms, coefficients, degenerate)` for one baseline on one split."""
    labels, counts, proxy, elements, proxy_symbol = data
    if spec["kind"] == "mean":
        return np.full(len(test), labels[train].mean()), [], [], []
    if spec["kind"] == "raw":
        return proxy[test].copy(), [], [], []
    X, terms = design_matrix(spec, counts, proxy, elements, proxy_symbol)
    # The delta-ML shape: fit what is left after subtracting the proxy, then put it back. Doing it
    # this way rather than as a column is the whole point -- the coefficient on the proxy stays 1.
    target = labels - proxy if spec.get("offset") else labels
    coefficients, degenerate = fit_ridged(X[train], target[train])
    degenerate_terms = [terms[index] if isinstance(index, int) else index for index in degenerate]
    predictions = X[test] @ coefficients
    if spec.get("offset"):
        predictions = predictions + proxy[test]
    return predictions, terms, coefficients, degenerate_terms


def errors(predictions, references):
    """MAE and RMSE, loudly rather than as a silent NaN."""
    residuals = predictions - references
    if not np.isfinite(residuals).all():
        raise SystemExit(
            "a baseline produced a non-finite prediction; refusing to report an error"
        )
    return float(np.abs(residuals).mean()), float(np.sqrt((residuals**2).mean()))


# ==============================================================================================
# Driving it, and writing the files.
# ==============================================================================================


def run_all_splits(all_SMILES, data, specs, curve_sizes, keep):
    """Every (baseline, split_type, train_size, seed) combination. Returns error and coeff rows.

    The random split carries the whole learning curve, because that is the split the curves are
    built on; the two scaffold splits are evaluated at their full training block only, which is
    all the ML runs there do.
    """
    position = {SMILES: index for index, SMILES in enumerate(all_SMILES)}
    error_rows, coeff_rows = [], []

    for split_type in SPLIT_TYPES:
        # A deterministic split has no seed: the learning scripts still pass one to name the job,
        # but it does not enter the partition, so running it four times would print one number
        # four times and invent an error bar for it.
        seeds = (SEEDS[0],) if split_type.startswith("freq_deterministic") else SEEDS
        for seed in seeds:
            ordered, train_size = ordered_split(all_SMILES, split_type, seed)
            block = np.array([position[SMILES] for SMILES in ordered])
            train_block, test_block = block[:train_size], block[train_size:]
            if split_type == "random":
                # Drawn here, in the same breath as the split, because it continues the same RNG
                # stream -- see learning_curve_subsets.
                sizes = curve_sizes + [train_size]
                subsets = learning_curve_subsets(train_size, sizes)
            else:
                sizes, subsets = [train_size], [list(range(train_size))]

            test = test_block[keep[test_block]]
            for size, subset in zip(sizes, subsets):
                train = train_block[subset]
                train = train[keep[train]]
                for name, spec in specs:
                    predictions, terms, coefficients, degenerate = predict(
                        name, spec, train, test, data
                    )
                    mae, rmse = errors(predictions, data[0][test])
                    fit_a = fit_b = ""
                    if spec.get("intercept") and not spec.get("counts"):
                        if spec.get("offset"):
                            # One fitted parameter, the shift; the slope is 1 by construction and
                            # is recorded as such rather than left blank, so the model in this row
                            # is fully readable from the row.
                            fit_a, fit_b = float(coefficients[0]), 1.0
                        else:
                            # Intercept and the slope on the proxy, both fitted.
                            fit_a, fit_b = float(coefficients[0]), float(coefficients[1])
                    error_rows.append(
                        {
                            "dataset": gs.DATASET_SUBDIR,
                            "baseline": name,
                            "split_type": split_type,
                            "train_size": size,
                            "seed": "deterministic"
                            if split_type.startswith("freq_deterministic")
                            else seed,
                            "mae": mae,
                            "rmse": rmse,
                            "fit_a": fit_a,
                            "fit_b": fit_b,
                            "ridge_triggered": ";".join(str(term) for term in degenerate),
                            "n_test": len(test),
                            "n_train_effective": len(train),
                        }
                    )
                    fitted = list(zip(terms, coefficients))
                    if spec.get("offset"):
                        # Named as fixed, because coeffs.csv otherwise reads as a list of things
                        # least squares chose, and this one it did not.
                        fitted.append((f"{data[4]}(fixed)", 1.0))
                    for term, value in fitted:
                        coeff_rows.append(
                            {
                                "dataset": gs.DATASET_SUBDIR,
                                "baseline": name,
                                "split_type": split_type,
                                "train_size": size,
                                "seed": (
                                    "deterministic"
                                    if split_type.startswith("freq_deterministic")
                                    else seed
                                ),
                                "term": term,
                                "value": float(value),
                            }
                        )
    return error_rows, coeff_rows


def summarize(error_rows):
    """Collapse the seeds of each (baseline, split_type, train_size) into mean +- std."""
    grouped = {}
    for row in error_rows:
        grouped.setdefault((row["baseline"], row["split_type"], row["train_size"]), []).append(row)
    summary = []
    for (baseline, split_type, train_size), rows in grouped.items():
        maes = np.array([row["mae"] for row in rows])
        rmses = np.array([row["rmse"] for row in rows])
        summary.append(
            {
                "dataset": gs.DATASET_SUBDIR,
                "baseline": baseline,
                "split_type": split_type,
                "train_size": train_size,
                "mae_mean": float(maes.mean()),
                # Population std, and 0 by construction for the deterministic split's single value.
                "mae_std": float(maes.std()),
                "rmse_mean": float(rmses.mean()),
                "rmse_std": float(rmses.std()),
                "n_seeds": len(rows),
                "n_test": rows[0]["n_test"],
            }
        )
    summary.sort(key=lambda row: (row["split_type"], row["baseline"], row["train_size"]))
    return summary


def write_csv(path, rows, fieldnames, header_comment):
    """One CSV, preceded by a comment line naming the units -- the files travel without this script."""
    with open(path, "w", newline="") as handle:
        handle.write(f"# {header_comment}\n")
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return path


def per_molecule_predictions(all_SMILES, data, specs, keep):
    """Per-molecule predictions in two modes, which must never be confused with each other.

    `insample_allpoints` fits on every molecule and predicts the same ones: a fair picture of what
    the fit looks like, and NOT a generalization number -- it must never be quoted against the
    ML's held-out errors. `oof_deterministic` holds out the deterministic scaffold split's test
    block, so those rows are honestly out-of-sample and are the ones a parity plot may carry a
    claim with.
    """
    labels = data[0]
    position = {SMILES: index for index, SMILES in enumerate(all_SMILES)}
    everything = np.arange(len(all_SMILES))[keep]
    rows = []

    modes = [("insample_allpoints", everything, everything)]
    # One held-out set per deterministic split, named after it: the pooled split's test molecules
    # are a different 128 from the by-skeleton split's, so a parity plot must not mix them.
    for split_type, label in (
        ("freq_deterministic", "oof_deterministic"),
        ("freq_deterministic_pool", "oof_deterministic_pool"),
    ):
        ordered, train_size = ordered_split(all_SMILES, split_type, SEEDS[0])
        modes.append(
            (
                label,
                np.array([position[SMILES] for SMILES in ordered[:train_size]]),
                np.array([position[SMILES] for SMILES in ordered[train_size:]]),
            )
        )

    for fit_mode, train, evaluate in modes:
        train = train[keep[train]]
        evaluate = evaluate[keep[evaluate]]
        columns = {}
        for name, spec in specs:
            columns[name], _, _, _ = predict(name, spec, train, evaluate, data)
        for offset, index in enumerate(evaluate):
            row = {
                "molecule_id": index,
                "smiles": all_SMILES[index],
                "fit_mode": fit_mode,
                "target_exp": float(labels[index]),
            }
            row.update({f"pred_{name}": float(columns[name][offset]) for name, _ in specs})
            rows.append(row)
    return rows


def sanity_checks(summary, error_rows, coeff_rows, specs, profile, unit, quiet=False):
    """The §8 checks, printed rather than only asserted, with a verdict on each."""
    proxy_baselines = [name for name, spec in specs if spec["kind"] == "fit" and spec.get("proxy")]
    verdicts = []
    # Things worth printing that are not pass/fail -- see the secondary-baseline note below.
    informational = []

    def note(ok, message):
        verdicts.append((ok, message))

    # 1. The xTB coefficient must be positive once the units match.
    for row in error_rows:
        if row["baseline"].endswith("_linear") and row["fit_b"] != "":
            note(
                row["fit_b"] > 0,
                f"slope on the proxy is {row['fit_b']:+.4f} "
                f"({row['baseline']}, {row['split_type']}, seed {row['seed']})",
            )
            break
    # The same check for the combined extensive fit, whose proxy coefficient lives in coeffs.csv
    # rather than in the fit_a/fit_b pair.
    for row in coeff_rows:
        if (
            row["baseline"] == "dressed_atom_plus_xtb"
            and row["term"] == profile["proxy_symbol"]
            and row["split_type"] == "random"
        ):
            note(
                row["value"] > 0,
                f"c_xTB is {row['value']:+.4f} in dressed_atom_plus_xtb (random split)",
            )
            break

    # 2. The physical floor must beat the trivial one on the random split, at max train.
    by_key = {(row["baseline"], row["split_type"], row["train_size"]): row for row in summary}
    max_train = max(row["train_size"] for row in summary)
    mean_row = by_key.get(("mean", "random", max_train))
    for name in proxy_baselines + ["dressed_atom"]:
        row = by_key.get((name, "random", max_train))
        if not (row and mean_row):
            continue
        beats = row["mae_mean"] < mean_row["mae_mean"]
        message = (
            f"{name} MAE {row['mae_mean']:.4f} vs mean floor {mean_row['mae_mean']:.4f} {unit}"
            " on the random split"
        )
        if name in profile["primary"]:
            note(beats, message)
        else:
            # Secondary here, and losing to the floor can be the correct answer: a dressed-atom
            # sum cannot represent an intensive target, which is exactly why it is not primary for
            # every dataset. Reported, not demanded.
            informational.append(f"{message} [secondary baseline]")
    combined = by_key.get(("dressed_atom_plus_xtb", "random", max_train))
    composition = by_key.get(("dressed_atom", "random", max_train))
    if combined and composition:
        note(
            combined["mae_mean"] < composition["mae_mean"],
            f"adding the xTB term improves dressed_atom {composition['mae_mean']:.4f}"
            f" -> {combined['mae_mean']:.4f} {unit}; if it does not, check the extraction",
        )

    # What forcing the proxy to unit weight costs: the free-slope fit nests the delta-ML one, so
    # the gap is the price of delta-ML's structure, and a small gap is the argument that
    # subtracting the reference outright loses nothing worth fitting.
    for free, fixed in (
        (
            proxy_baselines[0] if proxy_baselines else None,
            f"xtb_{profile['proxy_name']}_linear_dml",
        ),
        ("dressed_atom_plus_xtb", "dressed_atom_plus_xtb_dml"),
    ):
        free_row = by_key.get((free, "random", max_train))
        fixed_row = by_key.get((fixed, "random", max_train))
        if free_row and fixed_row:
            cost = fixed_row["mae_mean"] - free_row["mae_mean"]
            informational.append(
                f"unit-weight proxy costs {cost:+.4f} {unit}: {free} {free_row['mae_mean']:.4f}"
                f" -> {fixed} {fixed_row['mae_mean']:.4f} (random split)"
            )

    # 3. The frequency-ordered split is meant to be the harder one.
    for name in [n for n, spec in specs if spec["kind"] != "raw"]:
        easy = by_key.get((name, "random", max_train))
        hard = by_key.get((name, "freq_deterministic", max_train))
        if hard and easy:
            note(
                hard["mae_mean"] >= easy["mae_mean"],
                f"{name}: deterministic-scaffold MAE {hard['mae_mean']:.4f} >= random"
                f" {easy['mae_mean']:.4f} {unit}",
            )
        # What is actually checkable: that the policy changed the split at all. Whether pooling
        # makes the split HARDER is a property of the dataset, not a law -- it does on FreeSolv,
        # where half the molecules are ring-free and pooling empties them out of the test set, but
        # on a dataset with few ring-free molecules the grouping barely moves and the direction
        # can go either way. So the direction is reported, and only "no change at all" fails.
        pooled = by_key.get((name, "freq_deterministic_pool", max_train))
        if pooled and hard:
            note(
                pooled["mae_mean"] != hard["mae_mean"],
                f"{name}: the pooled policy changed the split (MAE {hard['mae_mean']:.4f} ->"
                f" {pooled['mae_mean']:.4f} {unit})",
            )
            harder = "harder" if pooled["mae_mean"] > hard["mae_mean"] else "EASIER"
            informational.append(
                f"{name}: pooled split is {harder} than by-skeleton,"
                f" {hard['mae_mean']:.4f} -> {pooled['mae_mean']:.4f} {unit}"
            )

    # 4. Nothing lost or double-counted by any split.
    sizes = {
        (row["n_train_effective"] + row["n_test"])
        for row in error_rows
        if row["train_size"] == max_train
    }
    note(len(sizes) == 1, f"train+test is {sorted(sizes)} across every max-train split")

    if not quiet:
        print("\nSANITY CHECKS (§8):")
        for ok, message in verdicts:
            print(f"  [{'ok ' if ok else 'LOOK'}] {message}")
        for message in informational:
            print(f"  [--  ] {message}")
    return verdicts


def print_coefficients(coeff_rows, max_train, unit, per_line=4):
    """The fitted coefficients, collapsed over seeds, for the full training set.

    coeffs.csv has every one of them, per split and per seed and per curve point, which is the
    right form for a record and the wrong one for reading: the question at a terminal is what the
    fit decided, and the answer is a dozen numbers, not a thousand. The random split at full
    training size is printed because that is the fit the summary's headline rows come from.
    """
    grouped = {}
    for row in coeff_rows:
        if row["split_type"] != "random" or row["train_size"] != max_train:
            continue
        grouped.setdefault(row["baseline"], {}).setdefault(row["term"], []).append(row["value"])
    if not grouped:
        return
    print(f"\nCOEFFICIENTS: (random split, ntrain={max_train}, mean +- std over the seeds)")
    for baseline, terms in grouped.items():
        print(f"  {baseline}")
        formatted = []
        for term, values in terms.items():
            array = np.array(values)
            # A term fixed at unit weight has no spread to report, and printing "+- 0.0000" next
            # to it would suggest least squares happened to land there four times.
            if term.endswith("(fixed)"):
                formatted.append(f"{term} {array[0]:+.4f}")
            else:
                formatted.append(f"{term} {array.mean():+.4f} +- {array.std():.4f}")
        width = max(len(entry) for entry in formatted) + 2
        for start in range(0, len(formatted), per_line):
            print(
                "    "
                + "".join(entry.ljust(width) for entry in formatted[start : start + per_line])
            )
    print(f"    (per-element terms are {unit} per atom; they are NOT stable under collinearity)")


def main():
    args = list(sys.argv[1:])
    quiet = "--quiet" in args
    if quiet:
        args.remove("--quiet")
    out_dir = "."
    if "--out-dir" in args:
        index = args.index("--out-dir")
        out_dir = args[index + 1]
        del args[index : index + 2]
    if args:
        raise SystemExit(f"unexpected arguments: {args}\n\n{__doc__}")

    data_root = os.environ.get("DATA")
    if data_root is None:
        raise SystemExit(
            "DATA is not set, and it is what locates the dataset whose order the splits are "
            "built on.\nUnder SLURM the submitting shell has it; set it by hand otherwise."
        )
    profile = dataset_profile()
    containing_folder = data_root + "/" + gs.DATASET_SUBDIR
    json_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), BASELINE_JSON)
    if not os.path.isfile(json_path):
        raise SystemExit(
            f"no {BASELINE_JSON} beside this script.\n"
            "It is where the xTB quantity comes from -- generate it with `generate_savefiles.py "
            "pair`, or regenerate it from finished savefiles with `print_baseline_table.py`."
        )

    all_SMILES, labels, proxy, excluded = load_quantities(containing_folder, json_path)
    counts, elements = atom_counts(all_SMILES)
    keep = np.isfinite(proxy)
    # `mean` and `dressed_atom` would survive a molecule with no xTB number, but they are compared
    # against the baselines that would not, so the excluded set is the same for all of them.
    data = (labels, counts, proxy, elements, profile["proxy_symbol"])
    specs, skipped = applicable_specs(profile["proxy_name"], profile["quantity_nature"])
    unit = "eV" if gs.ENERGY_UNIT == "au_eV" else "kcal/mol"
    curve_sizes = [size for size in LEARNING_CURVE_SIZES]

    print("PARAMETERS:")
    print(f"  dataset              : {gs.DATASET_SUBDIR}")
    print(f"  quantity             : {gs.QUANTITY_DESCRIPTION}")
    print(f"  unit                 : {unit}")
    print(f"  molecules            : {len(all_SMILES)} (excluded: {len(excluded)})")
    print(f"  xTB proxy            : {profile['proxy_symbol']}, read from {BASELINE_JSON}")
    print(f"  elements             : {len(elements)} {' '.join(elements)}")
    print(f"  seeds                : {', '.join(str(seed) for seed in SEEDS)}")
    print(f"  train fraction       : {TRAIN_FRACTION} -> {train_size_for(len(all_SMILES))} train")
    print(f"  learning curve sizes : {curve_sizes + [train_size_for(len(all_SMILES))]}")
    print(
        f"  scaffold grouping    : acyclic={SCAFFOLD_ACYCLIC!r}"
        f" (the pooled split uses {SCAFFOLD_ACYCLIC_POOLED!r})"
        f" include_chirality={SCAFFOLD_INCLUDE_CHIRALITY}"
    )
    print(f"  ridge                : {RIDGE_SCALE:g} * trace/ncol on every fit")
    print(f"  quantity nature      : {profile['quantity_nature']}")
    print(f"  baselines            : {', '.join(name for name, _ in specs)}")
    print(f"  primary baselines    : {', '.join(profile['primary'])}")
    if skipped:
        other = "extensive" if profile["quantity_nature"] == "intensive" else "intensive"
        print(f"  NOT computed here    : {', '.join(name for name, _ in skipped)}")
        print(
            f"                         (that form is {other}; this target is"
            f" {profile['quantity_nature']})"
        )
    if excluded:
        print(f"  EXCLUDED (no xTB value, dropped from every fit and metric): {excluded}")

    # The learning_root is two levels up: <dataset>_learning/FJK/savefile_creation_fjd.
    learning_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    assert_splits_match_the_ml_runs(all_SMILES, learning_root, quiet=quiet)

    error_rows, coeff_rows = run_all_splits(all_SMILES, data, specs, curve_sizes, keep)
    summary = summarize(error_rows)
    prediction_rows = per_molecule_predictions(all_SMILES, data, specs, keep)

    os.makedirs(out_dir, exist_ok=True)
    unit_note = f"units: {unit}; quantity: {gs.QUANTITY_DESCRIPTION}; dataset: {gs.DATASET_SUBDIR}"
    written = [
        write_csv(
            os.path.join(out_dir, "baselines_errors.csv"),
            error_rows,
            [
                "dataset",
                "baseline",
                "split_type",
                "train_size",
                "seed",
                "mae",
                "rmse",
                "fit_a",
                "fit_b",
                "ridge_triggered",
                "n_test",
                "n_train_effective",
            ],
            unit_note + "; fit_a/fit_b are the intercept and proxy slope, blank where there is no"
            " such pair; ridge_triggered names degenerate columns",
        ),
        write_csv(
            os.path.join(out_dir, "baselines_summary.csv"),
            summary,
            [
                "dataset",
                "baseline",
                "split_type",
                "train_size",
                "mae_mean",
                "mae_std",
                "rmse_mean",
                "rmse_std",
                "n_seeds",
                "n_test",
            ],
            unit_note + "; std is across the seeds, 0 for the deterministic split",
        ),
        write_csv(
            os.path.join(out_dir, "coeffs.csv"),
            coeff_rows,
            ["dataset", "baseline", "split_type", "train_size", "seed", "term", "value"],
            unit_note + "; coefficients are NOT stable under collinearity -- for the record, not"
            " for interpretation",
        ),
        write_csv(
            os.path.join(out_dir, "per_molecule_quantities.csv"),
            [
                {
                    "molecule_id": index,
                    "smiles": SMILES,
                    "target_exp": float(labels[index]),
                    "xtb_proxy": float(proxy[index]) if keep[index] else "",
                    **{
                        f"n_{element}": int(counts[index, column])
                        for column, element in enumerate(elements)
                    },
                }
                for index, SMILES in enumerate(all_SMILES)
            ],
            ["molecule_id", "smiles", "target_exp", "xtb_proxy"]
            + [f"n_{element}" for element in elements],
            unit_note + f"; xtb_proxy is {profile['proxy_symbol']}, the conformer-weighted"
            " difference that --delta-ml subtracts; atom counts include hydrogens",
        ),
        write_csv(
            os.path.join(out_dir, "baseline_predictions.csv"),
            prediction_rows,
            ["molecule_id", "smiles", "fit_mode", "target_exp"]
            + [f"pred_{name}" for name, _ in specs],
            unit_note + "; fit_mode=insample_allpoints is IN-SAMPLE and must never be compared"
            " against held-out ML errors; fit_mode=oof_deterministic is held out",
        ),
    ]

    sanity_checks(summary, error_rows, coeff_rows, specs, profile, unit, quiet=quiet)
    if not quiet:
        print_coefficients(coeff_rows, train_size_for(len(all_SMILES)), unit)

    max_train = train_size_for(len(all_SMILES))
    print("\nSUMMARY:")
    print(f"  {'baseline':24s} {'split':20s} {'train':>6s}  {'MAE':>18s}  {'RMSE':>18s}")
    for row in summary:
        if row["train_size"] != max_train:
            continue
        mark = "*" if row["baseline"] in profile["primary"] else " "
        print(
            f"{mark} {row['baseline']:24s} {row['split_type']:20s} {row['train_size']:6d}"
            f"  {row['mae_mean']:9.4f} +- {row['mae_std']:5.4f}"
            f"  {row['rmse_mean']:9.4f} +- {row['rmse_std']:5.4f}   {unit}"
        )
    print(f"  (* = this dataset's primary baselines; all errors in {unit})")
    print("\n  learning-curve baselines (random split, mean over seeds):")
    for row in summary:
        if row["split_type"] == "random" and row["baseline"] in profile["primary"]:
            print(
                f"    {row['baseline']:24s} ntrain={row['train_size']:4d}"
                f"  MAE {row['mae_mean']:9.4f} +- {row['mae_std']:6.4f} {unit}"
            )
    print("\n  files written:")
    for path in written:
        print(f"    {path}")


if __name__ == "__main__":
    main()
