"""Print SMILES, experimental quantity and baseline prediction from the savefiles already on disk.

    python print_baseline_table.py                  # CSV to baseline_table.csv, JSON beside it
    python print_baseline_table.py --stdout         # CSV to stdout instead of a file
    python print_baseline_table.py --out-dir DIR    # write both files into DIR

The baseline is the pair's own conformer-weighted energy difference -- E(cation) - E(neutral) for
LES, E(water) - E(gas) for FreeSolv -- which is what `--delta-ml` learns the residual against. It
already came out of `generate_savefiles.py pair` as FJD_pair_baseline.json, as a side effect of a
job that took hours; this script produces the same table from the finished savefiles in seconds, so
the numbers can be re-read, diffed, or turned into a CSV without rerunning any chemistry.

COMPUTES NOTHING. `Ensemble.run_calcs()` would happily start a GFN2 calculation for a molecule
whose savefile is missing -- here, on whatever machine this is invoked on. So every molecule's
savefile is checked for FIRST, and the ones without are reported as missing rather than calculated.
That is also what makes this safe to run on a login node while the real jobs are still going.

Both outputs are written because they answer different questions: the CSV is for reading and
plotting, the JSON is the artifact the repo already has for LES and is written through
`generate_savefiles.report_baseline`, so its shape cannot drift from the original.
"""

import csv
import glob
import os
import sys

# The sibling module carries everything dataset-specific: the savefile folder layout, the quantity
# loader, the unit conversion and the baseline arithmetic. Importing it is what keeps this file
# identical in the LES and FreeSolv copies.
import generate_savefiles as gs

DEFAULT_CSV = "baseline_table.csv"
DEFAULT_JSON = "FJD_pair_baseline.json"


def savefile_exists(SMILES, folder):
    """Whether this molecule has a conformer savefile in `folder`.

    `Ensemble` writes `<prefix>_<suffix>.pkl` with the suffix chosen by its own bookkeeping, so the
    test is a glob on the prefix rather than a known filename.
    """
    prefix = folder + "/" + SMILES.replace("/", "_")
    return bool(glob.glob(glob.escape(prefix) + "_*.pkl"))


def main():
    args = [argument for argument in sys.argv[1:]]
    to_stdout = "--stdout" in args
    if to_stdout:
        args.remove("--stdout")
    out_dir = "."
    if "--out-dir" in args:
        index = args.index("--out-dir")
        out_dir = args[index + 1]
        del args[index : index + 2]
    if args:
        raise SystemExit(f"unexpected arguments: {args}\n\n{__doc__}")

    data_root = os.environ.get("DATA")
    if data_root is None:
        raise SystemExit(
            "DATA is not set, and it is what locates both the dataset and the savefiles.\n"
            "Under SLURM the submitting shell has it; set it by hand otherwise."
        )
    containing_folder = data_root + "/" + gs.DATASET_SUBDIR
    folder = gs.savefile_folder(containing_folder, pair=True)
    print("SAVEFILE FOLDER:", folder)
    if not os.path.isdir(folder):
        raise SystemExit(
            f"no such folder: {folder}\n"
            "Nothing to print -- run `generate_savefiles.py pair` first, or point DATA at the "
            "host that holds the savefiles."
        )

    all_data = gs.load_dataset(containing_folder)
    all_SMILES = sorted(all_data.keys())

    results, missing = [], []
    for SMILES in all_SMILES:
        if not savefile_exists(SMILES, folder):
            missing.append(SMILES)
            continue
        # Reuse the generator's own arithmetic rather than repeating it: this unpickles the stored
        # conformers and returns the weighted difference in the dataset's unit.
        results.append(gs.calculate(SMILES, True, folder))

    finished = [(SMILES, value) for SMILES, value, error in results if value is not None]
    failed = [(SMILES, error) for SMILES, _, error in results if error is not None]
    print(f"molecules in the dataset : {len(all_SMILES)}")
    print(f"  with a savefile        : {len(results)}")
    print(f"  readable               : {len(finished)}")
    print(f"  savefile missing       : {len(missing)}")
    print(f"  savefile unreadable    : {len(failed)}")
    for SMILES, error in failed[:10]:
        print(f"    FAILED {SMILES}: {error}")
    if len(failed) > 10:
        print(f"    ... and {len(failed) - 10} more")
    if not finished:
        raise SystemExit("nothing readable; no table written")

    os.makedirs(out_dir, exist_ok=True)
    # The JSON through report_baseline, which also prints the correlation summary: one definition of
    # that file's shape, in the module that first wrote it.
    json_path = os.path.join(out_dir, DEFAULT_JSON)
    gs.report_baseline(results, all_data, json_path)

    header = ("smiles", "quantity", "baseline_prediction")
    rows = [(SMILES, float(all_data[SMILES][0]), float(value)) for SMILES, value in finished]
    if to_stdout:
        writer = csv.writer(sys.stdout)
        writer.writerow(header)
        writer.writerows(rows)
    else:
        csv_path = os.path.join(out_dir, DEFAULT_CSV)
        with open(csv_path, "w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(header)
            writer.writerows(rows)
        print(f"  {len(rows)} rows written to {csv_path}")
    print(f"  quantity column: {gs.QUANTITY_DESCRIPTION}")


if __name__ == "__main__":
    main()
