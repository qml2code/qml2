#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython cMBDF_FreeSolv_full.py cMBDF_learn_FreeSolv_$seed $seed
done
