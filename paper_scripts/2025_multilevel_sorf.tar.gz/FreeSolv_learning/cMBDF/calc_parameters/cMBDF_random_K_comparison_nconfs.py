import os
import random
import sys

import numpy as np

from qml2.dataset_formats.FreeSolv import get_free_solvation_energies
from qml2.ensemble import Ensemble
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import (
    ElementAugmentedLocalRepresentationCalc,
    ProcessedRepresentationListCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    EnsembleRepresentationCalc,
    local_dn_rep_ensemble_list_dict2datatype,
)
from qml2.representations.calculators import cMBDFCalculator
from qml2.utils import get_sorted_elements, roundup_power2

if len(sys.argv) > 1:
    seed = int(sys.argv[1])
else:
    seed = 274658
random.seed(seed)

containing_folder = os.environ["DATA"] + "/FreeSolv/FreeSolv-0.51"

ntransforms = 3

r_cut = 0.05  # None

# Import all data.
all_data = get_free_solvation_energies(containing_folder=containing_folder)

all_SMILES = sorted(list(all_data.keys()))
num_mols = len(all_SMILES)

# NOTE: the total number of molecules is 642
training_set_size = 514
nfeatures = 32768

random.shuffle(all_SMILES)

training_SMILES = all_SMILES[:training_set_size]


def get_K(num_conformers, sigmas):
    #    savefile_folder = (
    #        containing_folder
    #        + "/savefiles_cMBDF_rcut_"
    #        + str(r_cut)
    #        + "_num_conformers_"
    #        + str(num_conformers)
    #    )
    #    try:
    #        os.mkdir(savefile_folder)
    #    except FileExistsError:
    #        pass
    #        print("savefile folder already created")

    ensemble_kwargs = {
        "base_class_name": "Compound",
        "num_conformers": num_conformers,
        "r_cut": r_cut,
    }

    training_ensembles = []

    training_nuclear_charges = []
    present_nuclear_charges = []

    for SMILES in training_SMILES:
        #        changed_SMILES = SMILES.replace("/", "_")
        #        savefile_prefix=savefile_folder + "/" + changed_SMILES
        ensemble = Ensemble(SMILES=SMILES, savefile_prefix=None, **ensemble_kwargs)

        current_nuclear_charges = ensemble.get_nuclear_charges()

        training_nuclear_charges.append(current_nuclear_charges)
        present_nuclear_charges += list(current_nuclear_charges)

        training_ensembles.append(ensemble)

    present_nuclear_charges = get_sorted_elements(np.array(present_nuclear_charges))

    rep_calculator = ElementAugmentedLocalRepresentationCalc(
        representation_function=cMBDFCalculator(training_nuclear_charges),
        possible_nuclear_charges=present_nuclear_charges,
    )

    ensemble_rep_calculator = EnsembleRepresentationCalc(rep_calculator)

    parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

    training_ensemble_dicts = parallel_calculator(training_ensembles)

    training_ensembles = local_dn_rep_ensemble_list_dict2datatype(training_ensemble_dicts)

    max_component_bound = parallel_calculator.max_component_bound()

    init_size = roundup_power2(max_component_bound)

    nfeature_stacks = nfeatures // init_size

    function_definition_list = [
        "resize",
        "sorf",
        "element_id_switch",
        "component_sum",
        "weighted_component_sum",
        "component_sum",
    ]

    parameter_list = [
        {"output_size": init_size},
        {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
        {"num_element_ids": len(present_nuclear_charges)},
        {},
        {},
        {},
    ]

    model = MultilevelSORFModel(
        function_definition_list,
        parameter_list,
    )
    mSORF = model.MultilevelSORF
    if sigmas is None:
        sigmas = mSORF.hyperparameter_initial_guesses(training_ensembles)
    Z_matrix = mSORF.calc_Z_matrix(training_ensembles, sigmas)
    K = np.dot(Z_matrix, Z_matrix.T)

    return K, sigmas


nmats = 8

K_bench = None
K_std_bench = None
sigmas = None

for nconfs in [1024, 512, 256, 128, 64, 32, 16, 8]:
    K_new = np.zeros((nmats, training_set_size, training_set_size))
    for i_mat in range(nmats):
        K_new[i_mat, :, :], sigmas = get_K(nconfs, sigmas)
    K_mean = np.mean(K_new, axis=0)
    K_std_new = np.std(K_new, axis=0) / np.sqrt(float(nmats))
    if K_bench is None:
        K_bench = K_mean
        K_std_bench = K_std_new
    else:
        diff = np.sqrt(np.mean((K_mean - K_bench) ** 2))
        max_diff = np.max(np.abs(K_mean - K_bench))
        print(
            "###",
            nconfs,
            max_diff,
            diff,
            np.sqrt(np.mean(K_std_new**2 + K_std_bench**2)),
            np.mean(np.abs(K_mean)),
        )


print(K_mean.shape, K_std_new.shape)
