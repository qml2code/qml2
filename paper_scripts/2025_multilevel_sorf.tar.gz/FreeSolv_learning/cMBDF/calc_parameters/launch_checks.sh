#!/bin/bash

# K matrices
spython cMBDF_random_K_comparison.py cMBDF_random_K_comparison
spython cMBDF_random_K_comparison_nconfs.py cMBDF_random_K_comparison_nconfs
