#!/bin/bash

# K matrices
spython SOAP_mixed_sorf_random_K_comparison.py SOAP_mixed_sorf_random_K_comparison
