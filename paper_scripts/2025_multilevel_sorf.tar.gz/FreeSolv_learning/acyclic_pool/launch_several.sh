#!/bin/bash
#
# FreeSolv under the POOLED acyclic policy: one deterministic frequency-ordered scaffold split
# per configuration, to be read against the same configurations' numbers in ../FJK,
# ../FJK_single_det and ../charge_augmented, which group the ring-free molecules by skeleton.
#
# Why this directory exists. Half of FreeSolv (320 of 642 molecules) has no ring at all, so what
# happens to the ring-free molecules decides the split. Grouped by generic carbon skeleton -- the
# default everywhere else here -- they spread over many groups and end up as 48% of the test set.
# Pooled into one group, which is the MoleculeNet/DeepChem convention, they are a single
# unsplittable group bigger than any scaffold group, the frequency-ordered split assigns it whole
# to training, and the test set comes out with NO ring-free molecule in it. That test set is
# further from its training set by every measure in ../scaffolds/scaffold_results (ECFP4 median
# nearest-neighbour similarity 0.25 against 0.35, held-out fraction 0.82 against 0.58, SLATM
# median distance 12.8 against 9.5) while no longer sampling half of the dataset's chemistry.
# These runs put a number on what that does to the models.
#
# DETERMINISTIC SPLIT ONLY, and the scripts enforce it: with the ring-free molecules pooled, the
# tie shuffling has almost nothing left to reorder, so all four paper seeds return the same split
# -- identical to this one. --rfo_scaffold is refused rather than run four times for a zero error
# bar. One number per configuration is all this policy has to give.
#
# No new quantum chemistry: the savefiles under $DATA are the ones the ../FJK and
# ../charge_augmented runs already built, and only the grouping of the split changes.
#
# CORES: spython's default allocation, deliberately, which is 80 on this node. Note what the
# neighbouring launchers do and why they differ -- they pass --CPUs=16 because --CPUs doubles as
# a MEMORY request here (CR_Core_Memory, DefMemPerCPU=2681), so 16 buys 42 GB and 80 buys 210 GB,
# and because a learning curve stops scaling long before 80 cores. Neither reason bites here: a
# single scaffold split is one fit plus its group-based hyperparameter optimization, not a
# five-point curve, and the extra memory is free headroom for the aSLATM pair representation.
# It does mean each job takes the whole SLURM allocation, so all twelve run one after another.

# The deterministic split ignores the seed; it is passed because the argument is positional, and
# 274658 is the seed the other fo_scaffold runs name their jobs with.
fo_seed=274658

# The two representations that touch no GFN2-xTB output at all -- see the xTB-FREE block below.
aslatm_script=../aSLATM/aSLATM_FreeSolv_full.py
fchl19_script=../FCHL19/FCHL19_FreeSolv_full.py
fjd_pair_script=../FJK/FJK_FreeSolv_full.py
fjd_sdet_script=../FJK_single_det/FJK_sdet_FreeSolv_full.py
charges_script=../charge_augmented/charge_augmented_FreeSolv_full.py

# BOTH DETERMINANT TREATMENTS EVERYWHERE, which is the honest way to run this: on the by-skeleton
# fo_scaffold split the winner flips with the delta-ML axis, and it flips in OPPOSITE directions
# for the two charge-augmented representations, so there is no single choice that would be "the
# best configuration" across the grid (kcal/mol, by-skeleton fo_scaffold):
#
#                      plain (no delta-ML)          with delta-ML
#   FCHL19+charges     sdet 0.9606 < pair 0.9862    pair 1.0022 < sdet 1.0465
#   aSLATM+charges     pair 1.2029 < sdet 1.2101    sdet 1.0024 < pair 1.0453
#   FJD                sdet 1.0286 < pair 1.0406    pair 0.9179 < sdet 0.9497
#
# Every margin above is small (0.007 to 0.044) and comes from a split with no error bar, which is
# the other reason to run both rather than pick: under the pooled policy the ordering may simply
# not survive, and that is itself worth knowing.

# The representation arms, with BOTH determinant treatments spelled out per arm:
#   name | pair script | pair flags | single-determinant script | single-determinant flags
#
# Why it is written this way rather than with one --sdet appended in the loop: the two families do
# not express the determinant the same way. The charge-augmented script takes --sdet as a runtime
# flag, while the FJD family splits it across two SCRIPTS -- ../FJK is the pair,
# ../FJK_single_det is the single determinant -- and neither of those contains a --sdet flag at
# all. The first version of this launcher appended --sdet for every arm; against the FJD script
# that flag is unrecognized, and because these scripts parse argv by hand (nothing rejects an
# unknown argument) it survived into the first positional slot and the job died on
# int('--sdet'). Keeping both call forms visible per arm is what stops that from coming back.
reps=(
	"FCHL19|$charges_script||$charges_script|--sdet"
	"aSLATM|$charges_script|--aslatm|$charges_script|--aslatm --sdet"
	"FJD|$fjd_pair_script||$fjd_sdet_script|"
)

# ALL SIX delta-ML jobs first, then all six plain ones. These jobs serialize on the full node, so
# submission order is the order results arrive in, and delta-ML is what the manuscript is expected
# to report: across every matched pair already on disk it wins 36 of 36 on LES and 24 of 27 on
# FreeSolv. The plain runs still follow, because the three FreeSolv exceptions are all on exactly
# this split -- FCHL19+charges is BETTER without delta-ML on fo_scaffold, by 0.086 (sdet) and
# 0.016 (pair) kcal/mol under the by-skeleton grouping, margins that sit inside the seed spread of
# the replicated splits -- so whether that reversal survives the pooled policy is one of the things
# this grid is here to answer.
#
# Simple shifts throughout -- the trailing positional True.
for dml_name in "dml" "plain"
do
	if [ "$dml_name" == "dml" ]
	then
		dml_flag=--delta-ml
		dml_tag=_dml
	else
		dml_flag=
		dml_tag=
	fi

	# FCHL19, then aSLATM, then FJD, within each of the two blocks. The two determinant
	# treatments stay adjacent inside a representation, so that comparison lands in neighbouring
	# jobs.
	for rep_spec in "${reps[@]}"
	do
		IFS='|' read -r rep_name pair_script pair_flags sdet_script sdet_flags <<< "$rep_spec"

		for det_name in "pair" "sdet"
		do
			if [ "$det_name" == "sdet" ]
			then
				script=$sdet_script
				rep_flags=$sdet_flags
			else
				script=$pair_script
				rep_flags=$pair_flags
			fi

			# The charge-augmented jobs name the determinant explicitly; the FJD jobs follow the
			# convention of ../FJK against ../FJK_single_det, where the pair carries no marker.
			if [ "$rep_name" == "FJD" ]
			then
				if [ "$det_name" == "sdet" ]
				then
					tag=FJD_sdet
				else
					tag=FJD
				fi
			else
				tag=${rep_name}_charges_${det_name}
			fi
			tag=${tag}_fo_scaffold_acyclic_pool_FreeSolv_simple_shifts${dml_tag}

			spython $script "$tag" \
				$rep_flags $dml_flag --pool-acyclic --fo_scaffold $fo_seed True
		done
	done
done


# ==================================================================================================
# xTB-FREE ARMS: how far the pooled split can be pushed with NO GFN2-xTB input whatsoever.
#
# Everything above consumes GFN2 somewhere -- the FJD representations are built from its localized
# orbitals, the charge-augmented ones append its atomic charges, and --delta-ml subtracts its energy
# difference. These four runs use none of it: aSLATM and FCHL19 are functions of geometry and
# nuclear charges alone, and the conformers they average over come from MMFF94 (base_class_name
# "Compound", ff_type "MMFF94"), so not even the ensemble weights see a quantum calculation. The
# question they answer is what the pooled split costs a purely structural model, and how close that
# gets to the GFN2-informed rows -- which matters most on exactly this split, where the test set is
# the furthest from its training set.
#
# aSLATM and FCHL19 are the right two to ask: across both datasets and all three splits they are
# the strongest xTB-free representations on record here, FCHL19 leading five of the six cells and
# aSLATM taking FreeSolv's deterministic scaffold split (1.1687 against FCHL19's 1.1782 by
# skeleton). SLATM, cMBDF, SOAP and CM are all behind them on this dataset.
#
# SIMPLE SHIFTS ONLY, matching every other arm in this directory: all twelve GFN2 runs above are
# simple-shift runs, so the xTB-free rows are directly comparable with them and with the
# by-skeleton fo_scaffold counterparts -- aSLATM 1.1687 / 1.8358, FCHL19 1.1782 / 1.8537
# (MAE / RMSE, kcal/mol), the only mode for which those counterparts exist.
#
# Deliberately NOT run here: the hyperparameter-shift mode (positional False), where the shift
# coefficients are optimized against cross-validation errors instead of fitted directly. Worth
# knowing that it is the mode winning FCHL19's RANDOM split (0.4804 against 0.4954), so the number
# these runs produce is "the best without xTB under the grid's own shift setting", not necessarily
# the best this representation could do on a pooled split. Adding it later is one entry in the loop
# below, and the launcher comment history has the argument.
#
# Fast, unlike the GFN2 arms: the by-skeleton counterparts took 13 and 15 minutes.

#   name | script
xtb_free_reps=(
	"FCHL19|$fchl19_script"
	"aSLATM|$aslatm_script"
)

for rep_spec in "${xtb_free_reps[@]}"
do
	IFS='|' read -r rep_name script <<< "$rep_spec"

	spython $script \
		"${rep_name}_fo_scaffold_acyclic_pool_FreeSolv_simple_shifts" \
		--pool-acyclic --fo_scaffold $fo_seed True
done
