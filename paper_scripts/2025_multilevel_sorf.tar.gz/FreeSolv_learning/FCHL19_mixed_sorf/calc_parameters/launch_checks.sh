#!/bin/bash

# K matrices
spython FCHL19_mixed_sorf_random_K_comparison.py FCHL19_mixed_sorf_random_K_comparison
