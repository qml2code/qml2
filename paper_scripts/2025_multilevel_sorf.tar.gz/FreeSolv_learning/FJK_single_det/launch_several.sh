#!/bin/bash

# Learning curves scale poorly across every core this node reports, so ask spython for a
# smaller allocation than the hardware. An explicit --CPUs= would still override this.
export SPYTHON_ASSUMED_NCPUS=16

# FJD unless --fjk is passed, which selects the representation the paper used. The job name
# follows the choice: spython refuses to reuse an existing data directory, so the two must
# not land on the same one -- and under --fjk the names come out exactly as they were.
if [ "$1" == "--fjk" ]
then
    rep=FJK
    rep_flag=--fjk
else
    rep=FJD
    rep_flag=
fi

ss_dir=simple_shifts
# Same shifts, but learning the residual against the hydration free energy the
# two-determinant workflow computes. The reference is identical to the one the pair script
# uses, so the two sets of curves differ only in how the representation is built.
ss_dml_dir=simple_shifts_dml

# One conformer per molecule instead of the weighted ensemble, the counterpart of the
# min_conformer/ runs aSLATM, FCHL19 and CM already have and of the ones the pair launcher
# submits. Simple shifts, with and without delta-ML, so the question "what does the ensemble
# buy over its best conformer?" is asked on both sides of the reference rather than only
# where there is no reference to help.
#
# NOTE on the delta-ML pair: the subtracted reference stays the conformer-weighted ensemble
# difference even under --min_conf, because this script does not compute it at all -- it
# reads it out of the PAIR savefiles (delta_ml_reference in FJK_sdet_FreeSolv_full.py), and
# --min_conf changes only how the single determinant it represents is built. That is
# DELIBERATE and should stay so. Holding the reference fixed keeps the only varied axis the
# representation, which makes this a comparison of conformer against ensemble REPRESENTATION
# efficiency. Letting the reference follow the representation would instead compare two
# delta-ML references' quality -- a separate question, and one that would confound this one,
# since a weaker reference leaves a larger residual to learn and the two effects would arrive
# in the same number. So these runs are deliberately not a single-conformer pipeline end to
# end: do not "fix" them by subtracting each molecule's own chosen conformer.
#
# It is also the same reference the pair script subtracts, so a min-conformer delta-ML run
# here and one there differ only in whether the second determinant enters the
# representation -- which is what makes the two directly comparable.
#
# It reuses the ensemble run's savefiles -- the ab initio results are per conformer and the
# folder name is deliberately unchanged -- so it adds no quantum chemistry, only learning.
mc_ss_dir=min_conformer/simple_shifts
mc_ss_dml_dir=min_conformer/simple_shifts_dml

ss_dir_fo=simple_shifts_fo_scaffold
ss_dir_rfo=simple_shifts_rfo_scaffold
ss_dml_dir_fo=simple_shifts_dml_fo_scaffold
ss_dml_dir_rfo=simple_shifts_dml_rfo_scaffold
mc_ss_dir_fo=min_conformer/simple_shifts_fo_scaffold
mc_ss_dir_rfo=min_conformer/simple_shifts_rfo_scaffold
mc_ss_dml_dir_fo=min_conformer/simple_shifts_dml_fo_scaffold
mc_ss_dml_dir_rfo=min_conformer/simple_shifts_dml_rfo_scaffold
mkdir -p $ss_dir $ss_dml_dir $mc_ss_dir $mc_ss_dml_dir $ss_dir_fo $ss_dir_rfo $ss_dml_dir_fo $ss_dml_dir_rfo $mc_ss_dir_fo $mc_ss_dir_rfo $mc_ss_dml_dir_fo $mc_ss_dml_dir_rfo


# One 80/20 frequency-ordered scaffold split instead of a learning curve, with
# group-based hyperparameter optimization. The deterministic split is a property of the
# grouping and the train size, not of a seed, so it is submitted once; a seed is still
# passed because the argument is positional.
cd $ss_dir_fo
spython ../FJK_sdet_FreeSolv_full.py ${rep}_sdet_fo_scaffold_FreeSolv_simple_shifts $rep_flag --fo_scaffold 274658 True
cd ../
cd $ss_dml_dir_fo
spython ../FJK_sdet_FreeSolv_full.py ${rep}_sdet_fo_scaffold_FreeSolv_simple_shifts_dml $rep_flag --delta-ml --fo_scaffold 274658 True
cd ../
cd $mc_ss_dir_fo
spython ../../FJK_sdet_FreeSolv_full.py ${rep}_sdet_min_conf_fo_scaffold_FreeSolv_simple_shifts $rep_flag --min_conf --fo_scaffold 274658 True
cd ../../
cd $mc_ss_dml_dir_fo
spython ../../FJK_sdet_FreeSolv_full.py ${rep}_sdet_min_conf_fo_scaffold_FreeSolv_simple_shifts_dml $rep_flag --min_conf --delta-ml --fo_scaffold 274658 True
cd ../../

for seed in 274658 20786 109790 478390
do
	spython FJK_sdet_FreeSolv_full.py ${rep}_sdet_learn_FreeSolv_$seed $rep_flag $seed False
	cd $ss_dir
	spython ../FJK_sdet_FreeSolv_full.py ${rep}_sdet_learn_FreeSolv_simple_shifts_$seed $rep_flag $seed True
	cd ../
	cd $ss_dml_dir
	spython ../FJK_sdet_FreeSolv_full.py ${rep}_sdet_learn_FreeSolv_simple_shifts_dml_$seed $rep_flag --delta-ml $seed True
	cd ../
	cd $mc_ss_dir
	spython ../../FJK_sdet_FreeSolv_full.py ${rep}_sdet_min_conf_learn_FreeSolv_simple_shifts_$seed $rep_flag --min_conf $seed True
	cd ../../
	cd $mc_ss_dml_dir
	spython ../../FJK_sdet_FreeSolv_full.py ${rep}_sdet_min_conf_learn_FreeSolv_simple_shifts_dml_$seed $rep_flag --min_conf --delta-ml $seed True
	cd ../../
	cd $ss_dir_rfo
	spython ../FJK_sdet_FreeSolv_full.py ${rep}_sdet_rfo_scaffold_FreeSolv_simple_shifts_$seed $rep_flag --rfo_scaffold $seed True
	cd ../
	cd $ss_dml_dir_rfo
	spython ../FJK_sdet_FreeSolv_full.py ${rep}_sdet_rfo_scaffold_FreeSolv_simple_shifts_dml_$seed $rep_flag --delta-ml --rfo_scaffold $seed True
	cd ../
	cd $mc_ss_dir_rfo
	spython ../../FJK_sdet_FreeSolv_full.py ${rep}_sdet_min_conf_rfo_scaffold_FreeSolv_simple_shifts_$seed $rep_flag --min_conf --rfo_scaffold $seed True
	cd ../../
	cd $mc_ss_dml_dir_rfo
	spython ../../FJK_sdet_FreeSolv_full.py ${rep}_sdet_min_conf_rfo_scaffold_FreeSolv_simple_shifts_dml_$seed $rep_flag --min_conf --delta-ml --rfo_scaffold $seed True
	cd ../../
done
