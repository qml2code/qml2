#!/bin/bash

for ntransforms in 7 6 5 4 3 2 1
do
    sleep 1
    spython FJK_sdet_random_K_comparison.py FJK_sdet_random_K_check_$ntransforms $ntransforms $(pwd)/benchmark_K.pkl
done
