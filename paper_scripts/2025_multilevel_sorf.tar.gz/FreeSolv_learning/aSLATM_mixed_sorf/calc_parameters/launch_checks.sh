#!/bin/bash

# K matrices
spython aSLATM_mixed_sorf_random_K_comparison.py aSLATM_mixed_sorf_random_K_comparison
