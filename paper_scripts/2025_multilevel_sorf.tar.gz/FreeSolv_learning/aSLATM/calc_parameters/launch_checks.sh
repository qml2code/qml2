#!/bin/bash

# K matrices
spython aSLATM_random_K_comparison.py aSLATM_random_K_comparison
