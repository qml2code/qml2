import os
import random
import sys

import numpy as np

from qml2.basic_utils import now
from qml2.dataset_formats.FreeSolv import get_free_solvation_energies
from qml2.ensemble import Ensemble
from qml2.models.learning_curves import learning_curve_from_predictions
from qml2.models.loss_functions import MAE, RMSE
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import (
    ElementAugmentedLocalRepresentationCalc,
    ProcessedRepresentationListCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    EnsembleRepresentationCalc,
    local_dn_rep_ensemble_list_dict2datatype,
)
from qml2.representations.calculators import SLATMCalculator


def main():
    if len(sys.argv) > 1:
        seed = int(sys.argv[1])
    else:
        seed = 274658

    if len(sys.argv) > 2:
        no_shifts_str = sys.argv[2]
        assert no_shifts_str in ["True", "False"]
        no_shifts = no_shifts_str == "True"
    else:
        no_shifts = False

    print("SEED:", seed, "NO SHIFTS:", no_shifts)

    random.seed(seed)

    containing_folder = os.environ["DATA"] + "/FreeSolv/MobleyLab-FreeSolv-9d8a809"

    r_cut = 0.05
    num_conformers = 32

    savefile_folder = (
        containing_folder
        + "/savefiles_aSLATM_rcut_"
        + str(r_cut)
        + "_num_conformers_"
        + str(num_conformers)
    )

    try:
        os.mkdir(savefile_folder)
    except FileExistsError:
        print("savefile folder already created")

    # Import all data .
    all_data = get_free_solvation_energies(containing_folder=containing_folder)

    all_SMILES = sorted(list(all_data.keys()))
    assert len(all_SMILES) == 642

    # NOTE: the total number of molecules is 642
    training_set_size = 514
    nfeatures = 131072

    random.shuffle(all_SMILES)

    # For now running without statistical errors

    ensemble_kwargs = {
        "base_class_name": "Compound",
        "num_conformers": num_conformers,
        "r_cut": r_cut,
    }

    ensembles = []
    quant_vals = []

    all_nuclear_charges = []
    present_nuclear_charges = []

    for SMILES in all_SMILES:
        changed_SMILES = SMILES.replace("/", "_")
        ensemble = Ensemble(
            SMILES=SMILES,
            savefile_prefix=savefile_folder + "/" + changed_SMILES,
            **ensemble_kwargs,
        )

        current_nuclear_charges = ensemble.get_nuclear_charges()
        present_nuclear_charges += list(current_nuclear_charges)

        all_nuclear_charges.append(current_nuclear_charges)

        quant_vals.append(all_data[SMILES][0])
        ensembles.append(ensemble)

    print("Number of usable ensembles:", len(ensembles))

    present_nuclear_charges = np.unique(np.array(present_nuclear_charges))

    print("Present nuclear charges:", present_nuclear_charges)

    quant_vals = np.array(quant_vals)

    rep_calculator = ElementAugmentedLocalRepresentationCalc(
        representation_function=SLATMCalculator(all_nuclear_charges),
        possible_nuclear_charges=present_nuclear_charges,
        representation_function_kwargs={"local": True},
    )

    ensemble_rep_calculator = EnsembleRepresentationCalc(rep_calculator)

    parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

    processed_ensemble_dicts = parallel_calculator(ensembles)

    processed_ensembles = local_dn_rep_ensemble_list_dict2datatype(processed_ensemble_dicts)

    component_bounds = parallel_calculator.component_bounds

    print(component_bounds)

    max_component_bound = parallel_calculator.max_component_bound()
    print(max_component_bound)

    init_size = nfeatures
    assert init_size >= max_component_bound
    print("SORF init_size", init_size)

    nfeature_stacks = nfeatures // init_size

    print("nfeature_stacks:", nfeature_stacks)

    training_ensembles = processed_ensembles[:training_set_size]
    training_quantities = quant_vals[:training_set_size]

    test_ensembles = processed_ensembles[training_set_size:]
    test_quantities = quant_vals[training_set_size:]

    training_nuclear_charges = all_nuclear_charges[:training_set_size]
    test_nuclear_charges = all_nuclear_charges[training_set_size:]

    function_definition_list = [
        "resize",
        "sorf",
        "element_id_switch",
        "component_sum",
        "weighted_component_sum",
        "component_sum",
    ]

    ntransforms = 3

    parameter_list = [
        {"output_size": init_size},
        {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
        {"num_element_ids": len(present_nuclear_charges)},
        {},
        {},
        {},
    ]

    model = MultilevelSORFModel(
        function_definition_list,
        parameter_list,
        intensive_quantity_shift=False,
        extensive_quantity_shift=(not no_shifts),
    )

    training_set_sizes = [50, 100, 200, 400, training_set_size]

    # nperturbations = 4
    # initial_guess_perturbations = (
    #    np.random.random((nperturbations, model.get_nhyperparameters())) - 0.5
    # )
    # initial_guess_perturbations[0, :] = 0.0
    initial_guess_perturbations = None

    print(">>>started learning curve building:", now())
    all_predictions = model.learning_curve_predictions(
        training_ensembles,
        training_quantities,
        test_ensembles,
        training_set_sizes,
        max_subset_num=1,
        hyperparameter_reoptimization=True,
        hyperparameter_optimization_kwargs={
            "initial_guess_perturbations": initial_guess_perturbations
        },
        training_nuclear_charges=training_nuclear_charges,
        test_nuclear_charges=test_nuclear_charges,
        rng=random,
    )

    print(">>>finished learning curve building:", now())
    for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
        mean_MAEs, _ = learning_curve_from_predictions(
            all_predictions, test_quantities, error_loss_function=loss
        )
        with open(f"learning_curve_{loss_name}.txt", "w") as f:
            for ntr, mean_MAE_val in zip(training_set_sizes, mean_MAEs):
                print(ntr, mean_MAE_val, file=f)


if __name__ == "__main__":
    main()
