#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython aSLATM_FreeSolv_full.py aSLATM_learn_FreeSolv_$seed $seed
done
