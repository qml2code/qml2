#!/bin/bash

ss_dir=simple_shifts

ss_dir_fo=simple_shifts_fo_scaffold
ss_dir_rfo=simple_shifts_rfo_scaffold
mkdir -p $ss_dir $ss_dir_fo $ss_dir_rfo


# One 80/20 frequency-ordered scaffold split instead of a learning curve, with
# group-based hyperparameter optimization. The deterministic split is a property of the
# grouping and the train size, not of a seed, so it is submitted once; a seed is still
# passed because the argument is positional.
cd $ss_dir_fo
spython ../aSLATM_FreeSolv_full.py aSLATM_fo_scaffold_FreeSolv_simple_shifts --fo_scaffold 274658 True
cd ../

for seed in 274658 20786 109790 478390
do
	spython aSLATM_FreeSolv_full.py aSLATM_learn_FreeSolv_$seed $seed False
	cd $ss_dir
	spython ../aSLATM_FreeSolv_full.py aSLATM_learn_FreeSolv_simple_shifts_$seed $seed True
	cd ../
	cd $ss_dir_rfo
	spython ../aSLATM_FreeSolv_full.py aSLATM_rfo_scaffold_FreeSolv_simple_shifts_$seed --rfo_scaffold $seed True
	cd ../
done
