#!/bin/bash

# K matrices
spython cMBDF_mixed_sorf_random_K_comparison.py cMBDF_mixed_sorf_random_K_comparison
