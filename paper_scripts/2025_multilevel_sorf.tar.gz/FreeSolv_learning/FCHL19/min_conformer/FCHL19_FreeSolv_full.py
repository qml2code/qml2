import os
import random
import sys

import numpy as np

from qml2.basic_utils import now
from qml2.dataset_formats.FreeSolv import get_free_solvation_energies
from qml2.ensemble import Ensemble
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import (
    ElementAugmentedLocalRepresentationCalc,
    ProcessedRepresentationListCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    MinConformerRepresentationCalc,
    local_dn_rep_conformers_list_dict2data,
)
from qml2.representations import generate_fchl19
from qml2.utils import get_sorted_elements, roundup_power2

if len(sys.argv) > 1:
    seed = int(sys.argv[1])
else:
    seed = 274658

random.seed(seed)

containing_folder = os.environ["DATA"] + "/FreeSolv/FreeSolv-0.51"

r_cut = 0.05
num_conformers = 32

savefile_folder = (
    containing_folder
    + "/savefiles_FCHL19_rcut_"
    + str(r_cut)
    + "_num_conformers_"
    + str(num_conformers)
)

try:
    os.mkdir(savefile_folder)
except FileExistsError:
    print("savefile folder already created")


# Import all data .
all_data = get_free_solvation_energies(containing_folder=containing_folder)

all_SMILES = sorted(list(all_data.keys()))
num_mols = len(all_SMILES)

# NOTE: the total number of molecules is 642
training_set_size = 514
nfeatures = 32768

random.shuffle(all_SMILES)

# For now running without statistical errors

ensemble_kwargs = {
    "base_class_name": "Compound",
    "num_conformers": num_conformers,
    "r_cut": r_cut,
}

ensembles = []
quant_vals = []

all_nuclear_charges = []
present_nuclear_charges = []

for SMILES in all_SMILES:
    changed_SMILES = SMILES.replace("/", "_")
    ensemble = Ensemble(
        SMILES=SMILES, savefile_prefix=savefile_folder + "/" + changed_SMILES, **ensemble_kwargs
    )

    current_nuclear_charges = ensemble.get_nuclear_charges()
    present_nuclear_charges += list(current_nuclear_charges)

    all_nuclear_charges.append(current_nuclear_charges)

    quant_vals.append(all_data[SMILES][0])
    ensembles.append(ensemble)


print("Number of usable ensembles:", len(ensembles))

present_nuclear_charges = get_sorted_elements(np.array(present_nuclear_charges))

print("Present nuclear charges:", present_nuclear_charges)

quant_vals = np.array(quant_vals)

rep_calculator = ElementAugmentedLocalRepresentationCalc(
    representation_function=generate_fchl19,
    possible_nuclear_charges=present_nuclear_charges,
    representation_function_kwargs={"elements": present_nuclear_charges},
)

ensemble_rep_calculator = MinConformerRepresentationCalc(rep_calculator)

parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

processed_conformer_lists = parallel_calculator(ensembles)

processed_conformer_lists = local_dn_rep_conformers_list_dict2data(processed_conformer_lists)

component_bounds = parallel_calculator.component_bounds

print(component_bounds)

max_component_bound = parallel_calculator.max_component_bound()
print(max_component_bound)

init_size = roundup_power2(max_component_bound)
print("SORF init_size", init_size)

nfeature_stacks = nfeatures // init_size

print("nfeature_stacks:", nfeature_stacks)

training_conformer_lists = processed_conformer_lists[:training_set_size]
training_quantities = quant_vals[:training_set_size]

test_conformer_lists = processed_conformer_lists[training_set_size:]
test_quantities = quant_vals[training_set_size:]

training_nuclear_charges = all_nuclear_charges[:training_set_size]
test_nuclear_charges = all_nuclear_charges[training_set_size:]

function_definition_list = [
    "resize",
    "sorf",
    "element_id_switch",
    "component_sum",
    "component_sum",
]

ntransforms = 3

parameter_list = [
    {"output_size": init_size},
    {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
    {"num_element_ids": len(present_nuclear_charges)},
    {},
    {},
]

model = MultilevelSORFModel(
    function_definition_list,
    parameter_list,
    intensive_quantity_shift=False,
    extensive_quantity_shift=True,
)


training_set_sizes = [50, 100, 200, 400, training_set_size]

# nperturbations = 4
# initial_guess_perturbations = (
#    np.random.random((nperturbations, model.get_nhyperparameters())) - 0.5
# )
# initial_guess_perturbations[0, :] = 0.0
initial_guess_perturbations = None

print(">>>started learning curve building:", now())
mean_MAE, std_MAE = model.learning_curve(
    training_conformer_lists,
    training_quantities,
    test_conformer_lists,
    test_quantities,
    training_set_sizes,
    max_subset_num=1,
    hyperparameter_reoptimization=True,
    hyperparameter_optimization_kwargs={
        "initial_guess_perturbations": initial_guess_perturbations
    },
    training_nuclear_charges=training_nuclear_charges,
    test_nuclear_charges=test_nuclear_charges,
    rng=random,
)
print(">>>finished learning curve building:", now())
with open("learning_curve.txt", "w") as f:
    for ntr, mean_MAE_val in zip(training_set_sizes, mean_MAE):
        print(ntr, mean_MAE_val, file=f)
