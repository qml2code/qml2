#!/bin/bash

# K matrices
spython FCHL19_random_K_comparison.py FCHL19_random_K_comparison
