#!/bin/bash

# Learning curves scale poorly across every core this node reports, so ask spython for a
# smaller allocation than the hardware. An explicit --CPUs= would still override this.
export SPYTHON_ASSUMED_NCPUS=16

# FJD unless --fjk is passed, which selects the representation the paper used. The job name
# follows the choice: spython refuses to reuse an existing data directory, so the two must
# not land on the same one -- and under --fjk the names come out exactly as they were.
if [ "$1" == "--fjk" ]
then
    rep=FJK
    rep_flag=--fjk
else
    rep=FJD
    rep_flag=
fi

ss_dir=simple_shifts
# Same shifts, but learning the residual against the hydration free energy the pair's own
# two determinants already give, instead of the experimental value itself.
ss_dml_dir=simple_shifts_dml

ss_dir_fo=simple_shifts_fo_scaffold
ss_dir_rfo=simple_shifts_rfo_scaffold
ss_dml_dir_fo=simple_shifts_dml_fo_scaffold
ss_dml_dir_rfo=simple_shifts_dml_rfo_scaffold
mkdir -p $ss_dir $ss_dml_dir $ss_dir_fo $ss_dir_rfo $ss_dml_dir_fo $ss_dml_dir_rfo


# One 80/20 frequency-ordered scaffold split instead of a learning curve, with
# group-based hyperparameter optimization. The deterministic split is a property of the
# grouping and the train size, not of a seed, so it is submitted once; a seed is still
# passed because the argument is positional.
cd $ss_dir_fo
spython ../FJK_mixed_sorf_FreeSolv_full.py ${rep}_mixed_sorf_fo_scaffold_FreeSolv_simple_shifts $rep_flag --fo_scaffold 274658 True
cd ../
cd $ss_dml_dir_fo
spython ../FJK_mixed_sorf_FreeSolv_full.py ${rep}_mixed_sorf_fo_scaffold_FreeSolv_simple_shifts_dml $rep_flag --delta-ml --fo_scaffold 274658 True
cd ../

for seed in 274658 20786 109790 478390
do
	spython FJK_mixed_sorf_FreeSolv_full.py ${rep}_mixed_sorf_learn_FreeSolv_$seed $rep_flag $seed False
	cd $ss_dir
	spython ../FJK_mixed_sorf_FreeSolv_full.py ${rep}_mixed_sorf_learn_FreeSolv_simple_shifts_$seed $rep_flag $seed True
	cd ../
	cd $ss_dml_dir
	spython ../FJK_mixed_sorf_FreeSolv_full.py ${rep}_mixed_sorf_learn_FreeSolv_simple_shifts_dml_$seed $rep_flag --delta-ml $seed True
	cd ../
	cd $ss_dir_rfo
	spython ../FJK_mixed_sorf_FreeSolv_full.py ${rep}_mixed_sorf_rfo_scaffold_FreeSolv_simple_shifts_$seed $rep_flag --rfo_scaffold $seed True
	cd ../
	cd $ss_dml_dir_rfo
	spython ../FJK_mixed_sorf_FreeSolv_full.py ${rep}_mixed_sorf_rfo_scaffold_FreeSolv_simple_shifts_dml_$seed $rep_flag --delta-ml --rfo_scaffold $seed True
	cd ../
done
