#!/bin/bash

# FJD unless --fjk is passed, which selects the representation the paper used. The job name
# follows the choice: spython refuses to reuse an existing data directory, so the two must
# not land on the same one -- and under --fjk the names come out exactly as they were.
if [ "$1" == "--fjk" ]
then
    rep=FJK
    rep_flag=--fjk
else
    rep=FJD
    rep_flag=
fi

for ntransforms in 7 6 5 4 3 2 1
do
    sleep 1
    spython FJK_mixed_sorf_random_K_comparison.py ${rep}_mixed_sorf_random_K_check_$ntransforms $rep_flag $ntransforms $(pwd)/benchmark_K.pkl
done
