import os
import random
import sys

import numpy as np

from qml2.basic_utils import dump2pkl, loadpkl
from qml2.dataset_formats.FreeSolv import get_free_solvation_energies
from qml2.ensemble import Ensemble
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import ProcessedRepresentationListCalc
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    EnsembleRepresentationCalc,
    fjk_comp_ensemble_list_dict2datatype,
)
from qml2.multilevel_sorf.processed_object_constructors.fjk import FJKRepresentationCalc
from qml2.orb_ml.representations import OML_rep_params

# if len(sys.argv) > 1:
#    seed = int(sys.argv[1])
# else:
seed = 274658
random.seed(seed)

containing_folder = os.environ["DATA"] + "/FreeSolv/MobleyLab-FreeSolv-9d8a809"

use_Huckel = True
basis = "6-311G"  # "sto-3g"
solvent = "water"
r_cut = 0.05
num_conformers = 32

savefile_folder = (
    containing_folder
    + "/savefiles_FJK_pair_Huckel_"
    + str(use_Huckel)
    + "_basis_"
    + str(basis)
    + "_r_cut_"
    + str(r_cut)
    + "_solvent_"
    + solvent
    + "_nconfs_"
    + str(num_conformers)
)

try:
    os.mkdir(savefile_folder)
except FileExistsError:
    print("savefile folder already created")


# Import all data .
all_data = get_free_solvation_energies(containing_folder=containing_folder)

all_SMILES = sorted(list(all_data.keys()))
num_mols = len(all_SMILES)

# NOTE: the total number of molecules is 642
training_set_size = 514
nfeatures = 32768

random.shuffle(all_SMILES)

training_SMILES = all_SMILES[:training_set_size]

# For now running without statistical errors
comp_extra_kwargs = {
    "use_Huckel": use_Huckel,
    "basis": basis,
    "localization_procedure": "Boys",
    "second_oml_comp_kwargs": {"smd_solvent": solvent},
}

ensemble_kwargs = {
    "base_class_name": "OML_Slater_pair",
    "compound_kwargs": comp_extra_kwargs,
    "num_conformers": num_conformers,
    "r_cut": r_cut,
}

training_ensembles = []

for SMILES in training_SMILES:
    changed_SMILES = SMILES.replace("/", "_")
    ensemble = Ensemble(
        SMILES=SMILES, savefile_prefix=savefile_folder + "/" + changed_SMILES, **ensemble_kwargs
    )

    training_ensembles.append(ensemble)

rep_params = OML_rep_params(max_angular_momentum=1)

orb_rep_calculator = FJKRepresentationCalc(oml_rep_params=rep_params)

ensemble_orb_rep_calculator = EnsembleRepresentationCalc(orb_rep_calculator)

parallel_calculator = ProcessedRepresentationListCalc(ensemble_orb_rep_calculator)

processed_ensemble_slater_pair_dicts = parallel_calculator(training_ensembles)

processed_slater_pairs = fjk_comp_ensemble_list_dict2datatype(processed_ensemble_slater_pair_dicts)

component_bounds = parallel_calculator.component_bounds

print(component_bounds)

max_component_bound = parallel_calculator.max_component_bound()
print(max_component_bound)

init_size = nfeatures
assert init_size >= max_component_bound
print("SORF init_size", init_size)

nfeature_stacks = nfeatures // init_size

print("nfeature_stacks:", nfeature_stacks)


def get_K(ntransforms, sigmas):
    function_definition_list = [
        "resize",
        "rescaling",
        "unscaled_sorf",
        "weighted_component_sum",
        "normalization",
        "sorf",
        "weighted_component_sum",
        "mixed_extensive_sorf",
        "weighted_component_sum",
        "component_sum",
        "mixed_extensive_sorf",
    ]

    parameter_list = [
        {"output_size": init_size},
        {"resc_bounds": parallel_calculator.component_bounds},
        {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
        {},
        {},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
        {},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
        {},
        {},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
    ]

    model = MultilevelSORFModel(
        function_definition_list,
        parameter_list,
    )
    mSORF = model.MultilevelSORF
    if sigmas is None:
        sigmas = mSORF.hyperparameter_initial_guesses(processed_slater_pairs)
    thread_assignments = model.calc_thread_assignments(processed_slater_pairs)
    Z_matrix = mSORF.calc_Z_matrix(
        processed_slater_pairs, sigmas, thread_assignments=thread_assignments
    )
    K = np.dot(Z_matrix, Z_matrix.T)

    return K, sigmas


nmats = 8

ntransforms = int(sys.argv[1])

max_ntransforms = 7

bench_pkl = sys.argv[2]

if ntransforms == max_ntransforms:
    K_bench = None
    K_std_bench = None
    sigmas = None
else:
    K_bench, K_std_bench, sigmas = loadpkl(bench_pkl)

K_new = np.zeros((nmats, training_set_size, training_set_size))
for i_mat in range(nmats):
    K_new[i_mat, :, :], sigmas = get_K(ntransforms, sigmas)

K_mean = np.mean(K_new, axis=0)
K_std_new = np.std(K_new, axis=0) / np.sqrt(float(nmats))

if K_bench is None:
    dump2pkl((K_new, K_std_new, sigmas), bench_pkl)
    quit()

diff = np.sqrt(np.mean((K_mean - K_bench) ** 2))
st_diff = np.sqrt(np.mean(K_std_new**2 + K_std_bench**2))
print("===", ntransforms, diff, st_diff, np.mean(np.abs(K_mean)))

print(K_mean.shape, K_std_new.shape)
