import os
import random
import sys

import numpy as np

from qml2.dataset_formats.FreeSolv import get_free_solvation_energies
from qml2.ensemble import Ensemble
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import ProcessedRepresentationListCalc
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    EnsembleGlobalRepresentationCalc,
    global_rep_ensemble_list_dict2datatype,
)
from qml2.multilevel_sorf.processed_object_constructors.standard import GlobalRepresentationCalc
from qml2.representations import generate_coulomb_matrix

if len(sys.argv) > 1:
    seed = int(sys.argv[1])
else:
    seed = 274658
random.seed(seed)

containing_folder = os.environ["DATA"] + "/FreeSolv/MobleyLab-FreeSolv-9d8a809"

r_cut = 0.05
num_conformers = 32

savefile_folder = (
    containing_folder
    + "/savefiles_CM_rcut_"
    + str(r_cut)
    + "_num_conformers_"
    + str(num_conformers)
)

try:
    os.mkdir(savefile_folder)
except FileExistsError:
    print("savefile folder already created")


# Import all data .
all_data = get_free_solvation_energies(containing_folder=containing_folder)

all_SMILES = sorted(list(all_data.keys()))
num_mols = len(all_SMILES)

# NOTE: the total number of molecules is 642
training_set_size = 514
nfeatures = 32768

random.shuffle(all_SMILES)

training_SMILES = all_SMILES[:training_set_size]

# For now running without statistical errors

ensemble_kwargs = {
    "base_class_name": "Compound",
    "num_conformers": num_conformers,
    "r_cut": r_cut,
}

training_ensembles = []

size = 0

for SMILES in training_SMILES:
    changed_SMILES = SMILES.replace("/", "_")
    ensemble = Ensemble(
        SMILES=SMILES, savefile_prefix=savefile_folder + "/" + changed_SMILES, **ensemble_kwargs
    )

    current_nuclear_charges = ensemble.get_nuclear_charges()

    size = max(size, len(current_nuclear_charges))

    training_ensembles.append(ensemble)

rep_calculator = GlobalRepresentationCalc(
    generate_coulomb_matrix, representation_function_kwargs={"size": size}
)

ensemble_rep_calculator = EnsembleGlobalRepresentationCalc(rep_calculator)

parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

training_ensemble_dicts = parallel_calculator(training_ensembles)

processed_ensembles = global_rep_ensemble_list_dict2datatype(training_ensemble_dicts)

component_bounds = parallel_calculator.component_bounds

print("Component bounds")
print(component_bounds)
max_component_bound = parallel_calculator.max_component_bound()
print(max_component_bound)

init_size = nfeatures
assert init_size >= max_component_bound
print("SORF init_size", init_size)

nfeature_stacks = nfeatures // init_size

print("nfeature_stacks:", nfeature_stacks)


def get_K(ntransforms, sigmas):
    function_definition_list = [
        "resize",
        "sorf",
        "weighted_component_sum",
        "normalization",
        "component_sum",
        "sorf",
    ]

    parameter_list = [
        {"output_size": init_size},
        {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
        {},
        {},
        {},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
    ]

    model = MultilevelSORFModel(
        function_definition_list,
        parameter_list,
    )
    mSORF = model.MultilevelSORF
    if sigmas is None:
        sigmas = mSORF.hyperparameter_initial_guesses(processed_ensembles)
    Z_matrix = mSORF.calc_Z_matrix(processed_ensembles, sigmas)
    K = np.dot(Z_matrix, Z_matrix.T)

    return K, sigmas


nmats = 8

K_bench = None
K_std_bench = None
sigmas = None

for ntransforms in [7, 6, 5, 4, 3, 2, 1]:
    K_new = np.zeros((nmats, training_set_size, training_set_size))
    for i_mat in range(nmats):
        K_new[i_mat, :, :], sigmas = get_K(ntransforms, sigmas)
    K_mean = np.mean(K_new, axis=0)
    K_std_new = np.std(K_new, axis=0) / np.sqrt(float(nmats))
    if K_bench is None:
        K_bench = K_mean
        K_std_bench = K_std_new
    else:
        diff = np.sqrt(np.mean((K_mean - K_bench) ** 2))
        print(
            "###",
            ntransforms,
            diff,
            np.sqrt(np.mean(K_std_new**2 + K_std_bench**2)),
            np.mean(np.abs(K_mean)),
        )


print(K_mean.shape, K_std_new.shape)
