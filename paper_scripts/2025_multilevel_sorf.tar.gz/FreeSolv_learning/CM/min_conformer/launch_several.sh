#!/bin/bash

# Learning curves scale poorly across every core this node reports, so ask spython for a
# smaller allocation than the hardware. An explicit --CPUs= would still override this.
export SPYTHON_ASSUMED_NCPUS=16

ss_dir=simple_shifts

ss_dir_fo=simple_shifts_fo_scaffold
ss_dir_rfo=simple_shifts_rfo_scaffold
mkdir -p $ss_dir $ss_dir_fo $ss_dir_rfo


# One 80/20 frequency-ordered scaffold split instead of a learning curve, with
# group-based hyperparameter optimization. The deterministic split is a property of the
# grouping and the train size, not of a seed, so it is submitted once; a seed is still
# passed because the argument is positional.
cd $ss_dir_fo
spython ../CM_min_conf_FreeSolv_full.py CM_fo_scaffold_FreeSolv_min_conf_simple_shifts --fo_scaffold 274658 True
cd ../

for seed in 274658 20786 109790 478390
do
	spython CM_min_conf_FreeSolv_full.py CM_learn_FreeSolv_min_conf_$seed $seed False
	cd $ss_dir
	spython ../CM_min_conf_FreeSolv_full.py CM_learn_FreeSolv_min_conf_simple_shifts_$seed $seed True
	cd ../
	cd $ss_dir_rfo
	spython ../CM_min_conf_FreeSolv_full.py CM_rfo_scaffold_FreeSolv_min_conf_simple_shifts_$seed --rfo_scaffold $seed True
	cd ../
done
