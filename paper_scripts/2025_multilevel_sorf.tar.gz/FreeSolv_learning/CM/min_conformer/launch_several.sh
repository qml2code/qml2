#!/bin/bash

ns_dir=no_shifts

mkdir -p $ns_dir

for seed in 274658 20786 109790 478390
do
	spython CM_min_conf_FreeSolv_full.py CM_learn_FreeSolv_min_conf_$seed $seed False
	cd $ns_dir
	spython ../CM_min_conf_FreeSolv_full.py CM_learn_FreeSolv_min_conf_no_shifts_$seed $seed True
	cd ../
done
