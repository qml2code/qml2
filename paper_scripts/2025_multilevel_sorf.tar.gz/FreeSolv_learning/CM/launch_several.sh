#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython CM_FreeSolv_full.py CM_learn_FreeSolv_$seed $seed
done
