#!/bin/bash

# K matrices
spython SOAP_random_K_comparison.py SOAP_random_K_comparison
