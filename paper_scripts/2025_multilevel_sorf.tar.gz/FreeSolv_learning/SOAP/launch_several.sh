#!/bin/bash

ns_dir=no_shifts

mkdir -p $ns_dir

for seed in 274658 20786 109790 478390
do
	spython SOAP_FreeSolv_full.py SOAP_learn_FreeSolv_$seed $seed False
	cd $ns_dir
	spython ../SOAP_FreeSolv_full.py SOAP_learn_FreeSolv_no_shifts_$seed $seed True
	cd ../
done
