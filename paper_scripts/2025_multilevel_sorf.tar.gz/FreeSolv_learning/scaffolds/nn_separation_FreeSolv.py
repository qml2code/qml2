"""Does scaffold splitting actually separate test from train, for FreeSolv?

A DIAGNOSTIC. It trains nothing and changes nothing in the pipeline; it answers one
question before any learning-curve CPU is spent on frequency-ordered splits: does holding
out whole scaffolds push the test set further from the training set in feature space than
a plain random split does?

The measure is the standard one. For every TEST molecule, take its nearest neighbour in
the TRAINING set and record that similarity; the distribution of those values over the
test set is how close the test set sits to what the model saw. A split that separates
shifts the distribution DOWN relative to a random split. A split that does not is
cosmetic, however principled it sounds.

The measurement itself lives in qml2.cheminfo.nn_separation; what is here is this paper's
particular comparison -- which splits, which seeds, how it is summarized and plotted.

Every grouping is swept, as in scaffold_distribution_*.py -- the diagnostic runs in
seconds, so there is no reason to inspect one setting and guess about the rest. Whether a
grouping is DEGENERATE for the random-tie split (all seeds collapsing to one split) is
reported by scaffold_distribution_*.py, not here; where it is, the random-tie and
deterministic rows below will simply coincide.

Three splits per grouping, at 80/20:

  random-molecule       plain random 80/20, pooled over the four paper seeds
  random-tie scaffold   frequency_ordered_group_split(shuffle_ties=True), same four seeds
  deterministic scaffold frequency_ordered_group_split(shuffle_ties=False), one split

Pooling the random modes over their four draws matters: a single draw of either is one
sample of a distribution, and comparing one draw against one draw would mostly measure
draw-to-draw noise.

Two feature spaces, selected by flag:

  ECFP4 / Tanimoto (default)   the field-standard yardstick, and what the critique
                               literature uses, so it is the comparable number.
  --slatm                      global SLATM with the l2 distance the models use, reporting
                               raw nearest-neighbour DISTANCE (scale-free -- only the
                               comparison across splits matters, so no sigma is chosen).
                               Note the geometry caveat in slatm_representations: one
                               embedded conformer per molecule, not the pipeline's morfeus
                               ensembles.

Interpretation (Tanimoto/ECFP4 conventions):

  >= 0.7  very similar, likely an analogue     >= 0.4  similar     < 0.3  structurally distinct

Verdict rule of thumb: if the deterministic scaffold split's median_nn_sim is visibly
below the random split's AND its frac_held_out is higher, the split is doing real
separation and the paper can cite it as addressing the data-distribution concern with a
standard technique. If the distributions coincide, scaffold splitting is cosmetic FOR THAT
DATASET, so the two datasets get separate verdicts rather than a combined one.

Caveat worth stating in the text: this measures separation in ECFP space (or the chosen
representation), the field-standard proxy. It does not by itself prove separation in every
possible feature space.

The Mann-Whitney U p-values attached below test whether the distributions differ. They are
distributional tests, not performance claims; do not over-interpret them.
"""

import csv
import os
import sys

import matplotlib

# Chosen before pyplot is imported: this runs on a headless node and must never block.
matplotlib.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from scipy.stats import mannwhitneyu  # noqa: E402

from qml2.cheminfo.nn_separation import (  # noqa: E402
    ecfp4_fingerprints,
    nearest_neighbour_similarities,
    slatm_representations,
)
from qml2.cheminfo.scaffolds import scaffold_group_ids  # noqa: E402
from qml2.dataset_formats.FreeSolv import get_free_solvation_energies  # noqa: E402
from qml2.models.kfolds import frequency_ordered_group_split  # noqa: E402
from qml2.utils import nearest_neighbour_distances  # noqa: E402


def load_SMILES():
    containing_folder = os.environ["DATA"] + "/FreeSolv/MobleyLab-FreeSolv-9d8a809"
    all_data = get_free_solvation_energies(containing_folder=containing_folder)
    all_SMILES = sorted(list(all_data.keys()))
    # The same guard the learning-curve scripts use: a silently truncated dataset would
    # make every number below wrong in a way that still looks plausible.
    assert len(all_SMILES) == 642
    return all_SMILES


RESULTS_DIR = "scaffold_results"

# The seeds the random-split learning curves already use.
SHUFFLING_SEEDS = (274658, 20786, 109790, 478390)
TRAIN_FRACTION = 0.8

# Every grouping, as in scaffold_distribution_*.py -- the diagnostic is cheap enough that
# there is no reason to look at one setting and guess about the others. Which grouping is
# usable at all (some are degenerate for the random-tie split) is reported there, not here.
ACYCLIC_VALUES = ["pool", "skeleton", "singleton"]
INCLUDE_CHIRALITY_VALUES = [False, True]

# Tanimoto conventions; see the module docstring.
SIMILAR_THRESHOLD = 0.4
NEAR_DUPLICATE_THRESHOLD = 0.7

SPLIT_NAMES = ["random-molecule", "random-tie scaffold", "deterministic scaffold"]


def random_molecule_split(npoints, train_size, rng):
    """Plain random 80/20 -- the baseline every scaffold split is judged against."""
    shuffled = rng.permutation(npoints)
    return np.sort(shuffled[:train_size]), np.sort(shuffled[train_size:])


def nearest_neighbour_values(features, use_slatm, train_indices, test_indices):
    """Whichever measure the selected metric calls for."""
    if use_slatm:
        return nearest_neighbour_distances(features, train_indices, test_indices)
    return nearest_neighbour_similarities(features, train_indices, test_indices)


def random_baseline_values(npoints, train_size, features, use_slatm):
    """The random-molecule baseline, pooled over the seeds.

    Computed ONCE for the whole sweep: a plain random split does not consult the scaffold
    grouping, so this is identical for every (acyclic, include_chirality) combination.
    Recomputing it per combination would only burn time and invite the reader to think the
    baseline moved.
    """
    return np.concatenate(
        [
            nearest_neighbour_values(
                features,
                use_slatm,
                *random_molecule_split(npoints, train_size, np.random.default_rng(seed)),
            )
            for seed in SHUFFLING_SEEDS
        ]
    )


def collect_split_values(group_ids, train_size, features, use_slatm, random_values):
    """The nearest-neighbour values for each split variant, pooled over draws."""
    collected = {"random-molecule": random_values}

    collected["random-tie scaffold"] = np.concatenate(
        [
            nearest_neighbour_values(
                features,
                use_slatm,
                *frequency_ordered_group_split(
                    group_ids, train_size, shuffle_ties=True, rng=np.random.default_rng(seed)
                ),
            )
            for seed in SHUFFLING_SEEDS
        ]
    )
    collected["deterministic scaffold"] = nearest_neighbour_values(
        features, use_slatm, *frequency_ordered_group_split(group_ids, train_size)
    )
    return collected


def summarize(values, use_slatm):
    """The headline numbers. Fixed similarity thresholds mean nothing for a raw distance,
    so that metric reports percentiles instead."""
    if use_slatm:
        return {
            "median_nn_dist": float(np.median(values)),
            "mean_nn_dist": float(np.mean(values)),
            "p10_nn_dist": float(np.percentile(values, 10)),
            "p90_nn_dist": float(np.percentile(values, 90)),
        }
    return {
        "median_nn_sim": float(np.median(values)),
        "mean_nn_sim": float(np.mean(values)),
        "frac_leaked_0.4": float(np.mean(values >= SIMILAR_THRESHOLD)),
        "frac_leaked_0.7": float(np.mean(values >= NEAR_DUPLICATE_THRESHOLD)),
        "frac_held_out": float(np.mean(values < SIMILAR_THRESHOLD)),
    }


def write_summary_csv(rows, filename):
    """One table for the whole sweep.

    A file per combination would match scaffold_distribution_*.py, but there each file is a
    histogram of a different length; here every combination contributes three rows of the
    same fields, and comparing across parameters is the entire point of sweeping them.
    """
    metric_columns = [
        key for key in rows[0] if key not in ("acyclic", "include_chirality", "split")
    ]
    columns = ["acyclic", "include_chirality", "split"] + metric_columns
    with open(filename, "w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(columns)
        for row in rows:
            writer.writerow([row[column] for column in columns])


def write_values_csv(value_rows, filename):
    """Every value the histograms are drawn from, one row per molecule.

    write_summary_csv keeps the headline statistics; this keeps the distributions themselves,
    so the figure can be redrawn -- differently binned, as a violin or an ECDF -- without
    recomputing the representations and the nearest-neighbour search.
    """
    with open(filename, "w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["acyclic", "include_chirality", "split", "value"])
        writer.writerows(value_rows)


def make_plot(collected, filename_stem, use_slatm):
    """Overlaid histograms with medians marked -- the visual answer in one panel."""
    label = (
        "nearest-neighbour l2 distance"
        if use_slatm
        else "test->train nearest-neighbour Tanimoto similarity"
    )
    every_value = np.concatenate([collected[name] for name in SPLIT_NAMES])
    bins = np.linspace(every_value.min(), every_value.max(), 40)

    figure, axes = plt.subplots(figsize=(7.0, 4.2))
    colors = ["tab:blue", "tab:orange", "tab:green"]
    for split_name, color in zip(SPLIT_NAMES, colors):
        values = collected[split_name]
        axes.hist(values, bins=bins, alpha=0.45, density=True, label=split_name, color=color)
        axes.axvline(
            np.median(values),
            color=color,
            linestyle="--",
            linewidth=1.6,
            label=f"{split_name} median = {np.median(values):.3f}",
        )
    if not use_slatm:
        axes.axvline(SIMILAR_THRESHOLD, color="black", linestyle=":", linewidth=1.2)
        axes.text(
            SIMILAR_THRESHOLD,
            axes.get_ylim()[1] * 0.95,
            "  similar (0.4)",
            fontsize=8,
            va="top",
        )
    axes.set_xlabel(label)
    axes.set_ylabel("density")
    axes.set_title(f"FreeSolv: test-set separation ({os.path.basename(filename_stem)})")
    axes.legend(fontsize=7)
    figure.tight_layout()
    for extension in ("pdf", "png"):
        figure.savefig(f"{filename_stem}.{extension}", dpi=150)
    plt.close(figure)


def main():
    use_slatm = "--slatm" in sys.argv
    metric_name = "slatm" if use_slatm else "ecfp4"

    all_SMILES = load_SMILES()
    os.makedirs(RESULTS_DIR, exist_ok=True)
    npoints = len(all_SMILES)
    train_size = int(round(TRAIN_FRACTION * npoints))

    print("DATASET: FreeSolv")
    print(f"MOLECULES: {npoints}")
    print(f"METRIC: {metric_name} train_fraction={TRAIN_FRACTION} seeds={len(SHUFFLING_SEEDS)}")
    print()

    # Features do not depend on the grouping either, so they are built once for the sweep.
    features = slatm_representations(all_SMILES) if use_slatm else ecfp4_fingerprints(all_SMILES)
    random_values = random_baseline_values(npoints, train_size, features, use_slatm)

    rows = []

    value_rows = []
    for include_chirality in INCLUDE_CHIRALITY_VALUES:
        for acyclic in ACYCLIC_VALUES:
            group_ids = scaffold_group_ids(
                all_SMILES, acyclic=acyclic, include_chirality=include_chirality
            )
            collected = collect_split_values(
                group_ids, train_size, features, use_slatm, random_values
            )
            summaries = {name: summarize(collected[name], use_slatm) for name in SPLIT_NAMES}

            print(f"PARAMETERS: acyclic={acyclic} include_chirality={include_chirality}")
            for split_name in SPLIT_NAMES:
                fields = " ".join(
                    f"{key}={value:.4f}" for key, value in summaries[split_name].items()
                )
                print(
                    f"SUMMARY: split={split_name!r}"
                    f" n_values={collected[split_name].shape[0]} {fields}"
                )
                rows.append(
                    {
                        "acyclic": acyclic,
                        "include_chirality": include_chirality,
                        "split": split_name,
                        **summaries[split_name],
                    }
                )

            for split_name in SPLIT_NAMES[1:]:
                statistic, p_value = mannwhitneyu(
                    random_values, collected[split_name], alternative="two-sided"
                )
                print(
                    f"MANNWHITNEY: random-molecule vs {split_name!r}"
                    f" U={statistic:.1f} p={p_value:.3e}"
                )

            for split_name in SPLIT_NAMES:
                value_rows.extend(
                    (acyclic, include_chirality, split_name, float(value))
                    for value in collected[split_name]
                )

            tag = f"{acyclic}_chirality_{include_chirality}"
            plot_stem = os.path.join(RESULTS_DIR, f"nn_separation_{metric_name}_{tag}")
            make_plot(collected, plot_stem, use_slatm)
            print(f"PLOT: {plot_stem}.pdf {plot_stem}.png")

            if not use_slatm:
                random_median = summaries["random-molecule"]["median_nn_sim"]
                scaffold_median = summaries["deterministic scaffold"]["median_nn_sim"]
                random_held = summaries["random-molecule"]["frac_held_out"]
                scaffold_held = summaries["deterministic scaffold"]["frac_held_out"]
                separates = (scaffold_median < random_median) and (scaffold_held > random_held)
                print(
                    f"VERDICT: separation_achieved={separates}"
                    f" median_nn_sim {random_median:.4f} -> {scaffold_median:.4f}"
                    f" frac_held_out {random_held:.4f} -> {scaffold_held:.4f}"
                )
            print()

    csv_file = os.path.join(RESULTS_DIR, f"nn_separation_{metric_name}.csv")
    write_summary_csv(rows, csv_file)
    print(f"SUMMARY_CSV: {csv_file} ({len(rows)} rows)")

    values_file = os.path.join(RESULTS_DIR, f"nn_separation_values_{metric_name}.csv")
    write_values_csv(value_rows, values_file)
    print(f"VALUES_CSV: {values_file} ({len(value_rows)} rows)")


if __name__ == "__main__":
    main()
