import os
import random
import sys
from copy import deepcopy
from typing import List

import numpy as np
from ase.atoms import Atoms
from dscribe.descriptors import SOAP

from qml2.basic_utils import dump2pkl, loadpkl, total_cpu_time
from qml2.compound_list import CompoundList
from qml2.dataset_formats.FreeSolv import get_free_solvation_energies
from qml2.ensemble import Ensemble
from qml2.math import cho_solve, inplace_orthogonalize_vectors, regression_using_Z
from qml2.models.krr import KRRLocalModel, KRRModel
from qml2.multilevel_sorf.base_constructors import get_transform_list_dict2datatype
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import ProcessedRepresentationListCalc
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    MinConformerRepresentationCalc,
    local_dn_rep_conformers_list_dict2data,
)
from qml2.multilevel_sorf.processed_object_constructors.fjk import FJKRepresentationCalc
from qml2.multilevel_sorf.processed_object_constructors.fjk import comp_rep_def as fjk_comp_rep_def
from qml2.multilevel_sorf.processed_object_constructors.fjk import (
    concatenated_pair_rep_def as fjk_concatenated_pair_rep_def,
)
from qml2.multilevel_sorf.processed_object_constructors.standard import (
    ElementAugmentedLocalRepresentationCalc,
    GlobalRepresentationCalc,
    LocalRepresentationCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.utils import (
    transform_2D_representations_into_principal_component_versions,
)
from qml2.orb_ml.models import FJKModel
from qml2.orb_ml.representations import OML_rep_params
from qml2.representations.calculators import (
    CMCalculator,
    FCHL19Calculator,
    SLATMCalculator,
    cMBDFCalculator,
)

global_reps = ["CM", "SLATM", "SLATM_projected"]

# The qml2 modules imported above are still called "fjk" -- FJD is a set of coupling
# matrices inside the same representation, selected with OML_rep_params(fjd_coup_mats=True),
# not a separate machinery -- so only the names of the runs change here.
fjd_pair_rep = "FJD"
fjd_sdet_rep = "FJD_sdet"
fjd_reps = [fjd_pair_rep, fjd_sdet_rep]

local_reps = ["SOAP"]

local_dn_reps = ["cMBDF", "FCHL19", "aSLATM"]

local_rep_conformers_list_dict2data = get_transform_list_dict2datatype(["array_2D", "list"])

fjk_rep_conformers_list_dict2data = get_transform_list_dict2datatype(fjk_comp_rep_def + ["list"])

# The concatenated pair keeps its two determinants apart, so a molecule is one level deeper:
# a list of min conformers, each of which is a list of TWO compound representations rather
# than one. Matches what FJK_FreeSolv_full.py feeds its learning curves, minus the conformer
# weighting this script does not use.
fjk_concatenated_pair_conformers_list_dict2data = get_transform_list_dict2datatype(
    fjk_concatenated_pair_rep_def + ["list"]
)

# max_angular_momentum=2 and fjd_coup_mats=True: FJD replaces FJK's exchange slot with two
# dipole-derived channels, and the learning curves this table is meant to describe are built
# at l=2. Both have to agree with FJK_FreeSolv_full.py and FJK_sdet_FreeSolv_full.py or the
# CPU times describe a model nobody ran.
default_oml_rep_params = OML_rep_params(max_angular_momentum=2, fjd_coup_mats=True)

#
solvent = "water"
# The tight-binding recipe, copied from the FJD branch of FJK_FreeSolv_full.py: no basis and
# no Huckel guess to name, and Pipek-Mezey because IAO/IBO is ill-posed on GFN2's
# valence-only occupied space. Duplicated rather than imported because spython copies this
# file alone into its job directory (see AGENTS.md).
common_fjd_kwargs = {
    "localization_procedure": "Pipek-Mezey",
    "calc_type": "gfn2-xtb",
    "software": "tblite",
}

# for FJD rep. The first determinant is the molecule in gas phase and the second the
# solvated one -- only the second carries smd_solvent -- so their difference has the sign of
# a hydration free energy.
pair_fjd_comp_extra_kwargs = {
    # NOTE: with "software": "tblite" this does NOT select SMD. The keyword is passed to
    # tblite's own ALPB model -- calculator.add("alpb-solvation", solvent) in
    # qml2/orb_ml/tblite_interface -- so what these runs used is ALPB, not SMD. A naming
    # oversight, not an attempt at a solvent model tblite does not have; see README.txt note 1.
    "compound_kwargs": {**common_fjd_kwargs, "second_oml_comp_kwargs": {"smd_solvent": solvent}},
    "base_class_name": "OML_Slater_pair",
}

fjd_comp_extra_kwargs = {
    "compound_kwargs": {
        **common_fjd_kwargs,
        "smd_solvent": solvent,
    },
    "base_class_name": "OML_Compound",
}

comp_extra_kwargs = {"base_class_name": "Compound"}

# The two stages this script runs as, selected by its first positional argument.
#
# The split is along the only line that matters for timing: what parallelizes over MOLECULES
# and what parallelizes INSIDE one operation. Conformer generation, the ab initio
# calculations and the representation function are the former -- each molecule is
# independent, and a GFN2 single point on one conformer is far too small for OpenMP to help
# (measured: four threads bought no wall time at all, 1.10 s against 1.02 s, while costing
# eight times the CPU, because several thread pools spin-wait and os.times() counts every
# spinning thread). They are therefore timed on ONE core, where the CPU time reported is the
# true serial cost and nothing has to be corrected for.
#
# The SORF feature vectors and the kernel are the latter: both are Numba `prange` over one
# large array, with no per-molecule decomposition to exploit, and OpenMP scales well enough
# there for the measurement to stay honest. They get the cores.
#
# Multiprocessing appears nowhere. Over molecules it would only duplicate what one core
# measures correctly, while charging a child interpreter's import and Numba compilation --
# about 2.5 s, plus 1.2 s per worker -- to the very number being measured.
#
# Both stages report CPU seconds, so their numbers add directly and neither needs scaling by
# a core count.
STAGE_REPRESENTATIONS = "representations"
STAGE_MODELS = "models"
STAGES = [STAGE_REPRESENTATIONS, STAGE_MODELS]


def get_possible_nuclear_charges(all_nuclear_charges):
    return np.unique(np.concatenate(all_nuclear_charges))


class CalcSOAP:
    def __init__(self, all_nuclear_charges, **kwargs):
        self.soap_func = SOAP(species=get_possible_nuclear_charges(all_nuclear_charges), **kwargs)

    def __call__(self, nuclear_charges, coordinates):
        comp = Atoms(nuclear_charges, coordinates)
        return self.soap_func.create(comp)


def do_with_timing(routine, *args, **other_kwargs):
    start_calc = total_cpu_time()
    output = routine(*args, **other_kwargs)
    finish_calc = total_cpu_time()
    return output, finish_calc - start_calc


def redo_with_timing(routine, *args, args_deepcopy=False, **other_kwargs):
    if args_deepcopy:
        used_args = deepcopy(args)
        used_kwargs = deepcopy(other_kwargs)
    else:
        used_args = args
        used_kwargs = other_kwargs
    # run to trigger jit compilation
    routine(*used_args, **used_kwargs)

    return do_with_timing(routine, *args, **other_kwargs)


def get_processed_representations(conformers, rep_name):
    if rep_name in global_reps:
        return np.array(conformers)
    elif rep_name in local_dn_reps:
        return local_dn_rep_conformers_list_dict2data(conformers)
    elif rep_name in local_reps:
        return local_rep_conformers_list_dict2data(conformers)
    elif rep_name == fjd_pair_rep:
        return fjk_concatenated_pair_conformers_list_dict2data(conformers)
    elif rep_name == fjd_sdet_rep:
        return fjk_rep_conformers_list_dict2data(conformers)
    else:
        raise Exception("Unknown representation!")


def get_compounds_from_ensembles(ensembles: List[Ensemble]) -> CompoundList:
    output_compounds = []
    for ensemble in ensembles:
        cur_filtered_conformer_list = ensemble.filtered_conformers[0]
        assert len(cur_filtered_conformer_list) == 1
        output_compounds.append(deepcopy(cur_filtered_conformer_list[0].compound))
    return CompoundList(output_compounds)


def get_rep_calculator(representation_name, all_nuclear_charges):
    representation_function_kwargs = {}
    if representation_name == "CM":
        rep_bare_calculator = CMCalculator(all_nuclear_charges=all_nuclear_charges)
    elif representation_name in ["SLATM", "aSLATM", "SLATM_projected"]:
        rep_bare_calculator = SLATMCalculator(all_nuclear_charges=all_nuclear_charges)
        representation_function_kwargs = {"local": representation_name == "aSLATM"}
    elif representation_name == "SOAP":
        # SOAP+KRR parameters from DOI:10.1063/5.0214754
        rep_bare_calculator = CalcSOAP(
            all_nuclear_charges, periodic=False, n_max=8, l_max=8, r_cut=9.53
        )
    elif representation_name == "FCHL19":
        rep_bare_calculator = FCHL19Calculator(all_nuclear_charges=all_nuclear_charges)
    elif representation_name == "cMBDF":
        rep_bare_calculator = cMBDFCalculator(all_nuclear_charges=all_nuclear_charges)
    elif representation_name in fjd_reps:
        rep_bare_calculator = None
    else:
        raise Exception("Unknown representation")

    if representation_name in global_reps:
        rep_calculator = GlobalRepresentationCalc(
            rep_bare_calculator, representation_function_kwargs=representation_function_kwargs
        )
    elif representation_name in local_dn_reps:
        rep_calculator = ElementAugmentedLocalRepresentationCalc(
            rep_bare_calculator,
            representation_function_kwargs=representation_function_kwargs,
            possible_nuclear_charges=get_possible_nuclear_charges(all_nuclear_charges),
        )
    elif representation_name in local_reps:
        rep_calculator = LocalRepresentationCalc(
            rep_bare_calculator, representation_function_kwargs=representation_function_kwargs
        )
    elif representation_name in fjd_reps:
        # The pair's two determinants are concatenated rather than subtracted, matching
        # FJK_FreeSolv_full.py. The single determinant has nothing to concatenate.
        rep_calculator = FJKRepresentationCalc(
            oml_rep_params=default_oml_rep_params,
            concatenate_components=representation_name == fjd_pair_rep,
        )

    return rep_calculator


def get_orthogonal_basis(representations):
    prev_shape = representations.shape
    assert len(prev_shape) == 3
    assert prev_shape[1] == 1
    basis = np.copy(representations).reshape((prev_shape[0], prev_shape[-1]))
    inplace_orthogonalize_vectors(basis)
    return basis


global_training_set_projector = None


def full_transform_to_orthogonal_basis(representations):
    old_reps_shape = representations.shape

    old_reps = representations.reshape((old_reps_shape[0], old_reps_shape[-1]))

    new_rep_shape = (old_reps_shape[0], global_training_set_projector.shape[0] + 1)

    new_reps = np.empty(new_rep_shape)

    transform_2D_representations_into_principal_component_versions(
        old_reps, new_reps, global_training_set_projector, add_remainder=True
    )

    return new_reps.reshape((new_rep_shape[0], 1, new_rep_shape[1]))


def perform_global_training_set_projection(representations, print_name):
    global global_training_set_projector
    if global_training_set_projector is None:
        global_training_set_projector, projector_timing = redo_with_timing(
            get_orthogonal_basis, representations
        )
        print(f"PROJECTOR_TIMING_{print_name}:", projector_timing)
    projected_representations, projection_timing = redo_with_timing(
        full_transform_to_orthogonal_basis, representations
    )
    print(f"PROJECTION_TIMING_{print_name}:", projection_timing)
    return projected_representations


def generate_all_conformers(ensembles: List[Ensemble]) -> None:
    """Morfeus/RDKit conformer generation for every ensemble, and nothing else."""
    for ensemble in ensembles:
        ensemble.init_filtered_conformers()


def run_all_quantum_calculations(ensembles: List[Ensemble]) -> None:
    """The ab initio half of run_calcs, with the conformers already in place.

    The split between this and generate_all_conformers is exact rather than approximate:
    init_filtered_conformers returns immediately once an ensemble has its conformers, and
    run_calcs returns immediately for a plain Compound. So a representation that needs no
    calculation is MEASURED as free here rather than assumed to be, and one that does gets
    the calculation alone rather than the calculation plus the conformer search.
    """
    for ensemble in ensembles:
        ensemble.run_calcs()


def representations_for_handoff(processed_ensembles, rep_name, print_name):
    """The representations in whatever form survives a pickle.

    The MSORF datatypes are Numba `typed.List`s of jitclasses, and pickling one fails with
    "cannot pickle '_nrt_python._MemInfo' object". So for those the handoff carries the
    plain dicts the calculator produced and the model stage finishes the conversion -- which
    costs nothing, being a relabelling rather than a computation.

    Global representations are Numpy arrays once converted and pickle as they are. They are
    converted HERE rather than in the model stage because SLATM_projected's projector is
    built by this conversion, and the compound branch below needs it to already exist.
    """
    if rep_name in global_reps:
        converted = get_processed_representations(processed_ensembles, rep_name)
        if rep_name == "SLATM_projected":
            converted = perform_global_training_set_projection(converted, print_name)
        return converted
    return processed_ensembles


def representations_from_handoff(stored_representations, rep_name):
    """Undo `representations_for_handoff`: finish the conversion if it was deferred."""
    if rep_name in global_reps:
        return stored_representations
    return get_processed_representations(stored_representations, rep_name)


def get_processed_ensembles(parallel_calculator, ensembles, rep_name, print_name):
    """Everything that is per-molecule, timed in three parts on one core.

    num_procs=1 throughout, with the job expected to hold a single core and every thread
    variable set to 1 -- see the stage comment at the top of this file for why that is the
    honest setting here rather than a concession.

    The representation is built BEFORE the compounds the kernel model needs. That order
    matters for SLATM_projected: the projector is created by the first call that processes a
    training set, and the compound branch below asserts that it already exists.
    """
    _, conformer_timing = do_with_timing(generate_all_conformers, ensembles)
    print(f"{print_name}_CONFORMER_GENERATION_TIME:", conformer_timing)

    _, quantum_timing = do_with_timing(run_all_quantum_calculations, ensembles)
    print(f"{print_name}_QUANTUM_CALCULATION_TIME:", quantum_timing)

    processed_ensembles, procession_timing = do_with_timing(
        parallel_calculator, ensembles, num_procs=1
    )

    final_processed_ensembles = representations_for_handoff(
        processed_ensembles, rep_name, print_name
    )

    print(f"{print_name}_REPRESENTATION_TIME:", procession_timing)

    processed_init_compounds = get_compounds_from_ensembles(ensembles)

    if rep_name in fjd_reps:
        for i in range(len(processed_init_compounds)):
            # With the rep_params the model actually uses: generate_orb_reps() defaults to
            # OML_rep_params(), which is neither FJD nor l=2.
            processed_init_compounds[i].generate_orb_reps(rep_params=default_oml_rep_params)
    else:
        rep_object = parallel_calculator.representation_object
        representation_function = rep_object.rep_calc.representation_function
        representation_function_kwargs = rep_object.rep_calc.representation_function_kwargs
        processed_init_compounds.generate_rep_from_func(
            representation_function, num_procs=1, **representation_function_kwargs
        )
        if rep_name == "SLATM_projected":
            assert global_training_set_projector is not None
            # All compounds in ONE call rather than one call each. The projection is a
            # matrix product against a (nfeatures x representation size) projector, and
            # feeding it a single row at a time turns one gemm into N gemv calls that
            # cannot block for cache: measured at 514 x 78789, 5.20 s against 0.82 s.
            # The cost is holding the stacked representations, the same size as the
            # representation matrix this function has already built.
            stacked_representations = np.array(
                [compound.representation for compound in processed_init_compounds]
            )
            projected_representations = full_transform_to_orthogonal_basis(
                stacked_representations.reshape(
                    (stacked_representations.shape[0], 1, stacked_representations.shape[1])
                )
            )
            del stacked_representations
            for i in range(len(processed_init_compounds)):
                processed_init_compounds[i].representation = projected_representations[i, 0, :]

    return final_processed_ensembles, processed_init_compounds


def get_msorf_definition_lists(representation_name, component_bounds, all_nuclear_charges):
    print("Component bounds")
    if representation_name == "SLATM_projected":
        component_bounds = np.array([[0, global_training_set_projector.shape[0] + 1]])

    print(component_bounds)
    max_component_bound = np.max(component_bounds)
    print("REPRESENTATION_SIZE:", max_component_bound)
    if representation_name in ["aSLATM", "SLATM"]:
        nfeatures = 131072
    else:
        nfeatures = 32768
    init_size = nfeatures
    assert init_size >= max_component_bound
    print("SORF_init_size:", init_size)

    nfeature_stacks = nfeatures // init_size

    assert (
        nfeature_stacks == 1
    )  # the decision to do it this way was made very late, hence the strangeness
    print("nfeature_stacks:", nfeature_stacks)

    ntransforms = 3

    sorf_params = {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms}

    resize_params = {"output_size": init_size}

    if representation_name in global_reps:
        function_definition_list = ["resize", "sorf", "component_sum"]

        parameter_list = [
            resize_params,
            sorf_params,
            {},
        ]
    elif representation_name in local_reps:
        function_definition_list = ["resize", "sorf", "component_sum", "component_sum"]
        parameter_list = [
            resize_params,
            sorf_params,
            {},
            {},
        ]

    elif representation_name in local_dn_reps:
        possible_nuclear_charges = get_possible_nuclear_charges(all_nuclear_charges)
        function_definition_list = [
            "resize",
            "sorf",
            "element_id_switch",
            "component_sum",
            "component_sum",
        ]

        parameter_list = [
            resize_params,
            sorf_params,
            {"num_element_ids": len(possible_nuclear_charges)},
            {},
            {},
        ]
    elif representation_name in fjd_reps:
        # The levels below the compound are the same for both: atomic contributions summed
        # into an orbital, orbitals summed into one determinant. The pair then has one level
        # more -- its two determinants are laid END TO END rather than having been
        # subtracted back in FJKRepresentationCalc -- and the trailing "component_sum"
        # belongs to the conformer level above either of them.
        function_definition_list = [
            "resize",
            "rescaling",
            "unscaled_sorf",
            "weighted_component_sum",
            "normalization",
            "sorf",
            "weighted_component_sum",
        ]
        parameter_list = [
            resize_params,
            {"resc_bounds": component_bounds},
            sorf_params,
            {},
            {},
            sorf_params,
            {},
        ]
        if representation_name == fjd_pair_rep:
            function_definition_list.append("concatenation")
            parameter_list.append({"num_components": 2})
            # Concatenation doubles the feature vector, and it is left doubled rather than
            # halved through init_size because this is the model FJK_FreeSolv_full.py builds
            # and these CPU times are meant to describe that model.
            print("SORF_final_size:", 2 * nfeatures)
        function_definition_list.append("component_sum")
        parameter_list.append({})

    else:
        raise Exception("Unknown representation")

    return function_definition_list, parameter_list


def transformed_model_kwargs(representation_name, component_bounds, **kwargs):
    new_kwargs = deepcopy(kwargs)
    hyperparameters = kwargs["hyperparameters"]
    del new_kwargs["hyperparameters"]

    if representation_name in fjd_reps:
        nsigmas = np.max(component_bounds)
        sigmas = np.empty(nsigmas)
        global_sigma = hyperparameters[-1]
        for sigma, sigma_bound in zip(hyperparameters[:-1], component_bounds):
            sigmas[sigma_bound[0] : sigma_bound[1]] = sigma
        # K.Karan.: NOTE: the sqrt(2.) factor is due to the (admittedly weird) way I defined sigmas in the original FJK paper.
        new_kwargs["sigmas"] = sigmas / np.sqrt(2.0)
        new_kwargs["global_sigma"] = global_sigma
    else:
        new_kwargs["sigma"] = hyperparameters[0]
    return new_kwargs


def get_krr_model(representation_name, component_bounds, **kwargs):
    final_model_kwargs = transformed_model_kwargs(representation_name, component_bounds, **kwargs)
    if representation_name in global_reps:
        return KRRModel(**final_model_kwargs)
    elif representation_name in local_dn_reps + local_reps:
        return KRRLocalModel(**final_model_kwargs, local_dn=representation_name in local_dn_reps)
    elif representation_name in fjd_reps:
        # The reference kernel has to combine a pair's determinants the same way the SORF
        # features do, or it is not a reference for this model: concatenating gives
        # K00 + K11 where subtracting gives K00 - K01 - K10 + K11.
        return FJKModel(
            **final_model_kwargs,
            rep_params=default_oml_rep_params,
            concatenate_components=representation_name == fjd_pair_rep,
        )


def handoff_filename(representation_name, seed):
    """Where the representation stage leaves its results for the model stage.

    A bare filename rather than a path: spython runs each job in a scratch directory and
    copies what it finds there into data_<jobname>/ once the job ends, so the model stage
    receives this file through --req_files and finds it in its own working directory.
    """
    return f"cpu_times_{representation_name}_{seed}.pkl"


def parse_arguments():
    """(stage, seed, representation_name, handoff_path), as the launchers pass them.

    The fourth argument is where the model stage READS the representation stage's output.
    It is passed rather than copied in with spython's --req_files because the file is large
    -- 0.6 MB per molecule for FJD, 8.9 MB for SOAP, so several GB for a full set -- and
    copying it costs a read plus a write plus the load, where reading it where it already
    lies costs the load alone. It defaults to this directory, which is where the
    representation stage leaves it and therefore what a by-hand rerun in that job's data
    folder needs.
    """
    if len(sys.argv) > 1:
        stage = sys.argv[1]
        assert stage in STAGES, f"unknown stage {stage!r}, expected one of {STAGES}"
    else:
        stage = STAGE_REPRESENTATIONS

    if len(sys.argv) > 2:
        seed = int(sys.argv[2])
    else:
        seed = 274658

    if len(sys.argv) > 3:
        representation_name = sys.argv[3]
        assert representation_name in global_reps + local_reps + local_dn_reps + fjd_reps
    else:
        representation_name = "CM"

    if len(sys.argv) > 4:
        handoff_path = sys.argv[4]
    else:
        handoff_path = handoff_filename(representation_name, seed)

    print("STAGE:", stage, "SEED:", seed, "REPRESENTATION NAME:", representation_name)
    return stage, seed, representation_name, handoff_path


def build_ensembles(seed, representation_name):
    """The dataset, shuffled by `seed`, as ensembles plus the quantities to learn.

    The shuffle is what makes the two stages agree on which molecule is which, so both must
    call this with the same seed -- the model stage does not, because it reads the split
    back out of the handoff file instead, but the launchers still pass the seed to both so
    that a mismatched pair is caught rather than silently mis-paired.
    """
    random.seed(seed)

    containing_folder = os.environ["DATA"] + "/FreeSolv/MobleyLab-FreeSolv-9d8a809"

    r_cut = 0.05
    num_conformers = 1

    # Import all data.
    all_data = get_free_solvation_energies(containing_folder=containing_folder)

    all_SMILES = sorted(list(all_data.keys()))

    # NOTE: the total number of molecules is 642
    training_set_size = 514

    random.shuffle(all_SMILES)

    # For now running without statistical errors

    if representation_name == fjd_pair_rep:
        base_ensemble_kwargs = pair_fjd_comp_extra_kwargs
    elif representation_name == fjd_sdet_rep:
        base_ensemble_kwargs = fjd_comp_extra_kwargs
    else:
        base_ensemble_kwargs = {"base_class_name": "Compound"}

    ensemble_kwargs = {
        **base_ensemble_kwargs,
        "num_conformers": num_conformers,
        "r_cut": r_cut,
    }

    ensembles = []
    quant_vals = []
    all_nuclear_charges = []

    for SMILES in all_SMILES:
        savefile_prefix = None
        ensemble = Ensemble(SMILES=SMILES, savefile_prefix=savefile_prefix, **ensemble_kwargs)
        all_nuclear_charges.append(ensemble.get_nuclear_charges())
        quant_vals.append(all_data[SMILES][0])
        ensembles.append(ensemble)

    print("Number of usable ensembles:", len(ensembles))

    return ensembles, np.array(quant_vals), all_nuclear_charges, training_set_size


def main_representations(seed, representation_name):
    """Stage one, on ONE core: conformers, ab initio, representation. Dumps the rest a
    model needs so that stage two never touches a molecule again.
    """
    ensembles, quant_vals, all_nuclear_charges, training_set_size = build_ensembles(
        seed, representation_name
    )

    rep_calculator = get_rep_calculator(representation_name, all_nuclear_charges)
    ensemble_rep_calculator = MinConformerRepresentationCalc(rep_calculator)
    parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

    training_conformers, training_init_compounds = get_processed_ensembles(
        parallel_calculator, ensembles[:training_set_size], representation_name, "TRAINING"
    )
    test_conformers, test_init_compounds = get_processed_ensembles(
        parallel_calculator, ensembles[training_set_size:], representation_name, "TEST"
    )
    del ensembles

    # component_bounds rather than the calculator that produced them: the calculator holds
    # the representation function itself -- a dscribe object for SOAP, an OML_rep_params for
    # FJD -- and the model stage needs none of it, only the region list it implies.
    handoff = {
        "seed": seed,
        "representation_name": representation_name,
        "component_bounds": parallel_calculator.component_bounds,
        "all_nuclear_charges": all_nuclear_charges,
        "training_conformers": training_conformers,
        "test_conformers": test_conformers,
        "training_init_compounds": training_init_compounds,
        "test_init_compounds": test_init_compounds,
        "training_quantities": quant_vals[:training_set_size],
        "test_quantities": quant_vals[training_set_size:],
        # Only its shape is read downstream, by get_msorf_definition_lists.
        "global_training_set_projector": global_training_set_projector,
    }
    filename = handoff_filename(representation_name, seed)
    dump2pkl(handoff, filename)
    print("HANDOFF_FILE:", filename)
    print("HANDOFF_FILE_SIZE_MB:", os.path.getsize(filename) / 1.0e6)


def main_models(seed, representation_name, handoff_path):
    """Stage two, on as many OpenMP threads as the job holds: features and kernel.

    Reads the handoff in place rather than being given a copy of it; the --dependency on
    the representation job is what guarantees the file is complete by the time this starts.
    """
    global global_training_set_projector

    print("HANDOFF_FILE:", handoff_path)
    assert os.path.isfile(handoff_path), (
        f"{handoff_path} does not exist. This stage reads what the representation stage "
        "produced, whose path is its fourth argument; check that the representation job "
        "finished and that this job carried --dependency=afterok on it."
    )
    handoff = loadpkl(handoff_path)
    # A mismatched pair would otherwise produce timings for one representation labelled as
    # another, which no downstream check would catch.
    assert (
        handoff["representation_name"] == representation_name
    ), f"handoff file holds {handoff['representation_name']}, not {representation_name}"
    assert handoff["seed"] == seed, f"handoff file holds seed {handoff['seed']}, not {seed}"

    component_bounds = handoff["component_bounds"]
    all_nuclear_charges = handoff["all_nuclear_charges"]
    training_conformers = representations_from_handoff(
        handoff["training_conformers"], representation_name
    )
    test_conformers = representations_from_handoff(handoff["test_conformers"], representation_name)
    training_quantities = handoff["training_quantities"]
    test_quantities = handoff["test_quantities"]
    global_training_set_projector = handoff["global_training_set_projector"]

    msorf_definition_lists = get_msorf_definition_lists(
        representation_name, component_bounds, all_nuclear_charges
    )

    l2reg_diag_ratio = 1.0e-9

    model = MultilevelSORFModel(
        *msorf_definition_lists,
        intensive_quantity_shift=False,
        extensive_quantity_shift=False,
        l2reg_diag_ratio=l2reg_diag_ratio,
    )

    model.assign_training_set(training_conformers, training_quantities)

    # Timed and printed rather than left silent: it is not cheap, and whether it belongs in
    # a quoted SORF cost is a question the number has to be visible to answer.
    _, hyperparameter_optimization_timing = do_with_timing(model.optimize_hyperparameters_short)
    print("HYPERPARAMETER_OPTIMIZATION_TIMING:", hyperparameter_optimization_timing)
    print("Hyperparameters:", model.hyperparameters)

    training_feature_vectors, training_feature_vectors_timing = redo_with_timing(
        model.calc_training_Z_matrix
    )

    del training_conformers
    model.training_objects = None

    print("TRAINING_FEATURE_VECTOR_TIMING:", training_feature_vectors_timing)

    approx_training_kernel = np.dot(training_feature_vectors, training_feature_vectors.T)
    mean_diag_element = np.mean(
        approx_training_kernel[np.diag_indices_from(approx_training_kernel)]
    )

    feature_vector_alphas, feature_vector_alphas_timing = redo_with_timing(
        regression_using_Z,
        training_feature_vectors,
        training_quantities,
        l2reg_diag_ratio=l2reg_diag_ratio,
    )

    print("FEATURE_VECTOR_ALPHAS_TIMING:", feature_vector_alphas_timing)

    model.alphas = feature_vector_alphas

    feature_vector_predictions, feature_vector_predictions_timing = redo_with_timing(
        model.get_all_predictions, test_conformers
    )
    del test_conformers

    errors = np.abs(feature_vector_predictions - test_quantities)

    print("MAE_FROM_FEATURES:", np.mean(errors))

    print("RMSE_FROM_FEATURES:", np.sqrt(np.mean(errors**2)))

    print("PREDICTION_TIMING:", feature_vector_predictions_timing)

    krr_model = get_krr_model(
        representation_name,
        component_bounds,
        hyperparameters=model.hyperparameters,
        l2reg_diag_ratio=l2reg_diag_ratio,
    )

    krr_model.assign_training_set(
        training_compounds=handoff["training_init_compounds"],
        training_quantities=training_quantities,
    )
    handoff["training_init_compounds"] = None

    training_kernel, training_kernel_timing = redo_with_timing(krr_model.get_training_kernel)

    krr_model.training_compounds = None

    print(
        "KERNEL_MAGNITUDE_VS_DIFFERENCE:",
        np.mean(np.abs(training_kernel)),
        np.mean(np.abs(training_kernel - approx_training_kernel)),
    )

    print("TRAINING_KERNEL_TIMING:", training_kernel_timing)

    # args_deepcopy because overwrite_a=True means what it says: get_factorization_w_l2reg
    # adds l2reg to the diagonal IN PLACE and then writes the Cholesky factor over it, so
    # redo_with_timing's warm-up call leaves the timed call a factor to factorise instead of
    # a kernel. That is what "potrf return info = [2]" was -- every representation, every
    # seed. The warm-up now runs on a copy and the timed call gets the pristine kernel.
    krr_alphas, krr_alphas_timing = redo_with_timing(
        cho_solve,
        training_kernel,
        training_quantities,
        args_deepcopy=True,
        l2reg=mean_diag_element * l2reg_diag_ratio,
        overwrite_a=True,
    )

    print("TRAINING_KERNEL_REGRESSION_TIMING:", krr_alphas_timing)

    krr_model.alphas = krr_alphas

    krr_predictions, krr_predictions_timings = redo_with_timing(
        krr_model.predict_from_compounds, handoff["test_init_compounds"]
    )
    handoff["test_init_compounds"] = None

    print("KRR_PREDICTION_TIMINGS:", krr_predictions_timings)

    krr_errors = np.abs(krr_predictions - test_quantities)

    print("MAE_FROM_KRR:", np.mean(krr_errors))
    print("RMSE_FROM_KRR:", np.sqrt(np.mean(krr_errors**2)))


def main():
    stage, seed, representation_name, handoff_path = parse_arguments()
    if stage == STAGE_REPRESENTATIONS:
        # Not silently ignored: the representation stage has to write where spython will
        # collect it, so a path handed to this stage means the two were mixed up.
        assert len(sys.argv) <= 4, (
            f"{STAGE_REPRESENTATIONS} takes no handoff path -- it writes "
            f"{handoff_filename(representation_name, seed)} into its own working directory, "
            f"which spython copies into data_<job name>/. Got {sys.argv[4]!r}."
        )
        main_representations(seed, representation_name)
    else:
        main_models(seed, representation_name, handoff_path)


if __name__ == "__main__":
    main()
