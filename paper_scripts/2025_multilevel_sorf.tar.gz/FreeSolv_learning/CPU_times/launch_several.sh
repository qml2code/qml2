#!/bin/bash
# Two jobs per (seed, representation), chained with afterok.
#
# The split follows what parallelizes over MOLECULES and what parallelizes INSIDE one
# operation. Conformer generation, the ab initio calculations and the representation
# function are per-molecule and do not benefit from OpenMP -- a GFN2 single point on one
# conformer is far too small, and four threads were measured to buy no wall time at all
# while costing eight times the CPU. They get ONE core, where the CPU time reported is the
# true serial cost. The SORF features and the kernel are Numba prange over one large array
# and do scale, so they get the cores. No multiprocessing anywhere.
#
# Both stages report CPU seconds, so their numbers add directly with no core-count scaling.

max() {
    echo $(( $1 > $2 ? $1 : $2 ))
}

# --CPUs is also a MEMORY request here, and the only one available: the node runs
# SelectTypeParameters=CR_Core_Memory with DefMemPerCPU=MaxMemPerCPU=2681, so a job gets
# 2681 MB per core and cannot ask for memory any other way. That is why the cores below are
# bought separately from the threads: OMP_NUM_THREADS stays at what the stage should USE,
# while --CPUs is raised to what it needs to FIT.
#
# One core gives 2.6 GB, which OOM-killed every SOAP and aSLATM representation job. Sized
# from the handoff each representation produced under that cap:
#
#   SOAP, aSLATM             killed, no handoff written    -> 80 cores, 214 GB
#   SLATM                    1.09 GB (LES), the largest    -> 32 cores, 86 GB
#   SLATM_projected          0.44 GB, but it holds the full SLATM matrix AND the projector
#                            before the projection shrinks it, so its PEAK is above SLATM's
#                            even though its handoff is smaller -> 32 cores
#   FCHL19                   0.78 GB (LES)                 -> 32 cores
#   FJD, FJD_sdet, CM, cMBDF <= 0.62 GB, comfortable       -> whatever the stage uses
representation_cpus=1
model_cpus=8

memory_hungry_cpus=80
memory_moderate_cpus=32

script=kernel_sorf_timing_comparison_FreeSolv.py

for seed in 274658 20786 109790 478390
do
	for rep_name in "FJD" "FJD_sdet" "CM" "SLATM" "SOAP" "cMBDF" "FCHL19" "aSLATM" "SLATM_projected"
	do
		representation_job=${rep_name}_FreeSolv_CPU_check_representations_$seed
		model_job=${rep_name}_FreeSolv_CPU_check_models_$seed

		# A case rather than a chain of [ ] tests: `[ "SLATM" ]` asks whether the string
		# is non-empty, which is always true, so a chain silently applies the last branch
		# to everything. The catch-all also guarantees mem_safe_cpus is set on every
		# iteration -- without it the variable keeps the previous representation's value.
		case "$rep_name" in
			SOAP | aSLATM)
				mem_safe_cpus=$memory_hungry_cpus ;;
			SLATM | SLATM_projected | FCHL19)
				mem_safe_cpus=$memory_moderate_cpus ;;
			*)
				mem_safe_cpus=1 ;;
		esac

		representation_id=$(spython --OMP_NUM_THREADS=$representation_cpus --CPUs=$(max $representation_cpus $mem_safe_cpus) \
			$script "$representation_job" representations $seed "$rep_name" \
			| awk '/^SPYTHON_SUBMITTED_JOB_ID:/{print $2}')

		if [ -z "$representation_id" ]
		then
			# spython refuses to resubmit into an existing data_ folder, and prints no id
			# when it does. Submitting the model stage anyway would give sbatch an empty
			# dependency and start it before its input exists.
			echo "SKIPPING $model_job: no job id from $representation_job (already submitted?)"
			continue
		fi

		# Where the representation stage leaves its results: spython copies whatever the job
		# produced in its scratch directory into data_<jobname>/ once it ends. The model stage
		# is handed this path and reads the file THERE rather than being given a copy of it --
		# it runs to several GB, and copying costs a read plus a write plus the load where
		# reading in place costs the load alone. The afterok dependency is what guarantees the
		# file is complete before the model stage opens it.
		handoff=$(pwd)/data_$representation_job/cpu_times_${rep_name}_${seed}.pkl

		spython --OMP_NUM_THREADS=$model_cpus --CPUs=$(max $model_cpus $mem_safe_cpus) \
			--dependency=afterok:$representation_id \
			$script "$model_job" models $seed "$rep_name" "$handoff"
	done
done
