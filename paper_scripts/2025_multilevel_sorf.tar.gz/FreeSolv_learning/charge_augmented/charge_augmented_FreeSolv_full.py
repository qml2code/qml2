"""Learning curves for FCHL19/aSLATM augmented with tight-binding atomic charges.

The base representation carries geometry and nothing else: FCHL19 and aSLATM are functions
of nuclear charges and coordinates, so two states of one molecule that differ only in their
electronic structure get IDENTICAL vectors from them. GFN2's Mulliken charges do move --
by 0.009 to 0.089 per atom between gas phase and ALPB water, measured over 40 FreeSolv molecules -- so appending one charge per atom
is appending the only thing that distinguishes the states.

The charge column gets its OWN rescaling region and therefore its own sigma
(`LocalRepresentationCalc(additional_comp_rep_functions=...)`), which is the point: a single
sigma shared with hundreds of geometric features would let the model tune the charge away or
drown it.

Four axes, all flags, all stripped from sys.argv so the positional interface survives:

* `--aslatm`    aSLATM instead of FCHL19 as the base representation.
* `--sdet`      one state instead of a pair, the counterpart of FJD_sdet.
* `--min_conf`  the lowest-free-energy conformer instead of the weighted ensemble.
* `--no_charges` the base representation ALONE, with no charge column. Requires --sdet,
                for the reason the first paragraph gives: without the charges a pair's two
                states are identical, so their difference is exactly zero. With --sdet and
                one rescaling region this reproduces the plain FCHL19/aSLATM model --
                `rescaling` over a single region followed by `unscaled_sorf` IS `sorf` --
                so it is the same model as the plain scripts, which makes it the baseline
                the --delta-ml runs are read against.

The pair is combined by CONCATENATION, matching what FJK_FreeSolv_full.py does for the Slater pair: the two states' feature vectors are laid end to end.

NO NEW QUANTUM CHEMISTRY. The savefile folders below are the ones the FJD runs already
filled, and `xtb_charges` is stored per determinant in them (642 molecules x 32
conformers, verified present and summing to the determinant's total charge). This script
reads them and computes nothing ab initio.

The per-atom representation is the same one the plain FCHL19/aSLATM curves use, with an
`element_id_switch` level so each element keeps its own SORF block. The charges are the ONLY
difference against those curves, which is what makes a comparison against them mean something.

It is COMPUTED IN THE PARALLEL LOOP rather than imported: the conformers carry their geometry and
their charges, and multilevel_sorf's `calculate_representation` level turns each one into the
per-atom object the levels below it consume. Nothing stores a representation, so peak memory is set
by the geometries rather than by (molecules x conformers x states x representation width). The
representation is recomputed on every pass over a conformer, which is the price.

NOTE: with "software": "tblite" this does NOT select SMD. The keyword is passed to
tblite's own ALPB model -- calculator.add("alpb-solvation", solvent) in
qml2/orb_ml/tblite_interface -- so what these runs used is ALPB, not SMD. A naming
oversight, not an attempt at a solvent model tblite does not have; see README.txt note 1.
"""

import json
import os
import random
import sys

import numpy as np

from qml2.basic_utils import now
from qml2.cheminfo.scaffolds import ACYCLIC_POLICIES, scaffold_group_ids
from qml2.data import conversion_coefficient
from qml2.dataset_formats.FreeSolv import get_free_solvation_energies
from qml2.ensemble import Ensemble
from qml2.models.kfolds import frequency_ordered_group_split, group_index_lists
from qml2.models.learning_curves import learning_curve_from_predictions
from qml2.models.loss_functions import MAE, RMSE
from qml2.multilevel_sorf.base_constructors import get_transform_list_dict2datatype
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import ProcessedRepresentationListCalc
from qml2.multilevel_sorf.processed_object_constructors.conformer_pairs import (
    PairLocalRepresentationCalc,
    atomic_charge_representation,
)
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    EnsembleRepresentationCalc,
    MinConformerRepresentationCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.numba_constructors import (
    get_el_aug_rep_constructor,
)
from qml2.multilevel_sorf.processed_object_constructors.standard import (
    NumbaConformerWLocalRepGenerator,
)
from qml2.parallelization import embarrassingly_parallel
from qml2.representations.numba_calculators import (
    CONFORMER_WLOCALREP_CLASS,
    FCHL19JITCalculator,
    JITLocalRepresentationAdditionCalculator,
    aSLATMJITCalculator,
)


def selected_flag(flag, description):
    """Whether `flag` was passed, removing it from sys.argv so positions are preserved.

    Parsed by hand rather than with argparse because spython copies this file, alone, into
    its job directory -- so it must work with no sibling modules and keep the positional
    interface the launchers use.
    """
    selected = flag in sys.argv
    if selected:
        sys.argv = [argument for argument in sys.argv if argument != flag]
    print(f"{description}: {selected}")
    return selected


def delta_ml_reference(SMILES, pair_savefile_folder, pair_compound_kwargs, num_conformers, r_cut):
    """One molecule's conformer-weighted E(solvated) - E(gas), in kcal/mol.

    The pair's two states differ by exactly the perturbation the charges respond to, so the
    energy difference between them IS a calculated hydration free energy -- the same reference the
    FJD runs use. With --delta-ml the model learns what that calculation misses instead of
    the experimental value itself.

    Nothing is recalculated: the ensemble is built pointing at the PAIR savefile folder, so
    run_calcs finds every conformer already stored and only unpickles it. Only the
    subtraction, the conformer weighting and the unit conversion happen here. In --sdet mode
    this script has no pair of its own, which is why the reference is fetched this way
    rather than taken from the ensembles main() already holds.
    """
    ensemble = Ensemble(
        SMILES=SMILES,
        savefile_prefix=pair_savefile_folder + "/" + SMILES.replace("/", "_"),
        base_class_name="OML_Slater_pair",
        compound_kwargs=pair_compound_kwargs,
        num_conformers=num_conformers,
        r_cut=r_cut,
    )
    ensemble.run_calcs()
    return ensemble.mean_calculated_energy_diff() * conversion_coefficient["au_kcal"]


def base_representation_calculator(use_aslatm, all_nuclear_charges, present_nuclear_charges):
    """The base representation, as a jitted function of ONE conformer.

    Returned as a JIT calculator rather than applied here: the `calculate_representation` level bakes
    it in and calls it inside the parallel loop, so no molecule's representation is ever stored. What
    is stored per atom instead is the GFN2 charge, which nothing inside numba could recompute -- it is
    read off the converged calculation, which is exactly why it carries information the base
    representation does not.
    """
    if use_aslatm:
        return aSLATMJITCalculator(all_nuclear_charges=all_nuclear_charges)
    return FCHL19JITCalculator(elements=present_nuclear_charges)


def in_loop_representation_function(base_calculator):
    """[base representation | GFN2 charge] per atom, computed in-loop and concatenated.

    The charge column rides on the conformer; this wrapper appends it to whatever the base calculator
    produces, in that order, which is the order `component_bounds` below describes.
    """
    return JITLocalRepresentationAdditionCalculator(base_calculator).numba_calculator


def probe_representation_width(in_loop_function, nuclear_charges):
    """Width of one atom's [base representation | charge] vector, on a synthetic geometry.

    Only the SHAPE of the result is read, so the geometry need not be physical -- a straight chain at
    a typical bond length, which is non-degenerate (a distance-based representation would divide by
    zero on coincident atoms) and well inside any cutoff.
    """
    natoms = len(nuclear_charges)
    coordinates = np.zeros((natoms, 3))
    coordinates[:, 0] = np.arange(natoms) * 1.4
    probe_charges = np.zeros((natoms, 1))
    conformer = CONFORMER_WLOCALREP_CLASS(
        # int64 explicitly: the jitclass field is int64[:], and plain `int` is 32-bit on Windows.
        np.array(nuclear_charges, dtype=np.int64),
        coordinates,
        probe_charges,
    )
    return in_loop_function(conformer).shape[1], probe_charges.shape[1]


def representation_component_bounds(in_loop_function, all_nuclear_charges, with_charges=True):
    """Rescaling regions for [base representation | charge]: one region each, so one sigma each.

    MEASURED by calling the same jitted function the level bakes in, rather than derived from the
    representation's parameters, so a change in its width cannot leave these regions behind. It has to
    be measured somewhere: a NumbaConformerWLocalRepGenerator computes no representation, so it cannot
    report the regions itself and takes them as an argument instead.

    Probed on the SMALLEST and LARGEST molecule in the set and required to agree. That is not
    belt-and-braces: the whole design assumes one fixed per-atom width, shared by every conformer of
    every molecule, since the levels below are compiled once against it and the regions are baked into
    the model. A representation whose width grows with the molecule -- a global one, or a local one
    misconfigured into behaving like it -- cannot be used here at all, and this is the cheapest place
    to find that out rather than reading it off wrong features later.
    """
    sizes = [len(nuclear_charges) for nuclear_charges in all_nuclear_charges]
    smallest = all_nuclear_charges[sizes.index(min(sizes))]
    largest = all_nuclear_charges[sizes.index(max(sizes))]

    small_total, charge_columns = probe_representation_width(in_loop_function, smallest)
    large_total, _ = probe_representation_width(in_loop_function, largest)
    if small_total != large_total:
        raise ValueError(
            f"the per-atom representation is {small_total} wide for a {len(smallest)}-atom molecule "
            f"and {large_total} wide for a {len(largest)}-atom one. The calculate_representation level "
            "needs one fixed width for the whole set: the levels below it are compiled against it "
            "once and the rescaling regions are baked into the model."
        )

    if not with_charges:
        # One region, one sigma -- which is what makes `rescaling` + `unscaled_sorf` identical to
        # the plain scripts' `sorf` (that being `full_rescaling` + `unscaled_sorf`). The probe's
        # synthetic charge column is ignored by the in-loop function in this mode, so
        # `charge_columns` must NOT be subtracted here.
        return np.array([[0, small_total]])

    base_width = small_total - charge_columns
    return np.array([[0, base_width], [base_width, small_total]])


def sorf_definition_lists(
    single_determinant,
    min_conf,
    init_size,
    component_bounds,
    num_element_ids,
    ntransforms,
    compilation_parameters,
):
    """The SORF stack, built level by level so each one can be tied to what it collapses."""
    # rescaling gives the charge column its own sigma; element_id_switch gives each element
    # its own SORF block, as the plain FCHL19/aSLATM curves do. Both act on one atom's
    # vector, before anything is summed.
    #
    # unscaled_sorf, NOT sorf: `sorf` is a full_rescaling wrapped around unscaled_sorf, so it
    # carries a sigma of its own, and after `rescaling` -- which has already given each region its
    # own sigma -- that extra one is an exactly flat direction in hyperparameter space (only the
    # product sigma_region * sigma_global reaches the transform). The FJK/FJD stacks spell it this
    # way for the same reason; see qml2/multilevel_sorf/AGENTS.md.
    function_definition_list = [
        "resize",
        "rescaling",
        "unscaled_sorf",
        "element_id_switch",
        "component_sum",
    ]
    parameter_list = [
        {"output_size": init_size},
        {"resc_bounds": component_bounds},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
        {"num_element_ids": num_element_ids},
        {},
    ]

    # The conformer arrives carrying its geometry and its GFN2 charges, and this level turns it into
    # the per-atom object every level BELOW consumed directly before: it computes the base
    # representation in-loop, concatenates the charge column, wraps the result one atom at a time and
    # passes it down. Nothing below it changes, and nothing below it is aware anything did.
    #
    # It sits exactly here, at the boundary between the per-atom levels and the levels that combine
    # states and conformers, because that is the last point at which a whole conformer is still the
    # unit being handled.
    function_definition_list.append("calculate_representation")
    parameter_list.append({"compilation_parameters": compilation_parameters})

    if not single_determinant:
        function_definition_list.append("concatenation")
        parameter_list.append({"num_components": 2})

    if not min_conf:
        # The conformer level. --min_conf keeps one conformer, so there is nothing to sum.
        function_definition_list.append("weighted_component_sum")
        parameter_list.append({})

    # The conformer-generation level, which is a plain list either way.
    function_definition_list.append("component_sum")
    parameter_list.append({})
    return function_definition_list, parameter_list


# The grouping the split is built on. Verified non-degenerate for these seeds by
# scaffolds/scaffold_distribution_*.py: four distinct randomized draws, none of which
# reproduces the deterministic one.
SCAFFOLD_ACYCLIC = "skeleton"
# What --pool-acyclic selects instead: every ring-free molecule in one group. Named here beside
# the default rather than written into the flag handling, because both are qml2's vocabulary and
# not ours -- hence the check below, which turns a renamed or mistyped policy into an error at
# import instead of one raised from inside scaffold_group_ids after the dataset has been read.
# qml2 offers no per-policy constant to use directly, only the tuple of the valid ones.
SCAFFOLD_ACYCLIC_POOLED = "pool"
assert {SCAFFOLD_ACYCLIC, SCAFFOLD_ACYCLIC_POOLED} <= set(ACYCLIC_POLICIES), (
    f"acyclic policies {SCAFFOLD_ACYCLIC!r}/{SCAFFOLD_ACYCLIC_POOLED!r} are not both in qml2's "
    f"ACYCLIC_POLICIES={ACYCLIC_POLICIES}"
)
SCAFFOLD_INCLUDE_CHIRALITY = False
TRAIN_FRACTION = 0.8


def scaffold_split_mode():
    """Replace the learning curve with a single 80/20 scaffold split, or not.

    --fo_scaffold   frequency-ordered split, deterministic: the reference point, comparable
                    with the scaffold-split literature.
    --rfo_scaffold  same frequency ordering, but same-size groups shuffled with the seed, so
                    several seeds give an ensemble with genuine error bars.

    Stripped from sys.argv like --fjk and --delta-ml, so the positional arguments keep their
    meaning.
    """
    flags = ("--fo_scaffold", "--rfo_scaffold")
    selected = [flag for flag in flags if flag in sys.argv]
    assert len(selected) < 2, "pass at most one of " + ", ".join(flags)
    if not selected:
        return None
    sys.argv = [argument for argument in sys.argv if argument not in selected]
    return selected[0].lstrip("-")


def main():
    scaffold_mode = scaffold_split_mode()
    use_aslatm = selected_flag("--aslatm", "BASE REPRESENTATION aSLATM (else FCHL19)")
    single_determinant = selected_flag("--sdet", "SINGLE DETERMINANT")
    min_conf = selected_flag("--min_conf", "MINIMUM-ENERGY CONFORMER ONLY")
    delta_ml = selected_flag("--delta-ml", "DELTA-ML AGAINST THE PAIR ENERGY DIFFERENCE")
    no_charges = selected_flag("--no_charges", "NO CHARGE COLUMN (base representation alone)")
    # One group for every ring-free molecule -- the MoleculeNet/DeepChem convention -- instead of
    # grouping them by generic carbon skeleton. Half of FreeSolv has no ring, so pooled they are a
    # single unsplittable group of 320 that the frequency-ordered split puts whole into training,
    # leaving a test set with no ring-free molecule in it. See acyclic_policy() in
    # ../FJK/FJK_FreeSolv_full.py for the separation numbers that go with the trade.
    pool_acyclic = selected_flag("--pool-acyclic", "ONE GROUP FOR EVERY RING-FREE MOLECULE")
    acyclic = SCAFFOLD_ACYCLIC_POOLED if pool_acyclic else SCAFFOLD_ACYCLIC
    if pool_acyclic:
        if scaffold_mode is None:
            raise SystemExit(
                "--pool-acyclic changes how a SCAFFOLD split is grouped, and this run has no "
                "scaffold split. Pass --fo_scaffold with it, or drop it. An error rather than a "
                "no-op because the run would otherwise be an ordinary learning curve sitting in "
                "a directory whose name claims an acyclic policy."
            )
        if scaffold_mode == "rfo_scaffold":
            raise SystemExit(
                "--pool-acyclic with --rfo_scaffold is degenerate on FreeSolv. Pooled, the "
                "ring-free molecules form one unsplittable group of 320 out of 642, which leaves "
                "the tie shuffling almost nothing to reorder: all four paper seeds return the "
                "SAME split, and it is identical to the one --fo_scaffold gives. Four seeds "
                "would buy four identical runs and an error bar of exactly zero. Use "
                "--fo_scaffold, which is the honest single number for this policy."
            )

    if no_charges and not single_determinant:
        # The other half of "computable but meaningless". The base representation is a function
        # of nuclear charges and coordinates alone, so a pair's two states -- same geometry,
        # different electronic structure -- get IDENTICAL vectors from it, and the pair level
        # subtracts them with weights -1 and +1. Without the charge column that difference is
        # EXACTLY zero: the model would train on all-zero features, build a learning curve and
        # print a correlation, and the only clue would be an error that refuses to improve.
        raise SystemExit(
            "--no_charges requires --sdet: the charge column is the only thing that "
            "distinguishes a pair's two states, so without it their difference is exactly zero "
            "and the model sees nothing. Add --sdet to learn from one state, or drop "
            "--no_charges to keep the charges that make the pair meaningful."
        )

    if delta_ml and min_conf:
        # Computable but meaningless, which is the case worth refusing outright: the
        # reference is a CONFORMER-WEIGHTED energy difference, and with one conformer the
        # weighting is a no-op, so what comes back is that single conformer's difference
        # wearing the name of an ensemble average. Nothing downstream would notice -- the
        # learning curve builds, the Pearson correlation prints -- so the mistake would
        # only ever surface as a number nobody could reconcile with its siblings.
        raise SystemExit(
            "--delta-ml and --min_conf are mutually exclusive: the delta-ML reference is a "
            "conformer-weighted energy difference, which one conformer cannot provide. Drop "
            "--min_conf to learn against the ensemble reference, or drop --delta-ml to learn "
            "the quantity outright from the minimum-energy conformer."
        )

    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 274658
    if len(sys.argv) > 2:
        simple_shifts_str = sys.argv[2]
        assert simple_shifts_str in ["True", "False"]
        simple_shifts = simple_shifts_str == "True"
    else:
        simple_shifts = False

    print("SEED:", seed, "SIMPLE SHIFTS:", simple_shifts, "SCAFFOLD SPLIT:", scaffold_mode)
    if scaffold_mode == "fo_scaffold":
        print("NOTE: the seed does not enter a deterministic split; it only names the job.")
    random.seed(seed)

    containing_folder = os.environ["DATA"] + "/FreeSolv/MobleyLab-FreeSolv-9d8a809"
    solvent = "water"
    r_cut = 0.05
    num_conformers = 32

    # Matches the FJD runs exactly, because the point is to read THEIR savefiles: the
    # charges are already in them and recomputing 32 conformers per molecule to obtain what
    # is on disk would be the whole cost of this study for nothing.
    comp_extra_kwargs_base = {
        "localization_procedure": "Pipek-Mezey",
        "calc_type": "gfn2-xtb",
        "software": "tblite",
    }
    # Resolved whatever the mode: --delta-ml reads its reference out of the PAIR
    # savefiles even when the representation is a single determinant.
    pair_method_str = "FJD_pair"
    pair_comp_extra_kwargs = {
        **comp_extra_kwargs_base,
        "second_oml_comp_kwargs": {"smd_solvent": solvent},
    }
    pair_savefile_folder = (
        containing_folder
        + f"/savefiles_{pair_method_str}_r_cut_{str(r_cut)}_solvent_{solvent}"
        + f"_nconfs_{str(num_conformers)}"
    )

    if single_determinant:
        method_str = "FJD"
        base_class_name = "OML_Compound"
        comp_extra_kwargs = {**comp_extra_kwargs_base, "smd_solvent": solvent}
    else:
        method_str = pair_method_str
        base_class_name = "OML_Slater_pair"
        comp_extra_kwargs = pair_comp_extra_kwargs

    savefile_folder = (
        containing_folder
        + f"/savefiles_{method_str}_r_cut_{str(r_cut)}_solvent_{solvent}"
        + f"_nconfs_{str(num_conformers)}"
    )
    # Printed so a mismatch with what the FJD scripts resolve is visible in the job log
    # rather than silently triggering 32 fresh calculations per molecule.
    print("SAVEFILE FOLDER:", savefile_folder)
    assert os.path.isdir(savefile_folder), (
        f"{savefile_folder} does not exist. This script is meant to READ the FJD runs' "
        "savefiles; without them every molecule would be recalculated."
    )

    all_data = get_free_solvation_energies(containing_folder=containing_folder)
    all_SMILES = sorted(list(all_data.keys()))
    assert len(all_SMILES) == 642

    training_set_size = 514
    # aSLATM's per-atom vector is 16-28x wider than FCHL19's -- 54725 features for
    # FreeSolv's 10 elements, 96738 for LES's 12 -- so it cannot be resized into 32768 at
    # all: `assert init_size >= max_component_bound` below is what catches it. 131072 is
    # what the aSLATM learning-curve and CPU_times scripts already use, and what keeps
    # these comparable with them.
    nfeatures = 131072 if use_aslatm else 32768

    if scaffold_mode is None:
        random.shuffle(all_SMILES)
        training_group_ids = None
    else:
        # The deterministic split breaks ties between equal-size groups by smallest member
        # index, so it is only reproducible against a FIXED input order -- shuffling per seed
        # would make "deterministic" name a different split every time. The SMILES therefore
        # stay sorted, and --rfo_scaffold varies only the order WITHIN blocks of equal-size
        # groups, through its own rng.
        group_ids = scaffold_group_ids(
            all_SMILES,
            acyclic=acyclic,
            include_chirality=SCAFFOLD_INCLUDE_CHIRALITY,
        )
        randomized = scaffold_mode == "rfo_scaffold"
        train_indices, test_indices = frequency_ordered_group_split(
            group_ids,
            int(round(TRAIN_FRACTION * len(all_SMILES))),
            shuffle_ties=randomized,
            rng=np.random.default_rng(seed) if randomized else None,
        )
        # Reorder the dataset so the training molecules come first, which lets everything
        # below keep using the plain [:training_set_size] slicing.
        order = list(train_indices) + list(test_indices)
        all_SMILES = [all_SMILES[index] for index in order]
        group_ids = group_ids[order]
        training_set_size = len(train_indices)
        assert not (
            set(group_ids[:training_set_size].tolist())
            & set(group_ids[training_set_size:].tolist())
        ), "a scaffold group straddles the split, so it cannot partition the training set"
        training_group_ids = group_index_lists(group_ids[:training_set_size])
        print(
            f"SCAFFOLD SPLIT: {scaffold_mode}"
            f" train/test={training_set_size}/{len(all_SMILES) - training_set_size}"
            f" groups_in_train={len(training_group_ids)}"
        )

    ensemble_kwargs = {
        "base_class_name": base_class_name,
        "compound_kwargs": comp_extra_kwargs,
        "num_conformers": num_conformers,
        "r_cut": r_cut,
    }

    ensembles = []
    quant_vals = []
    all_nuclear_charges = []
    present_nuclear_charges = []

    for SMILES in all_SMILES:
        changed_SMILES = SMILES.replace("/", "_")
        ensemble = Ensemble(
            SMILES=SMILES,
            savefile_prefix=savefile_folder + "/" + changed_SMILES,
            **ensemble_kwargs,
        )
        current_nuclear_charges = ensemble.get_nuclear_charges()
        present_nuclear_charges += list(current_nuclear_charges)
        all_nuclear_charges.append(current_nuclear_charges)
        quant_vals.append(all_data[SMILES][0])
        ensembles.append(ensemble)

    print("Number of usable ensembles:", len(ensembles))
    present_nuclear_charges = np.unique(np.array(present_nuclear_charges))
    print("Present nuclear charges:", present_nuclear_charges)
    quant_vals = np.array(quant_vals)

    if delta_ml:
        assert os.path.isdir(pair_savefile_folder), (
            f"--delta-ml needs the pair savefiles in {pair_savefile_folder}, which does "
            "not exist. They are not generated here: that would take hours inside a "
            "learning-curve job and write into a folder this script does not own."
        )
        print("DELTA-ML REFERENCE FOLDER:", pair_savefile_folder)
        print(">>>started delta-ML reference:", now())
        baselines = np.array(
            embarrassingly_parallel(
                delta_ml_reference,
                all_SMILES,
                (pair_savefile_folder, pair_comp_extra_kwargs, num_conformers, r_cut),
            )
        )
        print(">>>finished delta-ML reference:", now())
        correlation = np.corrcoef(quant_vals, baselines)[0, 1]
        print(f"delta-ML reference vs experiment: Pearson {correlation:+.4f}")
        # The model learns the residual from here on. A per-molecule constant cancels
        # between a prediction and its reference, so the errors are the same whether they
        # are measured on residuals or on absolutes -- which keeps these learning curves
        # directly comparable with the runs that use no reference.
        quant_vals = quant_vals - baselines

    base_calculator = base_representation_calculator(
        use_aslatm, all_nuclear_charges, present_nuclear_charges
    )
    # The function the calculate_representation level bakes in, and the regions it will produce.
    # Measured before the import pass because the generator below has to be given them.
    # --no_charges takes the base calculator's own jitted function, so no charge column is
    # concatenated and the vector keeps a single rescaling region.
    if no_charges:
        in_loop_function = base_calculator.numba_calculator
    else:
        in_loop_function = in_loop_representation_function(base_calculator)
    component_bounds = representation_component_bounds(
        in_loop_function, all_nuclear_charges, with_charges=not no_charges
    )
    print(
        "Component bounds (base representation alone):"
        if no_charges
        else "Component bounds (the last region is the charges):"
    )
    print(component_bounds)

    # What gets IMPORTED and kept is the geometry plus one charge per atom. The representation itself
    # is never stored -- the level computes it per conformer inside the parallel loop.
    conformer_generator = NumbaConformerWLocalRepGenerator(
        [atomic_charge_representation], component_bounds
    )
    if single_determinant:
        rep_calculator = conformer_generator
    else:
        rep_calculator = PairLocalRepresentationCalc(
            conformer_generator, concatenate_components=True
        )

    if min_conf:
        ensemble_rep_calculator = MinConformerRepresentationCalc(rep_calculator)
        conformer_levels = ["list"]
    else:
        ensemble_rep_calculator = EnsembleRepresentationCalc(rep_calculator)
        conformer_levels = ["list", "rhos", "list"]

    parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

    # vacate_list on BOTH steps, as aSLATM_*_full.py does and for the same reason: each
    # ensemble is dropped as its representation is taken, and each dict as it is converted,
    # so the peak is about one copy of the representations rather than input plus output.
    # It matters most exactly where it is hardest to afford -- aSLATM's per-atom vector is
    # 78789 wide for FreeSolv and 123106 for LES, so the two-state LES ensemble runs to
    # 233 GB against the 214 GB that 80 cores buys.
    processed_dicts = parallel_calculator(ensembles, vacate_list=True)

    # Asked of whichever calculator is in use -- a bare generator or the pair wrapper around one --
    # rather than reconstructed here, so the transform and the data cannot drift apart.
    list_dict2datatype = get_transform_list_dict2datatype(
        rep_calculator.processed_representation_def() + conformer_levels
    )
    processed_ensembles = list_dict2datatype(processed_dicts, vacate_list=True)
    del processed_dicts

    # The generator reports the bounds it was given, so this only confirms every molecule agreed.
    assert np.all(parallel_calculator.component_bounds == component_bounds)

    max_component_bound = int(component_bounds[-1][-1])
    init_size = nfeatures
    assert init_size >= max_component_bound
    print("REPRESENTATION_SIZE:", max_component_bound)
    print("SORF init_size", init_size)

    compilation_parameters = {
        "representation_function": in_loop_function,
        "processed_object_constructor": get_el_aug_rep_constructor(present_nuclear_charges),
    }

    function_definition_list, parameter_list = sorf_definition_lists(
        single_determinant,
        min_conf,
        init_size,
        component_bounds,
        num_element_ids=len(present_nuclear_charges),
        ntransforms=3,
        compilation_parameters=compilation_parameters,
    )
    print("SORF levels:", function_definition_list)

    training_ensembles = processed_ensembles[:training_set_size]
    training_quantities = quant_vals[:training_set_size]
    training_nuclear_charges = all_nuclear_charges[:training_set_size]

    test_ensembles = processed_ensembles[training_set_size:]
    test_quantities = quant_vals[training_set_size:]
    test_nuclear_charges = all_nuclear_charges[training_set_size:]

    model = MultilevelSORFModel(
        function_definition_list,
        parameter_list,
        # The quantities are shifted either way; `simple_shifts` selects HOW the shift is
        # optimized -- fitted directly to the training quantities when True, or against the
        # model's leave-one-out errors when False.
        intensive_quantity_shift=False,
        extensive_quantity_shift=True,
        simple_quantity_shift=simple_shifts,
    )

    training_set_sizes = [50, 100, 200, 400, training_set_size]

    if scaffold_mode is not None:
        print(">>>started group-based hyperparameter optimization:", now())
        model.assign_training_set(
            training_ensembles,
            training_quantities,
            training_group_ids=training_group_ids,
            training_nuclear_charges=training_nuclear_charges,
        )
        model.optimize_hyperparameters()
        print(">>>finished group-based hyperparameter optimization:", now())
        model.fit(
            training_ensembles,
            training_quantities,
            training_nuclear_charges=training_nuclear_charges,
        )
        predictions = model.get_all_predictions(
            test_ensembles, all_query_nuclear_charges=test_nuclear_charges
        )
        errors = predictions - test_quantities
        # Names the run inside the file: collating one number per job across modes, seeds and
        # methods is otherwise guesswork about which directory it came from. The seed is
        # recorded even for the deterministic mode, where it does not enter the split, so that
        # every file has the same fields.
        run_description = (
            f"mode={scaffold_mode} seed={seed} simple_shifts={simple_shifts}"
            f" acyclic={acyclic} include_chirality={SCAFFOLD_INCLUDE_CHIRALITY}"
            f" train={training_set_size} test={len(test_quantities)}"
        )
        for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
            value = float(loss(errors))
            print(f"{loss_name}: {value}")
            with open(f"scaffold_split_{loss_name}.txt", "w") as error_file:
                print(f"# {loss_name} {run_description}", file=error_file)
                print(value, file=error_file)

        # Per-molecule predictions AND references, so the split can be re-analysed (per-scaffold
        # errors, the worst offenders, a parity plot) without rerunning the fit and without a
        # second lookup into the dataset. Keyed by SMILES rather than by index because the index
        # only means something relative to this split's ordering, which the scaffold modes
        # permute; the two maps therefore share their keys.
        test_SMILES = all_SMILES[training_set_size:]
        assert len(test_SMILES) == len(predictions)
        assert len(set(test_SMILES)) == len(test_SMILES), "SMILES keys must be unique"
        predictions_file = "scaffold_split_predictions.json"
        with open(predictions_file, "w") as json_file:
            json.dump(
                {
                    "description": run_description,
                    "predictions": {
                        SMILES: float(value) for SMILES, value in zip(test_SMILES, predictions)
                    },
                    "references": {
                        SMILES: float(value) for SMILES, value in zip(test_SMILES, test_quantities)
                    },
                },
                json_file,
                indent=2,
                sort_keys=True,
            )
        print(f"PREDICTIONS: {predictions_file} ({len(test_SMILES)} molecules)")
        return

    print(">>>started learning curve building:", now())
    all_predictions = model.learning_curve_predictions(
        training_ensembles,
        training_quantities,
        test_ensembles,
        training_set_sizes,
        max_subset_num=1,
        training_nuclear_charges=training_nuclear_charges,
        test_nuclear_charges=test_nuclear_charges,
        init_thread_assignments=True,
        hyperparameter_reoptimization=True,
        rng=random,
    )
    print(">>>finished learning curve building:", now())
    for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
        mean_MAEs, _ = learning_curve_from_predictions(
            all_predictions, test_quantities, error_loss_function=loss
        )
        with open(f"learning_curve_{loss_name}.txt", "w") as f:
            for ntr, mean_MAE_val in zip(training_set_sizes, mean_MAEs):
                print(ntr, mean_MAE_val, file=f)


if __name__ == "__main__":
    main()
