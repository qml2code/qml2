#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython SLATM_FreeSolv_full.py SLATM_learn_FreeSolv_$seed $seed
done
