#!/bin/bash

ns_dir=no_shifts

mkdir -p $ns_dir

for seed in 274658 20786 109790 478390
do
	spython SLATM_FreeSolv_full.py SLATM_learn_FreeSolv_$seed $seed False
	cd $ns_dir
	spython ../SLATM_FreeSolv_full.py SLATM_learn_FreeSolv_no_shifts_$seed $seed True
	cd ../
done
