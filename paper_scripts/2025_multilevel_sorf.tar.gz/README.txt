Couple of "dirty" notes:

1. I randomly choose 4 random generator seeds because copy-pasting them everywhere is the easiest way to ensure learning curves are compared over the same training and test sets.

2. The "FreeSolv-0.51" popping up in file descriptions was because v0.51 was downloaded originally due to a mix-up, despite 0.52 being the latest version. I later checked that the same combinations of SMILES and experimental values are imported from FreeSolv-0.52 as from FreeSolv-0.51.
