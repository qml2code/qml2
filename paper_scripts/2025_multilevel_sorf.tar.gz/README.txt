Couple of "dirty" notes:

1. I randomly choose 4 random generator seeds because copy-pasting them everywhere is the easiest way to ensure learning curves are compared over the same training and test sets.

2. The way the scripts are written would make more sense if you keep in mind the changes between the two preprint versions https://arxiv.org/abs/2505.21247v1 and https://arxiv.org/abs/2505.21247v2. In v1 Ninit was individually adjusted for each representation, which in retrospect was unfair because that affected quality of approximating the Gaussian kernel; in v2 everything was calculated with Ninit=Nfeatures everywhere.
