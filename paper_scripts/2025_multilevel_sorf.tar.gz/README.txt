Some notes on the state of the repo to hopefully make correctness verification easier:

1. The "smd_solvent" keyword in these scripts does NOT select SMD when "software" is "tblite", which most of them use (LES with "acetonitrile", FreeSolv with "water"): it is passed to tblite's own ALPB model, as calculator.add("alpb-solvation", solvent) in qml2/orb_ml/tblite_interface. A belatedly noticed naming oversight rather than an attempt to use a solvent model not native to tblite. Note that the scripts which omit "software" -- the savefile_creation*/generate_savefile*.py pair in both datasets -- default to pySCF and therefore do use real SMD, so the keyword means ALPB or SMD depending on the script.

2. Presence of "FJK" in the script names everywhere is due to the original plan being to use FJK rather than FJD.

3. I randomly choose 4 random generator seeds because copy-pasting them everywhere is the easiest way to ensure learning curves are compared over the same training and test sets.

4. The folder includes references to calculations that were planned and sometimes carried out, but then cut from the manuscript; I decided to leave such references there rather than potentially damage reproducibility with a final post-production revision of the scripts. Probably most prominent are references to "deterministic" frequency-ordered scaffold split with acyclic policy set to skeleton (as opposed to its randomized version which was used throughout the manuscript).

5. The way the scripts are written would make more sense if you keep in mind the changes between the two preprint versions https://arxiv.org/abs/2505.21247v1 and https://arxiv.org/abs/2505.21247v2. In v1 Ninit was individually adjusted for each representation, which in retrospect was unfair because that affected quality of approximating the Gaussian kernel; in v2 everything was calculated with Ninit=Nfeatures everywhere.
