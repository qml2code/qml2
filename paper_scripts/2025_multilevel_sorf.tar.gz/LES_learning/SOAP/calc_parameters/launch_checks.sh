#!/bin/bash

spython SOAP_random_K_comparison.py SOAP_random_K_comparison
