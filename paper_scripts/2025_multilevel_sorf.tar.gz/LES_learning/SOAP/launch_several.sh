#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython SOAP_LES_full.py SOAP_learn_LES_$seed $seed
done
