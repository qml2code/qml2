#!/bin/bash

ns_dir=no_shifts

mkdir -p $ns_dir

for seed in 274658 20786 109790 478390
do
	spython SOAP_LES_full.py SOAP_LES_$seed $seed False
	cd $ns_dir
	spython ../SOAP_LES_full.py SOAP_LES_no_shifts_$seed $seed True
	cd ../
done
