"""Scaffold-group distribution of LES, over every grouping parameter.

Prints a summary and writes the full data to RESULTS_DIR/ -- nothing else. The point is to
see how the grouping behaves BEFORE any learning curve is built on it, because the choice
decides whether a scaffold split is even feasible. If one group holds half the dataset, no
split can honour a requested training fraction and the "scaffold-based" curve is really a
curve about that one group.

Parameters swept (see qml2.cheminfo.scaffolds):

  acyclic           what to do with ring-free molecules, whose Murcko scaffold is empty:
                    "pool" (all one group, the literature convention), "skeleton" (group
                    by generic carbon skeleton), or "singleton" (each alone).
  include_chirality RDKit's standard flag, passed through to the canonical SMILES. False
                    makes stereoisomers share a scaffold, which is the usual convention.

Three kinds of output:

  stdout   PARAMETERS: / SUMMARY: per combination, line-oriented and greppable. Read
           largest_fraction first -- anything near 0.5 means that grouping cannot support
           a useful split.
  .csv     the size histogram: one row per distinct group size. Only sizes that actually
           occur get a row, so a plot of it has gaps rather than a tail of zeros.
  .dat     the groups themselves: one LINE per group holding that group's SMILES,
           space-separated, longest group first. SMILES cannot contain a space, so the
           line splits unambiguously.
  SHUFFLE_FILE  one row per grouping with the exact number of DISTINCT random-tie splits that
           grouping admits, for comparing the policies against each other.

SHUFFLES, and the justification for the one non-standard choice here. Of the two grouping
parameters, only `acyclic` departs from the scaffold-split literature: `include_chirality` stays
at the conventional False, where stereoisomers share a scaffold, so every number below is at
otherwise-standard settings and the comparison isolates the acyclic policy. qml2's own docs name
acyclic="pool" as the MoleculeNet/DeepChem convention; this repo uses "skeleton" instead, and the
counts below are the reason.

The random-tie split only varies where a
block of equal-size groups straddles the train/test boundary, so the number of distinct splits
it can produce is a product of binomial coefficients over those blocks -- computed exactly by
`count_possible_shuffles`. Pooling the ring-free molecules merges precisely the population that
sits at that boundary, the singletons and doubletons, into one large group that always lands in
training, and the count collapses with it. At 80/20 on these datasets:

    LES       skeleton  11,171,468 distinct splits      pool  5
    FreeSolv  skeleton     213,213 distinct splits      pool  1

So the convention, acyclic="pool", is the HARDER split -- its test set holds no ring-free
molecule at all, and on FreeSolv that is half the dataset -- but it cannot carry an error bar
over shuffles: on FreeSolv there is exactly ONE split to draw, so four seeds give four identical
runs whose standard deviation is zero while still looking like an error bar. "skeleton" is
chosen for that reason and not because it is easier.

The three policies bracket the choice, which is what makes the case:

    pool       the literature convention. Scaffold-like, but 1 split on FreeSolv: no ensemble.
    skeleton   USED HERE. Still scaffold-like -- ring-free molecules are grouped by their
               generic carbon skeleton, not scattered -- and 213,213 splits to average over.
    singleton  every ring-free molecule alone. Shufflable to excess, but the acyclic half of
               FreeSolv then behaves like a random split, so it is no longer a scaffold split
               for the half of the dataset that matters most.

The pooled split is still worth reporting, as a single deterministic number with no error bar,
which is all it honestly is -- see the acyclic_pool runs in ../acyclic_pool.

Everything lands in RESULTS_DIR/ rather than beside the script, so the script's own folder
stays readable and the whole lot can be deleted in one go and regenerated.
"""

import csv
import math
import os
import warnings
from collections import Counter

import numpy as np

from qml2.cheminfo.scaffolds import scaffold_distribution, scaffold_group_ids
from qml2.dataset_formats.literature_electrochemical_stability import get_oxidation_potentials
from qml2.models.kfolds import frequency_ordered_group_split, group_index_lists


def load_SMILES():
    containing_folder = os.environ["DATA"] + "/literature_electrochemical_stability"
    all_data = get_oxidation_potentials(containing_folder=containing_folder)
    all_SMILES = sorted(list(all_data.keys()))
    # The same guard the learning-curve scripts use: a silently truncated dataset would
    # make every number below wrong in a way that still looks plausible.
    assert len(all_SMILES) == 592
    return all_SMILES


ACYCLIC_VALUES = ["pool", "skeleton", "singleton"]
INCLUDE_CHIRALITY_VALUES = [False, True]

RESULTS_DIR = "scaffold_results"

# Columns ordered (size, count) rather than (count, size): the size is the independent
# variable a histogram is plotted against, and every plotting tool expects it first.
HISTOGRAM_COLUMNS = ["scaffold_group_size", "number_of_scaffold_groups"]
# One row per grouping, collected across the whole sweep and written once: the comparison this
# file is for is BETWEEN policies, so a per-policy file would have to be joined back together.
SHUFFLE_COLUMNS = [
    "acyclic",
    "include_chirality",
    # Where the whole chain starts: how much of the dataset has no ring at all. Policy-independent
    # by construction -- it counts molecules whose Murcko scaffold is empty -- but it is what
    # decides how much damage pooling them does, so it belongs beside the consequence rather than
    # only in the stdout SUMMARY line.
    "n_molecules",
    "acyclic_molecules",
    "acyclic_fraction",
    "n_groups",
    "groups_in_train",
    "groups_in_test",
    "largest_group",
    "realized_train",
    "realized_test",
    "distinct_splits",
    "tie_orderings_digits",
    "straddling_blocks",
    "distinct_test_sets_in_4_seeds",
    "degenerate",
]
SHUFFLE_FILE = "full_scaffold_shuffle_counts.csv"

# Unparsable SMILES become one-molecule groups rather than aborting the survey, and the
# same choice has to be used for the histogram and the group listing or the two would
# describe different groupings.
ON_UNPARSABLE = "singleton"

# The seeds the random-split learning curves already use. Reused here so the
# frequency-ordered ensemble is drawn from the same four draws.
SHUFFLING_SEEDS = (274658, 20786, 109790, 478390)

# The paper's split. Groups are indivisible, so the realized train size only
# approaches this from below.
TRAIN_FRACTION = 0.8


def parameter_tag(acyclic, include_chirality):
    return f"{acyclic}_chirality_{include_chirality}"


def write_histogram(sizes, filename):
    """One row per distinct group size: how many groups hold exactly that many molecules."""
    counts = {}
    for size in sizes:
        counts[int(size)] = counts.get(int(size), 0) + 1
    with open(filename, "w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(HISTOGRAM_COLUMNS)
        for size in sorted(counts):
            writer.writerow([size, counts[size]])
    return len(counts)


def write_groups(all_SMILES, group_ids, filename):
    """One line per group, holding that group's SMILES, largest group first.

    Ties in size keep the order the groups first appear in, so the file is reproducible
    for a given SMILES list rather than depending on dict iteration order.
    """
    members = {}
    for index, group_id in enumerate(group_ids):
        members.setdefault(int(group_id), []).append(all_SMILES[index])
    ordered = sorted(members.items(), key=lambda item: (-len(item[1]), item[0]))
    with open(filename, "w") as dat_file:
        for _, group_SMILES in ordered:
            dat_file.write(" ".join(group_SMILES) + "\n")
    return len(ordered)


def count_possible_shuffles(group_ids, train_size):
    """How many DISTINCT splits the random-tie mode can produce for this grouping, exactly.

    `report_frequency_ordered_split` answers the same question empirically, by running the
    paper's four seeds and counting how many distinct test sets come back. That tells you what
    four draws happened to give; this tells you how many exist. The difference matters when the
    number is small: four seeds drawn from five possibilities typically return three distinct
    splits, which looks like a working ensemble and is not one.

    Two counts, and only the second is meaningful:

      tie_orderings    the number of orderings the shuffle itself can produce, the product of
                       n! over each block of n equal-size groups. Astronomically large and
                       almost entirely redundant, because permuting groups that end up on the
                       same side of the split changes nothing.
      distinct_splits  the number of distinct train/test partitions. `_greedy_group_fill`
                       decides membership from group SIZES alone, so every ordering realizes
                       the same train and test SIZES, and the only freedom is WHICH of the
                       equal-size groups in a block land in train. For a block of n groups of
                       which k are taken, that is C(n, k), and the total is the product over
                       blocks. Blocks taken whole, or not at all, contribute a factor of 1.

    This is what makes the acyclic policy a methodological choice rather than a difficulty
    knob: pooling the ring-free molecules removes exactly the population that sits at the
    train/test boundary -- the singletons and doubletons -- and collapses the count. See the
    SHUFFLES note in the module docstring.
    """
    groups = group_index_lists(group_ids)
    # The splitter's own deterministic key: (size, smallest member index), both descending.
    ordered = sorted(groups, key=lambda g: (len(g), int(g.min())), reverse=True)

    # qml2's fill, mirrored rather than imported, because _greedy_group_fill is private. The
    # assertion below is what keeps the mirror honest: if qml2's rule ever changes, the realized
    # sizes stop matching and this fails instead of quietly counting the wrong thing.
    train_groups, test_groups, running = [], [], 0
    for group in ordered:
        if running + len(group) <= train_size:
            train_groups.append(group)
            running += len(group)
        else:
            test_groups.append(group)

    reference_train, reference_test = frequency_ordered_group_split(group_ids, train_size)
    mirrored_train = (
        np.sort(np.concatenate(train_groups)) if train_groups else np.zeros(0, dtype=int)
    )
    assert np.array_equal(mirrored_train, reference_train), (
        f"the mirrored greedy fill selected {mirrored_train.shape[0]} training points where "
        f"qml2's splitter selected {reference_train.shape[0]}, or chose different ones; the "
        "fill rule has changed and these counts would be wrong"
    )

    total_per_size = Counter(len(group) for group in groups)
    train_per_size = Counter(len(group) for group in train_groups)

    tie_orderings = 1
    for count in total_per_size.values():
        tie_orderings *= math.factorial(count)

    distinct_splits = 1
    straddling = []
    for size in sorted(total_per_size, reverse=True):
        count = total_per_size[size]
        taken = train_per_size.get(size, 0)
        if 0 < taken < count:
            ways = math.comb(count, taken)
            distinct_splits *= ways
            straddling.append(
                {"group_size": size, "groups_in_train": taken, "groups_total": count, "ways": ways}
            )

    return {
        "tie_orderings": tie_orderings,
        "distinct_splits": distinct_splits,
        "straddling_blocks": straddling,
        # How many GROUPS, not molecules, each side gets. This is the cause of a collapsed
        # shuffle count rather than a symptom of it: the fill takes whole groups largest-first,
        # so a grouping whose training block is a handful of large groups has only a handful of
        # placement decisions to make, and none of them is a choice between equal-size groups.
        "groups_in_train": len(train_groups),
        "groups_in_test": len(test_groups),
        "realized_train": int(reference_train.shape[0]),
        "realized_test": int(reference_test.shape[0]),
    }


def report_frequency_ordered_split(all_SMILES, group_ids):
    """Whether the 80/20 frequency-ordered split degenerates for this grouping.

    The random-tie mode only does something if a block of equal-size groups straddles the
    train/test boundary. If none does, every seed returns the SAME split -- an "ensemble"
    of four identical draws whose error bars are identically zero while still looking like
    error bars. That is the failure this reports, and it is a property of the grouping and
    the train size, not of the seeds.

    The seeds are still run, because agreement between them is the direct evidence: the
    warning says the split should be degenerate, the draws show whether it is.

    A second, weaker failure is reported alongside it: a randomized draw that reproduces the
    DETERMINISTIC split exactly. That is a legitimate random outcome rather than a bug, but it
    means the ensemble silently contains a duplicate of the reference point it is supposed to
    be compared against, so the error bar is computed over fewer independent splits than the
    seed count suggests.
    """
    train_size = int(round(TRAIN_FRACTION * len(all_SMILES)))

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        draws = [
            frequency_ordered_group_split(
                group_ids, train_size, shuffle_ties=True, rng=np.random.default_rng(seed)
            )
            for seed in SHUFFLING_SEEDS
        ]
    warned = any("no effect" in str(entry.message) for entry in caught)

    deterministic = frequency_ordered_group_split(group_ids, train_size)
    test_sets = [frozenset(test.tolist()) for _, test in draws]
    distinct = len(set(test_sets))

    deterministic_test = frozenset(deterministic[1].tolist())
    seeds_matching_deterministic = [
        seed
        for seed, test_set in zip(SHUFFLING_SEEDS, test_sets)
        if test_set == deterministic_test
    ]

    moved = set()
    for first in test_sets:
        for second in test_sets:
            moved |= first ^ second
    sizes = {}
    for label in group_ids:
        sizes[int(label)] = sizes.get(int(label), 0) + 1
    moving_sizes = sorted({sizes[int(group_ids[index])] for index in moved})

    return {
        "train_size_target": train_size,
        "realized_train": deterministic[0].shape[0],
        "realized_test": deterministic[1].shape[0],
        "degenerate": warned or distinct == 1,
        "distinct_test_sets": distinct,
        "draws_matching_deterministic": len(seeds_matching_deterministic),
        "seeds_matching_deterministic": seeds_matching_deterministic,
        "molecules_ever_moving": len(moved),
        "moving_group_sizes": moving_sizes,
    }


def main():
    all_SMILES = load_SMILES()
    os.makedirs(RESULTS_DIR, exist_ok=True)
    print("DATASET: LES")
    print(f"MOLECULES: {len(all_SMILES)}")
    print(f"RESULTS_DIR: {RESULTS_DIR}")
    print()

    shuffle_rows = []
    for include_chirality in INCLUDE_CHIRALITY_VALUES:
        for acyclic in ACYCLIC_VALUES:
            distribution = scaffold_distribution(
                all_SMILES,
                acyclic=acyclic,
                include_chirality=include_chirality,
                on_unparsable=ON_UNPARSABLE,
            )
            group_ids = scaffold_group_ids(
                all_SMILES,
                acyclic=acyclic,
                include_chirality=include_chirality,
                on_unparsable=ON_UNPARSABLE,
            )
            print(f"PARAMETERS: acyclic={acyclic} include_chirality={include_chirality}")
            print(
                "SUMMARY:"
                f" n_molecules={distribution['n_molecules']}"
                f" n_groups={distribution['n_groups']}"
                f" largest={distribution['largest_group']}"
                f" largest_fraction={distribution['largest_group_fraction']:.4f}"
                f" singletons={distribution['n_singletons']}"
                f" mean_size={distribution['mean_group_size']:.3f}"
                f" median_size={distribution['median_group_size']:.1f}"
                f" acyclic_molecules={distribution['n_acyclic']}"
                f" unparsable={distribution['n_unparsable']}"
            )

            tag = parameter_tag(acyclic, include_chirality)
            histogram_file = os.path.join(
                RESULTS_DIR, f"full_scaffold_distribution_histogram_{tag}.csv"
            )
            groups_file = os.path.join(RESULTS_DIR, f"full_scaffold_distribution_groups_{tag}.dat")
            nbins = write_histogram(distribution["sizes"], histogram_file)
            ngroups = write_groups(all_SMILES, group_ids, groups_file)
            assert ngroups == distribution["n_groups"]
            print(f"HISTOGRAM: {histogram_file} ({nbins} distinct sizes)")
            print(f"GROUPS: {groups_file} ({ngroups} lines)")

            split = report_frequency_ordered_split(all_SMILES, group_ids)
            print(
                "FREQUENCY_SPLIT:"
                f" train_size_target={split['train_size_target']}"
                f" realized={split['realized_train']}/{split['realized_test']}"
                f" degenerate={split['degenerate']}"
                f" distinct_test_sets={split['distinct_test_sets']}/{len(SHUFFLING_SEEDS)}"
                f" matching_deterministic={split['draws_matching_deterministic']}"
                f" matching_seeds={split['seeds_matching_deterministic']}"
                f" molecules_ever_moving={split['molecules_ever_moving']}"
                f" moving_group_sizes={split['moving_group_sizes']}"
            )

            shuffles = count_possible_shuffles(group_ids, split["train_size_target"])
            blocks = ";".join(
                f"{block['group_size']}:{block['groups_in_train']}/{block['groups_total']}"
                f"->C={block['ways']}"
                for block in shuffles["straddling_blocks"]
            )
            print(
                "SHUFFLES:"
                f" groups_in_train={shuffles['groups_in_train']}/{distribution['n_groups']}"
                f" groups_in_test={shuffles['groups_in_test']}"
                f" distinct_splits={format_count(shuffles['distinct_splits'])}"
                f" tie_orderings_digits={len(str(shuffles['tie_orderings']))}"
                f" straddling_blocks={blocks or 'none'}"
            )
            shuffle_rows.append(
                {
                    "acyclic": acyclic,
                    "include_chirality": include_chirality,
                    "n_molecules": distribution["n_molecules"],
                    "acyclic_molecules": distribution["n_acyclic"],
                    "acyclic_fraction": round(
                        distribution["n_acyclic"] / distribution["n_molecules"], 4
                    ),
                    "n_groups": distribution["n_groups"],
                    "groups_in_train": shuffles["groups_in_train"],
                    "groups_in_test": shuffles["groups_in_test"],
                    "largest_group": distribution["largest_group"],
                    "realized_train": shuffles["realized_train"],
                    "realized_test": shuffles["realized_test"],
                    "distinct_splits": shuffles["distinct_splits"],
                    "tie_orderings_digits": len(str(shuffles["tie_orderings"])),
                    "straddling_blocks": blocks,
                    "distinct_test_sets_in_4_seeds": split["distinct_test_sets"],
                    "degenerate": split["degenerate"],
                }
            )
            print()

    shuffle_file = os.path.join(RESULTS_DIR, SHUFFLE_FILE)
    written = write_shuffle_counts(shuffle_rows, shuffle_file)
    print(f"SHUFFLE_COUNTS: {shuffle_file} ({written} rows)")
    print()
    report_policy_choice(shuffle_rows)


def format_count(count):
    """A readable form of a possibly enormous integer. The CSV keeps the exact value.

    The singleton grouping admits more distinct splits than there are atoms in the observable
    universe -- over 100 digits on FreeSolv -- so printing it in full turns the comparison
    table into a wall of digits and hides the number that matters beside it.
    """
    if count < 10**9:
        return f"{count:,}"
    return f"{float(count):.3e} ({len(str(count))} digits)"


def write_shuffle_counts(rows, filename):
    """The cross-policy comparison, written once -- see SHUFFLES in the module docstring."""
    with open(filename, "w", newline="") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=SHUFFLE_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def report_policy_choice(rows):
    """Print the comparison the acyclic policy is actually chosen on.

    Printed rather than only written, because this is the number that settles the choice and a
    reader of the stdout log should not have to open a CSV to find it.
    """
    ring_free = next((row for row in rows if not row["include_chirality"]), None)
    if ring_free is not None:
        print(
            f"RING_FREE: {ring_free['acyclic_molecules']} of {ring_free['n_molecules']} molecules"
            f" ({100 * ring_free['acyclic_fraction']:.1f}%) have no ring at all, so this is how"
            " much of the dataset the acyclic policy governs"
        )
    print(
        "SHUFFLE_COMPARISON: distinct random-tie splits per acyclic policy, at the conventional"
        " include_chirality=False -- so the acyclic policy is the only axis in question"
    )
    for row in rows:
        if row["include_chirality"]:
            continue
        count = row["distinct_splits"]
        if count <= 1:
            verdict = "NO error bar over shuffles is possible"
        elif count <= len(SHUFFLING_SEEDS) ** 2:
            verdict = "fewer splits than seeds can distinguish -- draws will collide"
        else:
            verdict = "enough for a random-tie ensemble"
        print(
            f"  acyclic={row['acyclic']:<9s} n_groups={row['n_groups']:>4d}"
            f" groups_in_train={row['groups_in_train']:>4d}"
            f" largest={row['largest_group']:>4d}"
            f" distinct_splits={format_count(count):>22s}   {verdict}"
        )
    print(
        "CAUSE: compare n_groups with groups_in_train. The fill takes whole groups largest-first,"
        " so the number of placement decisions it makes is the number of groups it considers --"
        " and a shuffle only changes the outcome where two groups of EQUAL size compete for the"
        " last place in training. Pooling leaves a training block of a few large, distinctly"
        " sized groups, so there is nothing to compete."
    )
    print(
        "VERDICT: pooling the ring-free molecules makes the split harder AND unshufflable, by"
        " merging the boundary population into one always-in-training group. acyclic='skeleton'"
        " is used for the learning curves and error bars because it is the grouping that leaves"
        " a random-tie ensemble something to average over; the pooled split is reported as a"
        " single deterministic number, which is all it honestly is."
    )


if __name__ == "__main__":
    main()
