#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython aSLATM_LES_full.py aSLATM_learn_LES_$seed $seed
done
