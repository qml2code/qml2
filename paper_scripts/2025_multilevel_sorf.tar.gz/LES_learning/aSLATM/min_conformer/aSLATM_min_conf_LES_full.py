import json
import os
import random
import sys

import numpy as np

from qml2.basic_utils import now
from qml2.cheminfo.scaffolds import scaffold_group_ids
from qml2.dataset_formats.literature_electrochemical_stability import get_oxidation_potentials
from qml2.ensemble import Ensemble
from qml2.models.kfolds import frequency_ordered_group_split, group_index_lists
from qml2.models.learning_curves import learning_curve_from_predictions
from qml2.models.loss_functions import MAE, RMSE
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import (
    ElementAugmentedLocalRepresentationCalc,
    ProcessedRepresentationListCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    MinConformerRepresentationCalc,
    local_dn_rep_conformers_list_dict2data,
)
from qml2.representations.calculators import SLATMCalculator

# The grouping the split is built on. Verified non-degenerate for these seeds by
# scaffolds/scaffold_distribution_*.py: four distinct randomized draws, none of which
# reproduces the deterministic one.
SCAFFOLD_ACYCLIC = "skeleton"
SCAFFOLD_INCLUDE_CHIRALITY = False
TRAIN_FRACTION = 0.8


def scaffold_split_mode():
    """Replace the learning curve with a single 80/20 scaffold split, or not.

    --fo_scaffold   frequency-ordered split, deterministic: the reference point, comparable
                    with the scaffold-split literature.
    --rfo_scaffold  same frequency ordering, but same-size groups shuffled with the seed, so
                    several seeds give an ensemble with genuine error bars.

    Stripped from sys.argv like --fjk and --delta-ml, so the positional arguments keep their
    meaning.
    """
    flags = ("--fo_scaffold", "--rfo_scaffold")
    selected = [flag for flag in flags if flag in sys.argv]
    assert len(selected) < 2, "pass at most one of " + ", ".join(flags)
    if not selected:
        return None
    sys.argv = [argument for argument in sys.argv if argument not in selected]
    return selected[0].lstrip("-")


def main():
    scaffold_mode = scaffold_split_mode()
    if len(sys.argv) > 1:
        seed = int(sys.argv[1])
    else:
        seed = 274658

    if len(sys.argv) > 2:
        simple_shifts_str = sys.argv[2]
        assert simple_shifts_str in ["True", "False"]
        simple_shifts = simple_shifts_str == "True"
    else:
        simple_shifts = False

    print("SEED:", seed, "SIMPLE SHIFTS:", simple_shifts, "SCAFFOLD SPLIT:", scaffold_mode)
    if scaffold_mode == "fo_scaffold":
        print("NOTE: the seed does not enter a deterministic split; it only names the job.")

    random.seed(seed)

    containing_folder = os.environ["DATA"] + "/literature_electrochemical_stability"

    r_cut = 0.05
    num_conformers = 32

    savefile_folder = (
        containing_folder
        + "/savefiles_aSLATM_rcut_"
        + str(r_cut)
        + "_num_conformers_"
        + str(num_conformers)
    )

    try:
        os.mkdir(savefile_folder)
    except FileExistsError:
        print("savefile folder already created")

    # Import all data .
    all_data = get_oxidation_potentials(containing_folder=containing_folder)

    all_SMILES = sorted(list(all_data.keys()))
    assert len(all_SMILES) == 592

    # NOTE: the total number of molecules is 592
    training_set_size = 474
    nfeatures = 131072

    if scaffold_mode is None:
        random.shuffle(all_SMILES)
        training_group_ids = None
    else:
        # The deterministic split breaks ties between equal-size groups by smallest member
        # index, so it is only reproducible against a FIXED input order -- shuffling per seed
        # would make "deterministic" name a different split every time. The SMILES therefore
        # stay sorted, and --rfo_scaffold varies only the order WITHIN blocks of equal-size
        # groups, through its own rng.
        group_ids = scaffold_group_ids(
            all_SMILES,
            acyclic=SCAFFOLD_ACYCLIC,
            include_chirality=SCAFFOLD_INCLUDE_CHIRALITY,
        )
        randomized = scaffold_mode == "rfo_scaffold"
        train_indices, test_indices = frequency_ordered_group_split(
            group_ids,
            int(round(TRAIN_FRACTION * len(all_SMILES))),
            shuffle_ties=randomized,
            rng=np.random.default_rng(seed) if randomized else None,
        )
        # Reorder the dataset so the training molecules come first, which lets everything
        # below keep using the plain [:training_set_size] slicing.
        order = list(train_indices) + list(test_indices)
        all_SMILES = [all_SMILES[index] for index in order]
        group_ids = group_ids[order]
        training_set_size = len(train_indices)
        assert not (
            set(group_ids[:training_set_size].tolist())
            & set(group_ids[training_set_size:].tolist())
        ), "a scaffold group straddles the split, so it cannot partition the training set"
        training_group_ids = group_index_lists(group_ids[:training_set_size])
        print(
            f"SCAFFOLD SPLIT: {scaffold_mode}"
            f" train/test={training_set_size}/{len(all_SMILES) - training_set_size}"
            f" groups_in_train={len(training_group_ids)}"
        )

    # For now running without statistical errors

    ensemble_kwargs = {
        "base_class_name": "Compound",
        "num_conformers": num_conformers,
        "r_cut": r_cut,
    }

    ensembles = []
    quant_vals = []

    all_nuclear_charges = []
    present_nuclear_charges = []

    for SMILES in all_SMILES:
        changed_SMILES = SMILES.replace("/", "_")
        ensemble = Ensemble(
            SMILES=SMILES,
            savefile_prefix=savefile_folder + "/" + changed_SMILES,
            **ensemble_kwargs,
        )

        current_nuclear_charges = ensemble.get_nuclear_charges()
        present_nuclear_charges += list(current_nuclear_charges)

        all_nuclear_charges.append(current_nuclear_charges)

        quant_vals.append(all_data[SMILES][0])
        ensembles.append(ensemble)

    print("Number of usable ensembles:", len(ensembles))

    present_nuclear_charges = np.unique(np.array(present_nuclear_charges))

    print("Present nuclear charges:", present_nuclear_charges)

    quant_vals = np.array(quant_vals)

    rep_calculator = ElementAugmentedLocalRepresentationCalc(
        representation_function=SLATMCalculator(all_nuclear_charges),
        possible_nuclear_charges=present_nuclear_charges,
        representation_function_kwargs={"local": True},
    )

    ensemble_rep_calculator = MinConformerRepresentationCalc(rep_calculator)

    parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

    processed_conformer_lists = parallel_calculator(ensembles)

    processed_conformer_lists = local_dn_rep_conformers_list_dict2data(processed_conformer_lists)

    component_bounds = parallel_calculator.component_bounds

    print(component_bounds)

    max_component_bound = parallel_calculator.max_component_bound()
    print(max_component_bound)

    init_size = nfeatures
    assert init_size >= max_component_bound
    print("SORF init_size", init_size)

    nfeature_stacks = nfeatures // init_size

    print("nfeature_stacks:", nfeature_stacks)

    training_conformer_lists = processed_conformer_lists[:training_set_size]
    training_quantities = quant_vals[:training_set_size]

    test_conformer_lists = processed_conformer_lists[training_set_size:]
    test_quantities = quant_vals[training_set_size:]

    function_definition_list = [
        "resize",
        "sorf",
        "element_id_switch",
        "component_sum",
        "normalization",
        "sorf",
        "component_sum",
    ]

    ntransforms = 3

    parameter_list = [
        {"output_size": init_size},
        {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
        {"num_element_ids": len(present_nuclear_charges)},
        {},
        {},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
        {},
    ]

    model = MultilevelSORFModel(
        function_definition_list,
        parameter_list,
        # The quantities are shifted either way now; `simple_shifts` selects HOW the shift
        # is optimized -- fitted directly to the training quantities when True, or against
        # the model's leave-one-out errors when False.
        intensive_quantity_shift=True,
        extensive_quantity_shift=False,
        simple_quantity_shift=simple_shifts,
    )

    training_set_sizes = [50, 100, 200, 400, training_set_size]

    # nperturbations = 4
    # initial_guess_perturbations = (
    #    np.random.random((nperturbations, model.get_nhyperparameters())) - 0.5
    # )
    # initial_guess_perturbations[0, :] = 0.0
    initial_guess_perturbations = None

    if scaffold_mode is not None:
        print(">>>started group-based hyperparameter optimization:", now())
        model.assign_training_set(
            training_conformer_lists,
            training_quantities,
            training_group_ids=training_group_ids,
        )
        model.optimize_hyperparameters(initial_guess_perturbations=initial_guess_perturbations)
        print(">>>finished group-based hyperparameter optimization:", now())
        model.fit(
            training_conformer_lists,
            training_quantities,
        )
        predictions = model.get_all_predictions(test_conformer_lists)
        errors = predictions - test_quantities
        # Names the run inside the file: collating one number per job across modes, seeds and
        # methods is otherwise guesswork about which directory it came from. The seed is
        # recorded even for the deterministic mode, where it does not enter the split, so that
        # every file has the same fields.
        run_description = (
            f"mode={scaffold_mode} seed={seed} simple_shifts={simple_shifts}"
            f" acyclic={SCAFFOLD_ACYCLIC} include_chirality={SCAFFOLD_INCLUDE_CHIRALITY}"
            f" train={training_set_size} test={len(test_quantities)}"
        )
        for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
            value = float(loss(errors))
            print(f"{loss_name}: {value}")
            with open(f"scaffold_split_{loss_name}.txt", "w") as error_file:
                print(f"# {loss_name} {run_description}", file=error_file)
                print(value, file=error_file)

        # Per-molecule predictions AND references, so the split can be re-analysed (per-scaffold
        # errors, the worst offenders, a parity plot) without rerunning the fit and without a
        # second lookup into the dataset. Keyed by SMILES rather than by index because the index
        # only means something relative to this split's ordering, which the scaffold modes
        # permute; the two maps therefore share their keys.
        test_SMILES = all_SMILES[training_set_size:]
        assert len(test_SMILES) == len(predictions)
        assert len(set(test_SMILES)) == len(test_SMILES), "SMILES keys must be unique"
        predictions_file = "scaffold_split_predictions.json"
        with open(predictions_file, "w") as json_file:
            json.dump(
                {
                    "description": run_description,
                    "predictions": {
                        SMILES: float(value) for SMILES, value in zip(test_SMILES, predictions)
                    },
                    "references": {
                        SMILES: float(value) for SMILES, value in zip(test_SMILES, test_quantities)
                    },
                },
                json_file,
                indent=2,
                sort_keys=True,
            )
        print(f"PREDICTIONS: {predictions_file} ({len(test_SMILES)} molecules)")
        return

    print(">>>started learning curve building:", now())
    all_predictions = model.learning_curve_predictions(
        training_conformer_lists,
        training_quantities,
        test_conformer_lists,
        training_set_sizes,
        max_subset_num=1,
        hyperparameter_reoptimization=True,
        hyperparameter_optimization_kwargs={
            "initial_guess_perturbations": initial_guess_perturbations
        },
        rng=random,
    )
    print(">>>finished learning curve building:", now())
    for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
        mean_MAEs, _ = learning_curve_from_predictions(
            all_predictions, test_quantities, error_loss_function=loss
        )
        with open(f"learning_curve_{loss_name}.txt", "w") as f:
            for ntr, mean_MAE_val in zip(training_set_sizes, mean_MAEs):
                print(ntr, mean_MAE_val, file=f)


if __name__ == "__main__":
    main()
