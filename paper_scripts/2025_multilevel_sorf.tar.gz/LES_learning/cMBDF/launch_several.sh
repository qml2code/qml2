#!/bin/bash

ns_dir=no_shifts

mkdir -p $ns_dir

for seed in 274658 20786 109790 478390
do
	spython cMBDF_LES_full.py cMBDF_LES_$seed $seed False
	cd $ns_dir
	spython ../cMBDF_LES_full.py cMBDF_LES_no_shifts_$seed $seed True
	cd ../
done
