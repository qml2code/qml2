#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython cMBDF_LES_full.py cMBDF_learn_LES_$seed $seed
done
