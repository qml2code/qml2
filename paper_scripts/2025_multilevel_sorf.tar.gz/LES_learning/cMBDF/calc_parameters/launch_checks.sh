#!/bin/bash

# K matrices
spython cMBDF_random_K_comparison.py cMBDF_random_K_comparison
spython cMBDF_random_K_comparison_nconfs.py cMBDF_random_K_comparison_nconfs

# leave-one-out loss functions; in the end K matrices look like a more rigorous criterium
# spython cMBDF_loss_comparison_nconfs.py cMBDF_loss_comparison_nconfs
# spython cMBDF_loss_comparison_ntransforms.py cMBDF_loss_comparison_ntransforms
