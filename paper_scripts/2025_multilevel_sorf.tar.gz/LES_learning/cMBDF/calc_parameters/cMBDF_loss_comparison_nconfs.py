import os
import random
import sys

import numpy as np

from qml2.dataset_formats.literature_electrochemical_stability import get_oxidation_potentials
from qml2.ensemble import Ensemble
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import (
    ElementAugmentedLocalRepresentationCalc,
    ProcessedRepresentationListCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    EnsembleRepresentationCalc,
    local_dn_rep_ensemble_list_dict2datatype,
)
from qml2.representations.calculators import cMBDFCalculator
from qml2.utils import roundup_power2


def main():
    if len(sys.argv) > 1:
        seed = int(sys.argv[1])
    else:
        seed = 274658
    random.seed(seed)

    containing_folder = os.environ["DATA"] + "/literature_electrochemical_stability"

    ntransforms = 2

    r_cut = 0.05  # None

    # Import all data.
    all_data = get_oxidation_potentials(containing_folder=containing_folder)

    all_SMILES = sorted(list(all_data.keys()))
    assert len(all_SMILES) == 592

    # NOTE: the total number of molecules is 592
    training_set_size = 474
    nfeatures = 32768

    random.shuffle(all_SMILES)

    training_SMILES = all_SMILES[:training_set_size]

    def get_loss(num_conformers):
        #    savefile_folder = (
        #        containing_folder
        #        + "/savefiles_cMBDF_rcut_"
        #        + str(r_cut)
        #        + "_num_conformers_"
        #        + str(num_conformers)
        #    )
        #    try:
        #        os.mkdir(savefile_folder)
        #    except FileExistsError:
        #        pass
        #        print("savefile folder already created")

        ensemble_kwargs = {
            "base_class_name": "Compound",
            "num_conformers": num_conformers,
            "r_cut": r_cut,
        }

        training_ensembles = []

        training_nuclear_charges = []
        present_nuclear_charges = []

        training_quantities = np.empty(training_set_size)

        for i, SMILES in enumerate(training_SMILES):
            #        changed_SMILES = SMILES.replace("/", "_")
            #        savefile_prefix=savefile_folder + "/" + changed_SMILES
            ensemble = Ensemble(SMILES=SMILES, savefile_prefix=None, **ensemble_kwargs)

            current_nuclear_charges = ensemble.get_nuclear_charges()

            training_nuclear_charges.append(current_nuclear_charges)
            present_nuclear_charges += list(current_nuclear_charges)

            training_ensembles.append(ensemble)
            training_quantities[i] = all_data[SMILES][0]

        present_nuclear_charges = np.unique(np.array(present_nuclear_charges))

        rep_calculator = ElementAugmentedLocalRepresentationCalc(
            representation_function=cMBDFCalculator(training_nuclear_charges),
            possible_nuclear_charges=present_nuclear_charges,
        )

        ensemble_rep_calculator = EnsembleRepresentationCalc(rep_calculator)

        parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

        training_ensemble_dicts = parallel_calculator(training_ensembles)

        training_ensembles = local_dn_rep_ensemble_list_dict2datatype(training_ensemble_dicts)

        max_component_bound = parallel_calculator.max_component_bound()

        init_size = roundup_power2(max_component_bound)

        nfeature_stacks = nfeatures // init_size

        function_definition_list = [
            "resize",
            "sorf",
            "element_id_switch",
            "component_sum",
            "normalization",
            "sorf",
            "weighted_component_sum",
            "component_sum",
            "normalization",
            "sorf",
        ]

        parameter_list = [
            {"output_size": init_size},
            {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
            {"num_element_ids": len(present_nuclear_charges)},
            {},
            {},
            {"nfeature_stacks": 1, "ntransforms": ntransforms},
            {},
            {},
            {},
            {"nfeature_stacks": 1, "ntransforms": ntransforms},
        ]

        model = MultilevelSORFModel(
            function_definition_list,
            parameter_list,
            hyperparameter_optimizer="boss",
            boss_compromise_coeff=1.25e-1,
            intensive_quantity_shift=True,
            extensive_quantity_shift=False,
        )
        model.assign_training_set(
            training_ensembles,
            training_quantities,
            training_nuclear_charges=training_nuclear_charges,
        )
        model.find_initial_guesses()

        return model.get_loss_function_ln_hyperparameters(
            np.log(model.hyperparameter_initial_guesses)
        )

    nlosses = 8

    loss_bench = None

    for nconfs in [1024, 512, 256, 128, 64, 32, 16, 8]:
        losses_new = np.empty(nlosses)
        for i_mat in range(nlosses):
            losses_new[i_mat] = get_loss(nconfs)
        loss_mean = np.mean(losses_new)
        loss_std = np.std(losses_new) / np.sqrt(float(nlosses))
        if loss_bench is None:
            loss_bench = loss_mean
        else:
            diff = loss_mean - loss_bench
            print(
                "___",
                nconfs,
                loss_mean,
                diff,
                loss_std * np.sqrt(2.0),
            )


if __name__ == "__main__":
    main()
