#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython FCHL19_LES_full.py FCHL19_learn_LES_$seed $seed
done
