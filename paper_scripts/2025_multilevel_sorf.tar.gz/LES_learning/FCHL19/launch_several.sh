#!/bin/bash

# Learning curves scale poorly across every core this node reports, so ask spython for a
# smaller allocation than the hardware. An explicit --CPUs= would still override this.
export SPYTHON_ASSUMED_NCPUS=16

ss_dir=simple_shifts

ss_dir_fo=simple_shifts_fo_scaffold
ss_dir_rfo=simple_shifts_rfo_scaffold
mkdir -p $ss_dir $ss_dir_fo $ss_dir_rfo


# One 80/20 frequency-ordered scaffold split instead of a learning curve, with
# group-based hyperparameter optimization. The deterministic split is a property of the
# grouping and the train size, not of a seed, so it is submitted once; a seed is still
# passed because the argument is positional.
cd $ss_dir_fo
spython ../FCHL19_LES_full.py FCHL19_fo_scaffold_LES_simple_shifts --fo_scaffold 274658 True
cd ../

for seed in 274658 20786 109790 478390
do
	spython FCHL19_LES_full.py FCHL19_LES_$seed $seed False
	cd $ss_dir
	spython ../FCHL19_LES_full.py FCHL19_LES_simple_shifts_$seed $seed True
	cd ../
	cd $ss_dir_rfo
	spython ../FCHL19_LES_full.py FCHL19_rfo_scaffold_LES_simple_shifts_$seed --rfo_scaffold $seed True
	cd ../
done
