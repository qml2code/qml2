#!/bin/bash

spython FCHL19_random_K_comparison.py FCHL19_random_K_comparison
