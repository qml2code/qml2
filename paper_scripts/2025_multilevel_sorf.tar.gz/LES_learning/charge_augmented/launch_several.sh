#!/bin/bash
# Learning curves for FCHL19/aSLATM augmented with GFN2 atomic charges.
#
# Four axes. The two the study is about -- base representation and one state versus two --
# are carried in the job NAME, so every combination lands in its own data_ directory without
# a deeper tree. The shift axis and the conformer axis use directories, as the FJK and
# FCHL19 launchers next door do.
#
# One number for both the cores and the threads. --CPUs doubles as a MEMORY request on this
# node (CR_Core_Memory, DefMemPerCPU=MaxMemPerCPU=2681), so 16 buys 42 GB and whatever is
# asked for is also what OpenMP gets. The CPU_times scripts keep cores and threads apart
# because they MEASURE CPU time, where threads bought for memory would inflate the number
# being reported; nothing is timed here, so the split would be complication without purpose.
#
# BOTH representations now ask for 16. aSLATM used to ask for 80 (210 GB) and still ran out:
# every conformer's representation was materialised and held for the whole SORF pass, and a
# two-state pair held two nearly identical copies of it, which is what OOM-killed the pair runs
# on both datasets and the sdet runs on LES. The representation is now computed INSIDE the
# parallel loop by multilevel_sorf's calculate_representation level and never stored, so the
# allocation buys nothing beyond the cores themselves. The results those jobs did produce are
# kept under precomputed_rep_results/ as reference values for the new path.
#

# Cores AND threads AND memory, one number, both representations -- see the note above.
compute_threads=16

script=charge_augmented_LES_full.py

# The deterministic scaffold split does not depend on the seed, so it is submitted on
# this seed's pass only. The rep/det axes still apply to it, which is why it is guarded
# inside the loops rather than hoisted out of them.
fo_seed=274658

ss_dir=simple_shifts
# Same shifts, but learning the residual against the energy difference the pair's own two
# states already give, instead of the experimental value itself. Ensemble runs only: the
# reference is a conformer-weighted average, so it is the ensemble that gives it meaning.
ss_dml_dir=simple_shifts_dml
mc_ss_dir=min_conformer/simple_shifts

ss_dir_fo=simple_shifts_fo_scaffold
ss_dir_rfo=simple_shifts_rfo_scaffold
ss_dml_dir_fo=simple_shifts_dml_fo_scaffold
ss_dml_dir_rfo=simple_shifts_dml_rfo_scaffold
mc_ss_dir_fo=min_conformer/simple_shifts_fo_scaffold
mc_ss_dir_rfo=min_conformer/simple_shifts_rfo_scaffold

# --no_charges + delta-ML: the base representation ALONE, no charge column. Flat names following
# the convention above -- shift mode leads, modifiers follow, split last -- where the absence of a
# `simple_shifts` prefix means hyperparameter shifts, as it does elsewhere in this folder.
nc_dml_dir=no_charges_dml
nc_dml_dir_fo=no_charges_dml_fo_scaffold
nc_dml_dir_rfo=no_charges_dml_rfo_scaffold
ss_nc_dml_dir=simple_shifts_no_charges_dml
ss_nc_dml_dir_fo=simple_shifts_no_charges_dml_fo_scaffold
ss_nc_dml_dir_rfo=simple_shifts_no_charges_dml_rfo_scaffold

mkdir -p $ss_dir $ss_dml_dir $mc_ss_dir $ss_dir_fo $ss_dir_rfo $ss_dml_dir_fo $ss_dml_dir_rfo $mc_ss_dir_fo $mc_ss_dir_rfo \
  $nc_dml_dir $nc_dml_dir_fo $nc_dml_dir_rfo $ss_nc_dml_dir $ss_nc_dml_dir_fo $ss_nc_dml_dir_rfo

for seed in 274658 20786 109790 478390
do
	for rep_name in "FCHL19" "aSLATM"
	do
		if [ "$rep_name" == "aSLATM" ]
		then
			rep_flag=--aslatm
		else
			rep_flag=
		fi

		for det_name in "pair" "sdet"
		do
			if [ "$det_name" == "sdet" ]
			then
				det_flag=--sdet
			else
				det_flag=
			fi

			tag=${rep_name}_charges_${det_name}_LES
			fo_tag=${rep_name}_charges_${det_name}_fo_scaffold_LES
			rfo_tag=${rep_name}_charges_${det_name}_rfo_scaffold_LES

			# HYPERPARAMETER-shift runs, parked rather than removed. Not "no shift": the
			# quantities are shifted either way, and the positional False selects HOW the
			# coefficients are optimized -- against the model's cross-validation errors
			# (leave-one-out, or leave-one-GROUP-out for the scaffold splits) instead of
			# fitted directly to the training quantities, which is what True does. See the
			# "shifted either way" note beside simple_quantity_shift in the script.
			#
			# Parked because every charge-augmented comparison here uses simple shifts, so
			# the shift axis would multiply the job count without bearing on them. The
			# --no_charges groups below DO submit both modes: there the shift axis is part
			# of the question, since those runs are read against the plain scripts.
			# spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
			#	$script "${tag}_$seed" $rep_flag $det_flag $seed False

			cd $ss_dir
			spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
				../$script "${tag}_simple_shifts_$seed" $rep_flag $det_flag $seed True
			cd ../

			# Delta-ML, for the ensemble runs only -- see ss_dml_dir above.
			cd $ss_dml_dir
			spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
				../$script "${tag}_simple_shifts_dml_$seed" \
				$rep_flag $det_flag --delta-ml $seed True
			cd ../

			# Minimum-energy conformer only, for simple shifts alone -- the same restraint
			# the FJK min_conf runs use: this axis answers what the ensemble buys over its
			# best conformer, and sweeping the others too would multiply the runs without
			# bearing on that question.
			cd $mc_ss_dir
			spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
				../../$script "${tag}_min_conf_simple_shifts_$seed" \
				$rep_flag $det_flag --min_conf $seed True
			cd ../../

			# Scaffold-split runs: one 80/20 frequency-ordered split with group-based hyperparameter
			# optimization, crossed with the same delta-ML and minimum-conformer axes as above.
			if [ "$seed" == "$fo_seed" ]
			then
				cd $ss_dir_fo
				spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
					../$script "${fo_tag}_simple_shifts" $rep_flag $det_flag --fo_scaffold $fo_seed True
				cd ../

				cd $ss_dml_dir_fo
				spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
					../$script "${fo_tag}_simple_shifts_dml" \
					$rep_flag $det_flag --delta-ml --fo_scaffold $fo_seed True
				cd ../

				cd $mc_ss_dir_fo
				spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
					../../$script "${fo_tag}_min_conf_simple_shifts" \
					$rep_flag $det_flag --min_conf --fo_scaffold $fo_seed True
				cd ../../
			fi

			cd $ss_dir_rfo
			spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
				../$script "${rfo_tag}_simple_shifts_$seed" $rep_flag $det_flag --rfo_scaffold $seed True
			cd ../

			cd $ss_dml_dir_rfo
			spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
				../$script "${rfo_tag}_simple_shifts_dml_$seed" \
				$rep_flag $det_flag --delta-ml --rfo_scaffold $seed True
			cd ../

			cd $mc_ss_dir_rfo
			spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
				../../$script "${rfo_tag}_min_conf_simple_shifts_$seed" \
				$rep_flag $det_flag --min_conf --rfo_scaffold $seed True
			cd ../../
		done

		# The base representation ALONE, crossed with delta-ML. With --sdet and a single
		# rescaling region this is the same model as the plain FCHL19/aSLATM scripts
		# (`rescaling` over one region followed by `unscaled_sorf` IS `sorf`), so these runs
		# isolate what delta-ML alone buys and those plain curves are their baseline.
		#
		# OUTSIDE the det loop deliberately: --no_charges REQUIRES --sdet, because without the
		# charge column a pair's two states get identical vectors and the pair level subtracts
		# them to exactly zero. Submitted from inside, half of these would be refused by the
		# script's own guard.
		nc_tag=${rep_name}_nocharges_sdet_LES
		nc_fo_tag=${rep_name}_nocharges_sdet_fo_scaffold_LES
		nc_rfo_tag=${rep_name}_nocharges_sdet_rfo_scaffold_LES

		# Hyperparameter shifts (positional False) and simple shifts (True). The quantities are
		# shifted either way; the positional selects HOW the coefficients are optimized.
		cd $nc_dml_dir
		spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
			../$script "${nc_tag}_dml_$seed" \
			$rep_flag --sdet --no_charges --delta-ml $seed False
		cd ../

		cd $ss_nc_dml_dir
		spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
			../$script "${nc_tag}_simple_shifts_dml_$seed" \
			$rep_flag --sdet --no_charges --delta-ml $seed True
		cd ../

		if [ "$seed" == "$fo_seed" ]
		then
			cd $nc_dml_dir_fo
			spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
				../$script "${nc_fo_tag}_dml" \
				$rep_flag --sdet --no_charges --delta-ml --fo_scaffold $fo_seed False
			cd ../

			cd $ss_nc_dml_dir_fo
			spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
				../$script "${nc_fo_tag}_simple_shifts_dml" \
				$rep_flag --sdet --no_charges --delta-ml --fo_scaffold $fo_seed True
			cd ../
		fi

		cd $nc_dml_dir_rfo
		spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
			../$script "${nc_rfo_tag}_dml_$seed" \
			$rep_flag --sdet --no_charges --delta-ml --rfo_scaffold $seed False
		cd ../

		cd $ss_nc_dml_dir_rfo
		spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
			../$script "${nc_rfo_tag}_simple_shifts_dml_$seed" \
			$rep_flag --sdet --no_charges --delta-ml --rfo_scaffold $seed True
		cd ../
	done
done
