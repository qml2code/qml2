#!/bin/bash
# FJD/FJK learning curves for LES -- LINEAR variant.
#
# LINEAR is the one thing this varies against LES_learning/FJK/: the SORF that followed the
# molecule-level sum and the normalization+SORF that followed the ensemble sum are both gone, so
# above the per-orbital SORF the stack is plain (weighted) sums. The `normalization`+`sorf` in the
# middle stays, which is legitimate -- a `sorf` carries its own sigma and only duplicates one when
# it follows a `rescaling`, which that one does not.
#
# Learning curves scale poorly across every core this node reports, so ask spython for a
# smaller allocation than the hardware. An explicit --CPUs= would still override this.
export SPYTHON_ASSUMED_NCPUS=16

# Named once rather than repeated per call: this file carried the pre-revision name
# (FJK_LES_full.py) in all nine invocations after the script was renamed, which is a sweep that
# fails on every job with "No such file or directory".
script=FJD_LES_linear_full.py

# FJD unless --fjk is passed, which selects the representation the paper used. The job name
# follows the choice: spython refuses to reuse an existing data directory, so the two must
# not land on the same one.
#
# The _linear suffix is not decoration. The original runs in the paper repo are named
# data_FJD_LES_<seed>, which is exactly what ${rep}_LES_$seed would produce here -- two different
# models under one name, indistinguishable once the data dirs are read together. Drop the suffix
# only if the intention is to replace those results rather than compare against them.
if [ "$1" == "--fjk" ]
then
    rep=FJK_linear
    rep_flag=--fjk
else
    rep=FJD_linear
    rep_flag=
fi

# The shift axis. Both modes are submitted: the quantities are shifted either way, and the
# positional True/False selects HOW the coefficients are optimized -- fitted directly to the
# training quantities (True), or against the model's cross-validation errors (False), which is
# leave-one-out here and leave-one-GROUP-out for the scaffold runs that assign group ids.
#
# NOTE: This is probably the only calculation series whether choosing "hyperparameter" shifts over
# "simple" shifts has a physical justification since a hypotheticalmolecule whose FJD/FJK representation
# does not change if an electron is subtracted from it should have oxidation potential w.r.t. vacuum
# as exact zero, an intercept which is not reflected by taking the average of labels.
#
# The False runs land in the top-level directory, as they always have; dml_dir is their delta-ML
# counterpart, which this launcher was missing.
dml_dir=dml
# The scaffold splits with the non-simple shift, which is where the shift mode actually changes
# meaning: these runs assign group ids, so their shift is optimized against leave-one-GROUP-out
# errors rather than leave-one-out. Named without a `simple_shifts` prefix, the way the non-simple
# learning curves above are named.
fo_dir=fo_scaffold
rfo_dir=rfo_scaffold
dml_fo_dir=dml_fo_scaffold
dml_rfo_dir=dml_rfo_scaffold
ss_dir=simple_shifts
# Same shifts, but learning the residual against the pair's own ionization potential
# instead of the oxidation potential itself.
ss_dml_dir=simple_shifts_dml

# One conformer per molecule instead of the weighted ensemble, the counterpart of the
# min_conformer/ runs aSLATM, FCHL19 and CM already have. BOTH shift modes are submitted, so
# "what does the ensemble buy over its best conformer" can be answered against either shift
# axis rather than only the simple one, and so is the delta-ML axis: the ensemble side has it
# for every shift mode and split, so leaving it out here would be the one hole in the grid --
# and the answer need not be the same with and without a reference to lean on.
#
# NOTE on the delta-ML pair: the subtracted reference stays the conformer-weighted ensemble
# difference even under --min_conf, because the script builds it from the ensembles before it
# chooses a representation (ensemble_ionization_potential in FJD_LES_linear_full.py). That is
# DELIBERATE and should stay so. Holding the reference fixed keeps the only varied axis the
# representation, which makes this a comparison of conformer against ensemble REPRESENTATION
# efficiency. Letting the reference follow the representation would instead compare two
# delta-ML references' quality -- a separate question, and one that would confound this one,
# since a weaker reference leaves a larger residual to learn and the two effects would arrive
# in the same number. So these runs are deliberately not a single-conformer pipeline end to
# end: do not "fix" them by subtracting each molecule's own chosen conformer.
#
# It reuses the ensemble run's savefiles -- the ab initio results are per conformer and the
# folder name is deliberately unchanged -- so it adds no quantum chemistry, only learning.
#
# Directory naming follows the top level: the simple-shift runs carry a `simple_shifts`
# prefix, the non-simple ones carry none, which puts the non-simple learning curve in
# min_conformer/ itself just as its ensemble counterpart sits in the top-level directory.
mc_ss_dir=min_conformer/simple_shifts
mc_dir=min_conformer
# Their delta-ML counterparts, named the way the ensemble ones are: `dml` inserted where the
# top-level directories insert it, so min_conformer/ mirrors the top level directory for
# directory.
mc_ss_dml_dir=min_conformer/simple_shifts_dml
mc_dml_dir=min_conformer/dml

ss_dir_fo=simple_shifts_fo_scaffold
ss_dir_rfo=simple_shifts_rfo_scaffold
ss_dml_dir_fo=simple_shifts_dml_fo_scaffold
ss_dml_dir_rfo=simple_shifts_dml_rfo_scaffold
mc_ss_dir_fo=min_conformer/simple_shifts_fo_scaffold
mc_ss_dir_rfo=min_conformer/simple_shifts_rfo_scaffold
mc_dir_fo=min_conformer/fo_scaffold
mc_dir_rfo=min_conformer/rfo_scaffold
mc_ss_dml_dir_fo=min_conformer/simple_shifts_dml_fo_scaffold
mc_ss_dml_dir_rfo=min_conformer/simple_shifts_dml_rfo_scaffold
mc_dml_dir_fo=min_conformer/dml_fo_scaffold
mc_dml_dir_rfo=min_conformer/dml_rfo_scaffold
mkdir -p $dml_dir $fo_dir $rfo_dir $dml_fo_dir $dml_rfo_dir $ss_dir $ss_dml_dir $mc_ss_dir $ss_dir_fo $ss_dir_rfo $ss_dml_dir_fo $ss_dml_dir_rfo $mc_ss_dir_fo $mc_ss_dir_rfo $mc_dir $mc_dir_fo $mc_dir_rfo $mc_ss_dml_dir $mc_dml_dir $mc_ss_dml_dir_fo $mc_ss_dml_dir_rfo $mc_dml_dir_fo $mc_dml_dir_rfo


# One 80/20 frequency-ordered scaffold split instead of a learning curve, with
# group-based hyperparameter optimization. The deterministic split is a property of the
# grouping and the train size, not of a seed, so it is submitted once; a seed is still
# passed because the argument is positional.
cd $ss_dir_fo
spython ../$script ${rep}_fo_scaffold_LES_simple_shifts $rep_flag --fo_scaffold 274658 True
cd ../
cd $ss_dml_dir_fo
spython ../$script ${rep}_fo_scaffold_LES_simple_shifts_dml $rep_flag --delta-ml --fo_scaffold 274658 True
cd ../
cd $mc_ss_dir_fo
spython ../../$script ${rep}_min_conf_fo_scaffold_LES_simple_shifts $rep_flag --min_conf --fo_scaffold 274658 True
cd ../../
cd $mc_ss_dml_dir_fo
spython ../../$script ${rep}_min_conf_fo_scaffold_LES_simple_shifts_dml $rep_flag --min_conf --delta-ml --fo_scaffold 274658 True
cd ../../
cd $mc_dir_fo
spython ../../$script ${rep}_min_conf_fo_scaffold_LES $rep_flag --min_conf --fo_scaffold 274658 False
cd ../../
cd $mc_dml_dir_fo
spython ../../$script ${rep}_min_conf_fo_scaffold_LES_dml $rep_flag --min_conf --delta-ml --fo_scaffold 274658 False
cd ../../
cd $fo_dir
spython ../$script ${rep}_fo_scaffold_LES $rep_flag --fo_scaffold 274658 False
cd ../
cd $dml_fo_dir
spython ../$script ${rep}_fo_scaffold_LES_dml $rep_flag --delta-ml --fo_scaffold 274658 False
cd ../

for seed in 274658 20786 109790 478390
do
	spython $script ${rep}_LES_$seed $rep_flag $seed False
	# The delta-ML counterpart of the run above: same non-simple shift, learning the residual
	# against the pair's own ionization potential. Its own directory, because spython refuses to
	# reuse a data directory and these two differ only in a flag.
	cd $dml_dir
	spython ../$script ${rep}_LES_dml_$seed $rep_flag --delta-ml $seed False
	cd ../
	cd $ss_dir
	spython ../$script ${rep}_LES_simple_shifts_$seed $rep_flag $seed True
	cd ../
	cd $ss_dml_dir
	spython ../$script ${rep}_LES_simple_shifts_dml_$seed $rep_flag --delta-ml $seed True
	cd ../
	cd $mc_ss_dir
	spython ../../$script ${rep}_min_conf_LES_simple_shifts_$seed $rep_flag --min_conf $seed True
	cd ../../
	cd $mc_ss_dml_dir
	spython ../../$script ${rep}_min_conf_LES_simple_shifts_dml_$seed $rep_flag --min_conf --delta-ml $seed True
	cd ../../
	# One level up, not two: this one runs in min_conformer/ itself.
	cd $mc_dir
	spython ../$script ${rep}_min_conf_LES_$seed $rep_flag --min_conf $seed False
	cd ../
	# Two levels again: unlike the run above, its delta-ML counterpart has its own
	# subdirectory, because spython refuses to reuse a data directory.
	cd $mc_dml_dir
	spython ../../$script ${rep}_min_conf_LES_dml_$seed $rep_flag --min_conf --delta-ml $seed False
	cd ../../
	cd $ss_dir_rfo
	spython ../$script ${rep}_rfo_scaffold_LES_simple_shifts_$seed $rep_flag --rfo_scaffold $seed True
	cd ../
	cd $ss_dml_dir_rfo
	spython ../$script ${rep}_rfo_scaffold_LES_simple_shifts_dml_$seed $rep_flag --delta-ml --rfo_scaffold $seed True
	cd ../
	cd $mc_ss_dir_rfo
	spython ../../$script ${rep}_min_conf_rfo_scaffold_LES_simple_shifts_$seed $rep_flag --min_conf --rfo_scaffold $seed True
	cd ../../
	cd $mc_ss_dml_dir_rfo
	spython ../../$script ${rep}_min_conf_rfo_scaffold_LES_simple_shifts_dml_$seed $rep_flag --min_conf --delta-ml --rfo_scaffold $seed True
	cd ../../
	cd $mc_dir_rfo
	spython ../../$script ${rep}_min_conf_rfo_scaffold_LES_$seed $rep_flag --min_conf --rfo_scaffold $seed False
	cd ../../
	cd $mc_dml_dir_rfo
	spython ../../$script ${rep}_min_conf_rfo_scaffold_LES_dml_$seed $rep_flag --min_conf --delta-ml --rfo_scaffold $seed False
	cd ../../
	cd $rfo_dir
	spython ../$script ${rep}_rfo_scaffold_LES_$seed $rep_flag --rfo_scaffold $seed False
	cd ../
	cd $dml_rfo_dir
	spython ../$script ${rep}_rfo_scaffold_LES_dml_$seed $rep_flag --delta-ml --rfo_scaffold $seed False
	cd ../
done
