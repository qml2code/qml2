import os
import random
import sys
from copy import deepcopy
from typing import List

import numpy as np
from ase.atoms import Atoms
from dscribe.descriptors import SOAP

from qml2.basic_utils import dump2pkl, loadpkl, total_cpu_time
from qml2.compound_list import CompoundList
from qml2.dataset_formats.literature_electrochemical_stability import get_oxidation_potentials
from qml2.ensemble import Ensemble
from qml2.math import cho_solve, inplace_orthogonalize_vectors, regression_using_Z
from qml2.models.krr import KRRLocalModel, KRRModel
from qml2.multilevel_sorf.base_constructors import get_transform_list_dict2datatype
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import ProcessedRepresentationListCalc
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    MinConformerRepresentationCalc,
    local_dn_rep_conformers_list_dict2data,
)
from qml2.multilevel_sorf.processed_object_constructors.fjk import FJKRepresentationCalc
from qml2.multilevel_sorf.processed_object_constructors.fjk import comp_rep_def as fjk_comp_rep_def
from qml2.multilevel_sorf.processed_object_constructors.standard import (
    ElementAugmentedLocalRepresentationCalc,
    GlobalRepresentationCalc,
    LocalRepresentationCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.utils import (
    transform_2D_representations_into_principal_component_versions,
)
from qml2.orb_ml.models import FJKModel
from qml2.orb_ml.representations import OML_rep_params
from qml2.parallelization import embarrassingly_parallel
from qml2.representations.calculators import (
    CMCalculator,
    FCHL19Calculator,
    SLATMCalculator,
    cMBDFCalculator,
)

global_reps = ["CM", "SLATM", "SLATM_projected"]

fjk_reps = ["FJK", "FJK_sdet"]

local_reps = ["SOAP"]

local_dn_reps = ["cMBDF", "FCHL19", "aSLATM"]

local_rep_conformers_list_dict2data = get_transform_list_dict2datatype(["array_2D", "list"])

fjk_rep_conformers_list_dict2data = get_transform_list_dict2datatype(fjk_comp_rep_def + ["list"])

default_oml_rep_params = OML_rep_params(max_angular_momentum=1)

#
use_Huckel = True
basis = "6-311G"  # "sto-3g"
solvent = "acetonitrile"
common_fjk_kwargs = {
    "use_Huckel": use_Huckel,
    "basis": basis,
    "localization_procedure": "Boys",
}

# for FJK rep
pair_fjk_comp_extra_kwargs = {
    "compound_kwargs": {
        **common_fjk_kwargs,
        "second_oml_comp_kwargs": {"charge": 1, "calc_type": "UHF"},
    },
    "base_class_name": "OML_Slater_pair",
}

fjk_comp_extra_kwargs = {
    "compound_kwargs": {
        **common_fjk_kwargs,
        "smd_solvent": solvent,
    },
    "base_class_name": "OML_Compound",
}

comp_extra_kwargs = {"base_class_name": "Compound"}


def get_possible_nuclear_charges(all_nuclear_charges):
    return np.unique(np.concatenate(all_nuclear_charges))


class CalcSOAP:
    def __init__(self, all_nuclear_charges, **kwargs):
        self.soap_func = SOAP(species=get_possible_nuclear_charges(all_nuclear_charges), **kwargs)

    def __call__(self, nuclear_charges, coordinates):
        comp = Atoms(nuclear_charges, coordinates)
        return self.soap_func.create(comp)


def do_with_timing(routine, *args, **other_kwargs):
    start_calc = total_cpu_time()
    output = routine(*args, **other_kwargs)
    finish_calc = total_cpu_time()
    return output, finish_calc - start_calc


def redo_with_timing(routine, *args, args_deepcopy=False, **other_kwargs):
    if args_deepcopy:
        used_args = deepcopy(args)
        used_kwargs = deepcopy(other_kwargs)
    else:
        used_args = args
        used_kwargs = other_kwargs
    # run to trigger jit compilation
    routine(*used_args, **used_kwargs)
    return do_with_timing(routine, *args, **other_kwargs)


def get_init_ensemble(ensemble: Ensemble, rep_name):
    ensemble.run_calcs()
    return ensemble


def get_init_ensembles(ensembles: List[Ensemble], rep_name, **kwargs):
    return embarrassingly_parallel(get_init_ensemble, ensembles, (rep_name,), **kwargs)


def get_processed_representations(conformers, rep_name, vacate_list=False):
    if rep_name in global_reps:
        output = np.array(conformers)
        if vacate_list:
            for i in range(len(conformers)):
                conformers[i] = None
        return output
    elif rep_name in local_dn_reps:
        return local_dn_rep_conformers_list_dict2data(conformers, vacate_list=vacate_list)
    elif rep_name in local_reps:
        return local_rep_conformers_list_dict2data(conformers, vacate_list=vacate_list)
    elif rep_name in fjk_reps:
        return fjk_rep_conformers_list_dict2data(conformers, vacate_list=vacate_list)
    else:
        raise Exception("Unknown representation!")


def get_compounds_from_ensembles(ensembles: List[Ensemble]) -> CompoundList:
    output_compounds = []
    for ensemble in ensembles:
        cur_filtered_conformer_list = ensemble.filtered_conformers[0]
        assert len(cur_filtered_conformer_list) == 1
        output_compounds.append(deepcopy(cur_filtered_conformer_list[0].compound))
    return CompoundList(output_compounds)


def get_rep_calculator(representation_name, all_nuclear_charges):
    representation_function_kwargs = {}
    if representation_name == "CM":
        rep_bare_calculator = CMCalculator(all_nuclear_charges=all_nuclear_charges)
    elif representation_name in ["SLATM", "aSLATM", "SLATM_projected"]:
        rep_bare_calculator = SLATMCalculator(all_nuclear_charges=all_nuclear_charges)
        representation_function_kwargs = {"local": representation_name == "aSLATM"}
    elif representation_name == "SOAP":
        # SOAP+KRR parameters from DOI:10.1063/5.0214754
        rep_bare_calculator = CalcSOAP(
            all_nuclear_charges, periodic=False, n_max=8, l_max=8, r_cut=9.53
        )
    elif representation_name == "FCHL19":
        rep_bare_calculator = FCHL19Calculator(all_nuclear_charges=all_nuclear_charges)
    elif representation_name == "cMBDF":
        rep_bare_calculator = cMBDFCalculator(all_nuclear_charges=all_nuclear_charges)
    elif representation_name in fjk_reps:
        rep_bare_calculator = None
    else:
        raise Exception("Unknown representation")

    if representation_name in global_reps:
        rep_calculator = GlobalRepresentationCalc(
            rep_bare_calculator, representation_function_kwargs=representation_function_kwargs
        )
    elif representation_name in local_dn_reps:
        rep_calculator = ElementAugmentedLocalRepresentationCalc(
            rep_bare_calculator,
            representation_function_kwargs=representation_function_kwargs,
            possible_nuclear_charges=get_possible_nuclear_charges(all_nuclear_charges),
        )
    elif representation_name in local_reps:
        rep_calculator = LocalRepresentationCalc(
            rep_bare_calculator, representation_function_kwargs=representation_function_kwargs
        )
    elif representation_name in fjk_reps:
        rep_calculator = FJKRepresentationCalc(oml_rep_params=default_oml_rep_params)

    return rep_calculator


def get_orthogonal_basis(representations):
    prev_shape = representations.shape
    assert len(prev_shape) == 3
    assert prev_shape[1] == 1
    basis = np.copy(representations).reshape((prev_shape[0], prev_shape[-1]))
    inplace_orthogonalize_vectors(basis)
    return basis


global_training_set_projector = None


def full_transform_to_orthogonal_basis(representations):
    old_reps_shape = representations.shape

    old_reps = representations.reshape((old_reps_shape[0], old_reps_shape[-1]))

    new_rep_shape = (old_reps_shape[0], global_training_set_projector.shape[0] + 1)

    new_reps = np.empty(new_rep_shape)

    transform_2D_representations_into_principal_component_versions(
        old_reps, new_reps, global_training_set_projector, add_remainder=True
    )

    return new_reps.reshape((new_rep_shape[0], 1, new_rep_shape[1]))


def perform_global_training_set_projection(representations, print_name):
    global global_training_set_projector
    if global_training_set_projector is None:
        global_training_set_projector, projector_timing = redo_with_timing(
            get_orthogonal_basis, representations
        )
        print(f"PROJECTOR_TIMING_{print_name}:", projector_timing)
    projected_representations, projection_timing = redo_with_timing(
        full_transform_to_orthogonal_basis, representations
    )
    print(f"PROJECTION_TIMING_{print_name}:", projection_timing)
    return projected_representations


def get_processed_ensembles(
    parallel_calculator: ProcessedRepresentationListCalc,
    ensembles: List[Ensemble],
    rep_name,
    print_name,
):
    #    if rep_name in fjk_reps:
    #        num_procs = 1
    #    else:
    #        num_procs = int(os.getenv("OMP_NUM_THREADS") or mp.cpu_count())
    num_procs = 1

    all_init_ensembles, all_init_ensembles_timing = do_with_timing(
        get_init_ensembles, ensembles, rep_name, num_procs=num_procs
    )

    print(f"{print_name}_ENSEMBLE_INIT_TIME:", all_init_ensembles_timing)

    processed_init_compounds = get_compounds_from_ensembles(all_init_ensembles)

    if rep_name in fjk_reps:
        for i in range(len(processed_init_compounds)):
            processed_init_compounds[i].generate_orb_reps()
    else:
        rep_object = parallel_calculator.representation_object
        representation_function = rep_object.rep_calc.representation_function
        representation_function_kwargs = rep_object.rep_calc.representation_function_kwargs
        processed_init_compounds.generate_rep_from_func(
            representation_function, num_procs=num_procs, **representation_function_kwargs
        )
        if rep_name == "SLATM_projected":
            assert global_training_set_projector is not None
            for i in range(len(processed_init_compounds)):
                reshaped_representation = processed_init_compounds[i].representation
                reshaped_representation = reshaped_representation.reshape(
                    (1, 1, *reshaped_representation.shape)
                )
                projected_representation = full_transform_to_orthogonal_basis(
                    reshaped_representation
                )
                new_rep_size = projected_representation.shape[-1]
                processed_init_compounds[i].representation = projected_representation.reshape(
                    (new_rep_size,)
                )

    processed_pkl_name = f"processed_init_compounds_{print_name}.pkl"

    dump2pkl(processed_init_compounds, processed_pkl_name)

    del processed_init_compounds

    processed_ensembles, procession_timing = redo_with_timing(
        parallel_calculator,
        all_init_ensembles,
        num_procs=num_procs,
        args_deepcopy=True,
        vacate_list=True,
    )

    final_processed_ensembles = get_processed_representations(
        processed_ensembles, rep_name, vacate_list=True
    )

    if rep_name == "SLATM_projected":
        final_processed_ensembles = perform_global_training_set_projection(
            final_processed_ensembles, print_name
        )

    print(f"{print_name}_ENSEMBLE_REP_TIME:", procession_timing)

    return final_processed_ensembles, processed_pkl_name


def get_msorf_definition_lists(representation_name, parallel_calculator, all_nuclear_charges):
    print("Component bounds")
    if representation_name == "SLATM_projected":
        component_bounds = np.array([[0, global_training_set_projector.shape[0] + 1]])
    else:
        component_bounds = parallel_calculator.component_bounds

    print(component_bounds)
    max_component_bound = np.max(component_bounds)
    print("REPRESENTATION_SIZE:", max_component_bound)
    if representation_name in ["aSLATM", "SLATM"]:
        nfeatures = 131072
    elif representation_name == "SOAP":
        nfeatures = 65536
    else:
        nfeatures = 32768
    init_size = nfeatures
    assert init_size >= max_component_bound
    print("SORF_init_size:", init_size)

    nfeature_stacks = nfeatures // init_size

    assert (
        nfeature_stacks == 1
    )  # the decision to do it this way was made very late, hence the strangeness
    print("nfeature_stacks:", nfeature_stacks)

    ntransforms = 3

    sorf_params = {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms}

    resize_params = {"output_size": init_size}

    if representation_name in global_reps:
        function_definition_list = ["resize", "sorf", "component_sum"]

        parameter_list = [
            resize_params,
            sorf_params,
            {},
        ]
    elif representation_name in local_reps:
        function_definition_list = ["resize", "sorf", "component_sum", "component_sum"]
        parameter_list = [
            resize_params,
            sorf_params,
            {},
            {},
        ]

    elif representation_name in local_dn_reps:
        possible_nuclear_charges = get_possible_nuclear_charges(all_nuclear_charges)
        function_definition_list = [
            "resize",
            "sorf",
            "element_id_switch",
            "component_sum",
            "component_sum",
        ]

        parameter_list = [
            resize_params,
            sorf_params,
            {"num_element_ids": len(possible_nuclear_charges)},
            {},
            {},
        ]
    elif representation_name in fjk_reps:
        function_definition_list = [
            "resize",
            "rescaling",
            "unscaled_sorf",
            "weighted_component_sum",
            "normalization",
            "sorf",
            "weighted_component_sum",
            "component_sum",
        ]
        parameter_list = [
            resize_params,
            {"resc_bounds": component_bounds},
            sorf_params,
            {},
            {},
            sorf_params,
            {},
            {},
        ]

    else:
        raise Exception("Unknown representation")

    return function_definition_list, parameter_list


def transformed_model_kwargs(representation_name, component_bounds, **kwargs):
    new_kwargs = deepcopy(kwargs)
    hyperparameters = kwargs["hyperparameters"]
    del new_kwargs["hyperparameters"]

    if representation_name in fjk_reps:
        nsigmas = np.max(component_bounds)
        sigmas = np.empty(nsigmas)
        global_sigma = hyperparameters[-1]
        for sigma, sigma_bound in zip(hyperparameters[:-1], component_bounds):
            sigmas[sigma_bound[0] : sigma_bound[1]] = sigma
        # K.Karan.: NOTE: the sqrt(2.) factor is due to the (admittedly weird) way I defined sigmas in the original FJK paper.
        new_kwargs["sigmas"] = sigmas / np.sqrt(2.0)
        new_kwargs["global_sigma"] = global_sigma
    else:
        new_kwargs["sigma"] = hyperparameters[0]
    return new_kwargs


def get_krr_model(
    representation_name, parallel_calculator: ProcessedRepresentationListCalc, **kwargs
):
    final_model_kwargs = transformed_model_kwargs(
        representation_name, parallel_calculator.component_bounds, **kwargs
    )
    if representation_name in global_reps:
        return KRRModel(**final_model_kwargs)
    elif representation_name in local_dn_reps + local_reps:
        return KRRLocalModel(**final_model_kwargs, local_dn=representation_name in local_dn_reps)
    elif representation_name in fjk_reps:
        return FJKModel(**final_model_kwargs, rep_params=default_oml_rep_params)


def main():
    if len(sys.argv) > 1:
        seed = int(sys.argv[1])
    else:
        seed = 274658

    if len(sys.argv) > 2:
        representation_name = sys.argv[2]
        assert representation_name in global_reps + local_reps + local_dn_reps + fjk_reps
    else:
        representation_name = "CM"

    print("SEED:", seed, "REPRESENTATION NAME:", representation_name)

    random.seed(seed)

    containing_folder = os.environ["DATA"] + "/literature_electrochemical_stability"

    r_cut = 0.05
    num_conformers = 1

    # Import all data.
    all_data = get_oxidation_potentials(containing_folder=containing_folder)

    all_SMILES = sorted(list(all_data.keys()))

    # NOTE: the total number of molecules is 592
    training_set_size = 474

    random.shuffle(all_SMILES)

    # For now running without statistical errors

    if representation_name == "FJK":
        base_ensemble_kwargs = pair_fjk_comp_extra_kwargs
    elif representation_name == "FJK_sdet":
        base_ensemble_kwargs = fjk_comp_extra_kwargs
    else:
        base_ensemble_kwargs = {"base_class_name": "Compound"}

    ensemble_kwargs = {
        **base_ensemble_kwargs,
        "num_conformers": num_conformers,
        "r_cut": r_cut,
    }

    ensembles = []
    quant_vals = []

    all_nuclear_charges = []

    for SMILES in all_SMILES:
        # changed_SMILES = SMILES.replace("/", "_")
        # savefile_prefix=savefile_folder + "/" + changed_SMILES
        savefile_prefix = None
        ensemble = Ensemble(SMILES=SMILES, savefile_prefix=savefile_prefix, **ensemble_kwargs)

        current_nuclear_charges = ensemble.get_nuclear_charges()

        all_nuclear_charges.append(current_nuclear_charges)

        quant_vals.append(all_data[SMILES][0])
        ensembles.append(ensemble)

    print("Number of usable ensembles:", len(ensembles))

    quant_vals = np.array(quant_vals)

    rep_calculator = get_rep_calculator(representation_name, all_nuclear_charges)

    ensemble_rep_calculator = MinConformerRepresentationCalc(rep_calculator)

    parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

    training_ensembles = ensembles[:training_set_size]
    test_ensembles = ensembles[training_set_size:]
    del ensembles

    training_conformers, training_init_compounds_pkl = get_processed_ensembles(
        parallel_calculator, training_ensembles, representation_name, "TRAINING"
    )

    msorf_definition_lists = get_msorf_definition_lists(
        representation_name, parallel_calculator, all_nuclear_charges
    )

    training_quantities = quant_vals[:training_set_size]

    l2reg_diag_ratio = 1.0e-9

    model = MultilevelSORFModel(
        *msorf_definition_lists,
        intensive_quantity_shift=False,
        extensive_quantity_shift=False,
        l2reg_diag_ratio=l2reg_diag_ratio,
    )

    model.assign_training_set(training_conformers, training_quantities)

    model.optimize_hyperparameters_short()
    print("Hyperparameters:", model.hyperparameters)

    training_feature_vectors, training_feature_vectors_timing = redo_with_timing(
        model.calc_training_Z_matrix
    )

    del training_conformers
    model.training_objects = None

    print("TRAINING_FEATURE_VECTOR_TIMING:", training_feature_vectors_timing)

    approx_training_kernel = np.dot(training_feature_vectors, training_feature_vectors.T)
    mean_diag_element = np.mean(
        approx_training_kernel[np.diag_indices_from(approx_training_kernel)]
    )

    feature_vector_alphas, feature_vector_alphas_timing = redo_with_timing(
        regression_using_Z,
        training_feature_vectors,
        training_quantities,
        l2reg_diag_ratio=l2reg_diag_ratio,
    )

    print("FEATURE_VECTOR_ALPHAS_TIMING:", feature_vector_alphas_timing)

    model.alphas = feature_vector_alphas

    test_conformers, test_init_compounds_pkl = get_processed_ensembles(
        parallel_calculator, test_ensembles, representation_name, "TEST"
    )

    test_quantities = quant_vals[training_set_size:]

    feature_vector_predictions, feature_vector_predictions_timing = redo_with_timing(
        model.get_all_predictions, test_conformers
    )
    del test_conformers

    errors = np.abs(feature_vector_predictions - test_quantities)

    print("MAE_FROM_FEATURES:", np.mean(errors))

    print("RMSE_FROM_FEATURES:", np.sqrt(np.mean(errors**2)))

    print("PREDICTION_TIMING:", feature_vector_predictions_timing)

    krr_model = get_krr_model(
        representation_name,
        parallel_calculator,
        hyperparameters=model.hyperparameters,
        l2reg_diag_ratio=l2reg_diag_ratio,
    )

    training_init_compounds = loadpkl(training_init_compounds_pkl)
    os.remove(training_init_compounds_pkl)

    krr_model.assign_training_set(
        training_compounds=training_init_compounds, training_quantities=training_quantities
    )

    training_kernel, training_kernel_timing = redo_with_timing(krr_model.get_training_kernel)

    krr_model.training_compounds = None
    del training_init_compounds

    print(
        "KERNEL_MAGNITUDE_VS_DIFFERENCE:",
        np.mean(np.abs(training_kernel)),
        np.mean(np.abs(training_kernel - approx_training_kernel)),
    )

    print("TRAINING_KERNEL_TIMING:", training_kernel_timing)

    krr_alphas, krr_alphas_timing = redo_with_timing(
        cho_solve,
        training_kernel,
        training_quantities,
        l2reg=mean_diag_element * l2reg_diag_ratio,
        overwrite_a=True,
    )

    print("TRAINING_KERNEL_REGRESSION_TIMING:", krr_alphas_timing)

    krr_model.alphas = krr_alphas

    test_init_compounds = loadpkl(test_init_compounds_pkl)
    os.remove(test_init_compounds_pkl)

    krr_predictions, krr_predictions_timings = redo_with_timing(
        krr_model.predict_from_compounds, test_init_compounds
    )

    del test_init_compounds

    print("KRR_PREDICTION_TIMINGS:", krr_predictions_timings)

    krr_errors = np.abs(krr_predictions - test_quantities)

    print("MAE_FROM_KRR:", np.mean(krr_errors))
    print("RMSE_FROM_KRR:", np.sqrt(np.mean(krr_errors**2)))


if __name__ == "__main__":
    main()
