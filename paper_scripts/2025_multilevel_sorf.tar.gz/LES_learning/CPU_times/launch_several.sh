#!/bin/bash

ncpus=4

for seed in 274658 20786 109790 478390
do
	for rep_name in "FJK" "FJK_sdet" "CM" "SLATM" "SOAP" "cMBDF" "FCHL19" "aSLATM" "SLATM_projected"
	do
		# since limiting CPU time is a challenge with pyscf; does not account CPU counts since they are managed with os.times. (Also adjusted to give some representations more memory.)
		spython --OMP_NUM_THREADS=$ncpus --CPUs=16 kernel_sorf_timing_comparison_LES.py ${rep_name}_LES_CPU_check_$seed $seed $rep_name
	done
done
