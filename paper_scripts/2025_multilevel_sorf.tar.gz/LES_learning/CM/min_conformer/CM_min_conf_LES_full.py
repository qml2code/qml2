import os
import random
import sys

import numpy as np

from qml2.basic_utils import now
from qml2.dataset_formats.literature_electrochemical_stability import get_oxidation_potentials
from qml2.ensemble import Ensemble
from qml2.models.learning_curves import learning_curve_from_predictions
from qml2.models.loss_functions import MAE, RMSE
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import ProcessedRepresentationListCalc
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    MinConformerRepresentationCalc,
)
from qml2.multilevel_sorf.processed_object_constructors.standard import GlobalRepresentationCalc
from qml2.representations import generate_coulomb_matrix

if len(sys.argv) > 1:
    seed = int(sys.argv[1])
else:
    seed = 274658

if len(sys.argv) > 2:
    no_shifts_str = sys.argv[2]
    assert no_shifts_str in ["True", "False"]
    no_shifts = no_shifts_str == "True"
else:
    no_shifts = False

print("SEED:", seed, "NO SHIFTS:", no_shifts)

random.seed(seed)

containing_folder = os.environ["DATA"] + "/literature_electrochemical_stability"

r_cut = 0.05
num_conformers = 32

savefile_folder = (
    containing_folder
    + "/savefiles_CM_rcut_"
    + str(r_cut)
    + "_num_conformers_"
    + str(num_conformers)
)

try:
    os.mkdir(savefile_folder)
except FileExistsError:
    print("savefile folder already created")


# Import all data .
all_data = get_oxidation_potentials(containing_folder=containing_folder)

all_SMILES = sorted(list(all_data.keys()))
num_mols = len(all_SMILES)

# NOTE: the total number of molecules is 592
training_set_size = 474
nfeatures = 32768

random.shuffle(all_SMILES)

# For now running without statistical errors

ensemble_kwargs = {
    "base_class_name": "Compound",
    "num_conformers": num_conformers,
    "r_cut": r_cut,
}

ensembles = []
quant_vals = []

size = 0

for SMILES in all_SMILES:
    changed_SMILES = SMILES.replace("/", "_")
    ensemble = Ensemble(
        SMILES=SMILES, savefile_prefix=savefile_folder + "/" + changed_SMILES, **ensemble_kwargs
    )

    current_nuclear_charges = ensemble.get_nuclear_charges()
    size = max(size, len(current_nuclear_charges))

    quant_vals.append(all_data[SMILES][0])
    ensembles.append(ensemble)


print("Number of usable ensembles:", len(ensembles))

quant_vals = np.array(quant_vals)

rep_calculator = GlobalRepresentationCalc(
    generate_coulomb_matrix, representation_function_kwargs={"size": size}
)

ensemble_rep_calculator = MinConformerRepresentationCalc(rep_calculator)

parallel_calculator = ProcessedRepresentationListCalc(ensemble_rep_calculator)

conformer_representations = np.array(parallel_calculator(ensembles))

print("Component bounds")
component_bounds = parallel_calculator.component_bounds

print(component_bounds)
max_component_bound = parallel_calculator.max_component_bound()
print(max_component_bound)

init_size = nfeatures
assert init_size >= max_component_bound
print("SORF init_size", init_size)

nfeature_stacks = nfeatures // init_size

print("nfeature_stacks:", nfeature_stacks)

training_conformers = conformer_representations[:training_set_size]
training_quantities = quant_vals[:training_set_size]

test_conformers = conformer_representations[training_set_size:]
test_quantities = quant_vals[training_set_size:]

function_definition_list = [
    "resize",
    "sorf",
    "component_sum",
]

ntransforms = 3

parameter_list = [
    {"output_size": init_size},
    {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
    {},
]

model = MultilevelSORFModel(
    function_definition_list,
    parameter_list,
    intensive_quantity_shift=(not no_shifts),
    extensive_quantity_shift=False,
)


training_set_sizes = [50, 100, 200, 400, training_set_size]

# nperturbations = 4
# initial_guess_perturbations = (
#    np.random.random((nperturbations, model.get_nhyperparameters())) - 0.5
# )
# initial_guess_perturbations[0, :] = 0.0
initial_guess_perturbations = None

print(">>>started learning curve building:", now())
all_predictions = model.learning_curve_predictions(
    training_conformers,
    training_quantities,
    test_conformers,
    training_set_sizes,
    max_subset_num=1,
    hyperparameter_reoptimization=True,
    hyperparameter_optimization_kwargs={
        "initial_guess_perturbations": initial_guess_perturbations
    },
    rng=random,
)
print(">>>finished learning curve building:", now())
for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
    mean_MAEs, _ = learning_curve_from_predictions(
        all_predictions, test_quantities, error_loss_function=loss
    )
    with open(f"learning_curve_{loss_name}.txt", "w") as f:
        for ntr, mean_MAE_val in zip(training_set_sizes, mean_MAEs):
            print(ntr, mean_MAE_val, file=f)
