#!/bin/bash

for seed in 274658 20786 109790 478390
do
	spython CM_LES_full.py CM_learn_LES_$seed $seed
done
