#!/bin/bash

ns_dir=no_shifts

mkdir -p $ns_dir

for seed in 274658 20786 109790 478390
do
	spython FJK_LES_full.py FJK_LES_$seed $seed False
	cd $ns_dir
	spython ../FJK_LES_full.py FJK_LES_no_shifts_$seed $seed True
	cd ../
done
