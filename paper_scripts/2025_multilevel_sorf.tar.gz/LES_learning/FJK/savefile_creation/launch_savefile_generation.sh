#!/bin/bash
# Break down savefile calculations into unit jobs to avoid getting stuck.

workdir=savefile_data

mkdir $workdir
cd $workdir

datafile=$DATA/literature_electrochemical_stability/grouped_dataset_acetonitrile_neutral.csv

nCPUs=8

for i in $(seq 1 $(wc -l $datafile | awk '{print $1-1}'))
do
	sleep 1
	spython --OMP_NUM_THREADS=$nCPUs --CPUs=$nCPUs ../generate_savefile.py calc_$i $i
	spython --OMP_NUM_THREADS=$nCPUs --CPUs=$nCPUs ../generate_savefile_pair.py calc_pair_$i $i
done
