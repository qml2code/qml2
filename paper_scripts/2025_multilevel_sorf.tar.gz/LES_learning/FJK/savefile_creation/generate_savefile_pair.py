import os
import sys

from qml2.dataset_formats.literature_electrochemical_stability import get_oxidation_potentials
from qml2.ensemble import Ensemble

use_Huckel = True
basis = "6-311G"  # "sto-3g"
solvent = "acetonitrile"
r_cut = 0.05

num_conformers = 32

SMILES_id = int(sys.argv[1])

containing_folder = os.environ["DATA"] + "/literature_electrochemical_stability"
all_data = get_oxidation_potentials(containing_folder=containing_folder)
all_SMILES = sorted(list(all_data.keys()))

SMILES = all_SMILES[SMILES_id - 1]
print("SMILES:", SMILES)

savefile_folder = (
    containing_folder
    + "/savefiles_FJK_pair_Huckel_"
    + str(use_Huckel)
    + "_basis_"
    + str(basis)
    + "_r_cut_"
    + str(r_cut)
    + "_solvent_"
    + solvent
    + "_nconfs_"
    + str(num_conformers)
)

try:
    os.mkdir(savefile_folder)
except FileExistsError:
    print("savefile folder already created")


# For now running without statistical errors

comp_extra_kwargs = {
    "use_Huckel": use_Huckel,
    "basis": basis,
    "localization_procedure": "Boys",
    "smd_solvent": solvent,
    "second_oml_comp_kwargs": {"charge": 1, "calc_type": "UHF"},
}

ensemble_kwargs = {
    "base_class_name": "OML_Slater_pair",
    "compound_kwargs": comp_extra_kwargs,
    "num_conformers": num_conformers,
    "r_cut": r_cut,
}

changed_SMILES = SMILES.replace("/", "_")

ensemble = Ensemble(
    SMILES=SMILES, savefile_prefix=savefile_folder + "/" + changed_SMILES, **ensemble_kwargs
)

ensemble.run_calcs()
