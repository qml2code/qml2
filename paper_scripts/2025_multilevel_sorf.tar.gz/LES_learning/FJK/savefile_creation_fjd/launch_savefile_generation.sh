#!/bin/bash
# Pre-calculate the FJD savefiles. Unlike the FJK generators next door, which break the set
# into one job per molecule to avoid getting stuck, this submits one job per configuration
# and parallelizes over molecules inside it -- the Python script catches a molecule that
# fails rather than letting it take the others down, which is what the per-molecule jobs
# were protecting against.
#
# OMP_NUM_THREADS=1 with QML2_NUM_PROCS=$nCPUs: a GFN2 single point on a single conformer is
# far too small to use a node's cores through OpenMP, so the cores are handed different
# molecules instead. spython sets QML2_NUM_PROCS to the OMP thread count by default, which
# is why it has to be overridden explicitly -- --export_env_vars is written into the job
# script after the thread block, so it wins.
#
# Each job prints the savefile folder it resolved. Compare it against what FJK_LES_full.py
# prints: if the two disagree, these calculations will never be read.

nCPUs=80
workdir=savefile_data

mkdir -p $workdir
cd $workdir

for configuration in sdet pair
do
	spython --OMP_NUM_THREADS=1,1 --CPUs=$nCPUs \
		--export_env_vars=QML2_NUM_PROCS=$nCPUs \
		../generate_savefiles.py FJD_$configuration $configuration
done
