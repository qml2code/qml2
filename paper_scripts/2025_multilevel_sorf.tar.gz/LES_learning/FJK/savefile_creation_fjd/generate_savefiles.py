"""Pre-calculate the FJD savefiles for the LES set, and report the baseline they imply.

Two configurations, chosen by the single positional argument:

    sdet   the neutral molecule in acetonitrile, one determinant
    pair   the same molecule and its cation (spin-polarized), both in acetonitrile

Unlike the FJK generators next door, which submit one job per molecule, this runs the whole
set in one job and parallelizes over molecules with qml2's own embarrassingly_parallel. The
launcher therefore asks for OMP_NUM_THREADS=1 and gives QML2_NUM_PROCS the CPU count: a
GFN2 single point on one conformer is far too small to use a node's cores through OpenMP,
and handing each core a different molecule instead keeps all of them busy.

The pair configuration also produces a physical baseline for free. Its two determinants
differ by one electron, so the conformer-weighted energy difference IS an estimate of the
oxidation potential -- the quantity being learned -- which makes it a candidate delta-ML
reference. How good a one is printed as a correlation against the experimental values, and
the per-molecule numbers are written out so the comparison can be redone elsewhere.

The sdet configuration has no such difference: a single determinant gives an absolute
energy, and correlating that with an oxidation potential means nothing. It writes savefiles
and stops.

NOTE: the savefile folder name and the compound keyword arguments below have to match the
learning script's exactly, or the calculations land somewhere it will never look. spython
copies this file into its job directory alone, so it cannot import them -- the resolved
folder is printed instead, to be compared against the one FJK_LES_full.py prints.

NOTE: with "software": "tblite" this does NOT select SMD. The keyword is passed to
tblite's own ALPB model -- calculator.add("alpb-solvation", solvent) in
qml2/orb_ml/tblite_interface -- so what these runs used is ALPB, not SMD. A naming
oversight, not an attempt at a solvent model tblite does not have; see README.txt note 1.
"""

import json
import os
import sys

import numpy as np

from qml2.data import conversion_coefficient
from qml2.dataset_formats.literature_electrochemical_stability import get_oxidation_potentials
from qml2.ensemble import Ensemble
from qml2.parallelization import embarrassingly_parallel

solvent = "acetonitrile"
r_cut = 0.05
num_conformers = 32

# Has to agree with the FJD branch of FJK_LES_full.py.
COMPOUND_KWARGS = {
    "software": "tblite",
    "calc_type": "gfn2-xtb",
    "localization_procedure": "Pipek-Mezey",
    "smd_solvent": solvent,
}
# comps[0] is the neutral and comps[1] the cation, so the difference comes out with the same
# sign as the oxidation potential rather than against it.
#
# The cation is spin-polarized. Restricted GFN2 has a spin-independent energy expression and
# so cannot describe an open shell as anything but a closed one; spGFN2-xTB is the variant
# the literature uses for exactly this, and the difference is real -- 3.4 kcal/mol on a
# methanol cation. The neutral stays restricted, where the two coincide exactly.
SECOND_COMPOUND_KWARGS = {"charge": 1, "calc_type": "spgfn2-xtb"}

# The oxidation potentials are in volts against SCE; a one-electron process makes an energy
# difference in eV numerically comparable to them, up to the reference electrode's offset.
ENERGY_UNIT = "au_eV"
QUANTITY_DESCRIPTION = "oxidation potential vs SCE [V] against E(cation) - E(neutral) [eV]"


# Where this dataset lives under $DATA, and how its quantities are read. Named here rather than
# inline in main() so print_baseline_table.py beside this file can resolve the same folder and the
# same quantities without repeating either.
DATASET_SUBDIR = "literature_electrochemical_stability"


def load_dataset(containing_folder):
    """``{SMILES: (quantity, ...)}`` for this dataset, as the learning scripts read it."""
    return get_oxidation_potentials(containing_folder=containing_folder)


def savefile_folder(containing_folder, pair):
    """Where this configuration's savefiles live.

    The two configurations MUST NOT share a folder, and not only to keep them tidy:
    Ensemble names its conformer savefile `<prefix>_<suffix>.pkl` with no record of the
    base class, so a pair ensemble pointed at a folder an sdet run already filled restores
    OML_Compounds and then fails inside mean_calculated_energy_diff with a bare
    AssertionError. The "_pair" in the name below is what keeps them apart.
    """
    # "spcation" is in the name because nothing else records the spin treatment: Ensemble
    # stores a whole molecule in one pickle whose name says nothing about calc_type, so a
    # folder shared with a restricted-cation run would be reused without complaint.
    method = "FJD_pair_spcation" if pair else "FJD"
    return (
        f"{containing_folder}/savefiles_{method}_r_cut_{r_cut}"
        f"_solvent_{solvent}_nconfs_{num_conformers}"
    )


def build_ensemble(SMILES, pair, folder):
    compound_kwargs = dict(COMPOUND_KWARGS)
    if pair:
        compound_kwargs["second_oml_comp_kwargs"] = SECOND_COMPOUND_KWARGS
    return Ensemble(
        SMILES=SMILES,
        savefile_prefix=folder + "/" + SMILES.replace("/", "_"),
        base_class_name="OML_Slater_pair" if pair else "OML_Compound",
        compound_kwargs=compound_kwargs,
        num_conformers=num_conformers,
        r_cut=r_cut,
    )


def calculate(SMILES, pair, folder):
    """One molecule. Returns (SMILES, value, error), value None where it did not finish.

    Exceptions are caught rather than raised: this is one job for the whole set, so a
    molecule that fails to converge or to produce conformers would otherwise take the other
    591 with it. The count is reported at the end.
    """
    try:
        ensemble = build_ensemble(SMILES, pair, folder)
        ensemble.run_calcs()
        if not pair:
            return (SMILES, None, None)
        difference = ensemble.mean_calculated_energy_diff()
        return (SMILES, difference * conversion_coefficient[ENERGY_UNIT], None)
    except Exception as error:
        return (SMILES, None, f"{type(error).__name__}: {error}")


def report_baseline(results, all_data, output_filename):
    """Correlate the conformer-weighted energy differences with the experimental values."""
    usable = [(SMILES, value) for SMILES, value, error in results if value is not None]
    if len(usable) < 2:
        print("not enough finished molecules to correlate anything")
        return
    experimental = np.array([all_data[SMILES][0] for SMILES, _ in usable])
    predicted = np.array([value for _, value in usable])
    correlation = np.corrcoef(experimental, predicted)[0, 1]
    slope, intercept = np.polyfit(predicted, experimental, 1)

    print(f"\nbaseline: {QUANTITY_DESCRIPTION}")
    print(f"  molecules correlated      : {len(usable)}")
    print(f"  Pearson correlation       : {correlation:+.4f}  (squared: {correlation**2:.4f})")
    # A one-electron oxidation should need a slope near 1; far from it means the difference
    # is not measuring what it is supposed to.
    print(f"  experiment vs baseline fit: slope {slope:+.4f}, intercept {intercept:+.4f}")

    with open(output_filename, "w") as output:
        json.dump(
            {
                SMILES: {
                    "experimental_value": float(all_data[SMILES][0]),
                    "predicted_value": float(value),
                }
                for SMILES, value in usable
            },
            output,
            indent=2,
        )
    print(f"  per-molecule values written to {output_filename}")


def main():
    configuration = sys.argv[1] if len(sys.argv) > 1 else "sdet"
    assert configuration in ("sdet", "pair"), f"unknown configuration '{configuration}'"
    pair = configuration == "pair"

    containing_folder = os.environ["DATA"] + "/" + DATASET_SUBDIR
    folder = savefile_folder(containing_folder, pair)
    print("CONFIGURATION:", configuration)
    print("SAVEFILE FOLDER:", folder)
    print("(compare against what the learning script prints -- a mismatch means these")
    print(" calculations will never be read)")
    os.makedirs(folder, exist_ok=True)

    all_data = load_dataset(containing_folder)
    all_SMILES = sorted(all_data.keys())
    print(f"molecules: {len(all_SMILES)}")

    results = embarrassingly_parallel(calculate, all_SMILES, (pair, folder))

    failures = [(SMILES, error) for SMILES, _, error in results if error is not None]
    print(f"\nfinished: {len(results) - len(failures)} of {len(results)}")
    for SMILES, error in failures:
        print(f"  FAILED {SMILES}: {error}")
    if len(failures) == len(results):
        # Every molecule failing is not a chemistry problem, it is a broken job -- a missing
        # module, an unreadable dataset. Exiting non-zero keeps it from looking like a run
        # that simply had nothing to report.
        raise SystemExit(
            "every molecule failed; this is an environment or dataset problem rather than "
            "a per-molecule one -- see the errors above"
        )

    if pair:
        report_baseline(results, all_data, "FJD_pair_baseline.json")
    else:
        print("\nno baseline for a single determinant: there is no energy difference to")
        print("average, and an absolute energy says nothing about an oxidation potential")


if __name__ == "__main__":
    main()
