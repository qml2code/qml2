import json
import os
import random
import sys

import numpy as np

from qml2.basic_utils import now
from qml2.cheminfo.scaffolds import scaffold_group_ids
from qml2.data import conversion_coefficient
from qml2.dataset_formats.literature_electrochemical_stability import get_oxidation_potentials
from qml2.ensemble import Ensemble
from qml2.models.kfolds import frequency_ordered_group_split, group_index_lists
from qml2.models.learning_curves import learning_curve_from_predictions
from qml2.models.loss_functions import MAE, RMSE
from qml2.multilevel_sorf.base_constructors import get_transform_list_dict2datatype
from qml2.multilevel_sorf.models import MultilevelSORFModel
from qml2.multilevel_sorf.processed_object_constructors import ProcessedRepresentationListCalc
from qml2.multilevel_sorf.processed_object_constructors.ensemble import (
    EnsembleRepresentationCalc,
    MinConformerRepresentationCalc,
    fjk_comp_ensemble_list_dict2datatype,
)
from qml2.multilevel_sorf.processed_object_constructors.fjk import (
    FJKRepresentationCalc,
    comp_rep_def,
)
from qml2.orb_ml.representations import OML_rep_params
from qml2.parallelization import embarrassingly_parallel

# The min-conformer counterpart of fjk_comp_ensemble_list_dict2datatype:
# one representation per molecule rather than a weighted list of conformers, so exactly one
# level shallower. Built here rather than imported because qml2 names only the local_dn_rep
# analogue, and this script has to keep working as the single file spython copies into its
# job directory.
fjk_comp_conformers_list_dict2data = get_transform_list_dict2datatype(comp_rep_def + ["list"])


def use_fjk_representation():
    """Whether to fall back to FJK; FJD is the default.

    FJD replaces FJK's exchange slot with two dipole-derived channels. FJK is what the
    paper used, so it stays reachable with --fjk, but it is no longer what you get by
    default. The flag is stripped from sys.argv, so every positional argument below keeps
    the meaning it had.

    Parsed by hand rather than with argparse because spython copies this file, on its own,
    into the job directory and runs it there -- so it has to keep working with no sibling
    modules, and the positional interface the launchers already use has to survive.
    """
    selected = "--fjk" in sys.argv
    if selected:
        sys.argv = [argument for argument in sys.argv if argument != "--fjk"]
    print("REPRESENTATION:", "FJK" if selected else "FJD")
    return selected


def use_min_conformer():
    """Whether to represent each molecule by ONE conformer instead of the whole ensemble.

    The min-conformer counterpart of the ensemble runs, matching what aSLATM, FCHL19 and CM
    already have as separate `min_conformer/` scripts. `Ensemble` sorts its conformers by
    weight, so the one taken is the highest-weighted -- the lowest free energy -- and the
    weighted sum over conformers disappears from the SORF stack along with the level it
    summed over.

    The savefile folder is deliberately NOT renamed. The ab initio results are per conformer
    and identical either way, so a --min_conf run reads the savefiles the ensemble run
    already wrote and costs no new calculation. Giving it its own folder would throw that
    away and recompute every conformer in order to use one of them.

    Stripped from sys.argv like --fjk, so the positional arguments keep their meaning.
    """
    selected = "--min_conf" in sys.argv
    if selected:
        sys.argv = [argument for argument in sys.argv if argument != "--min_conf"]
    print("CONFORMERS:", "minimum-energy only" if selected else "full ensemble")
    return selected


def use_delta_ml_reference():
    """Whether to learn the residual against the calculated ionization potential.

    The Slater pair's two determinants differ by one electron, so the conformer-weighted
    energy difference between them IS an estimate of the quantity being learned. With
    --delta-ml the model is trained on what that estimate misses rather than on the
    oxidation potential itself.

    NOT usable under --fjk as this script configures pySCF: use_Huckel sets
    mf.max_cycle = -1 (qml2/orb_ml/aux_classes.py), so both determinants store the energy of
    the Huckel GUESS rather than a converged HF one -- 75 kcal/mol above converged for
    water/6-311G -- and the difference of two such energies is not an ionization potential.
    Setting use_Huckel = False and regenerating the savefiles would make it one.

    Stripped from sys.argv like --fjk, so the positional arguments keep their meaning.
    """
    selected = "--delta-ml" in sys.argv
    if selected:
        sys.argv = [argument for argument in sys.argv if argument != "--delta-ml"]
    print("DELTA-ML REFERENCE:", "calculated ionization potential" if selected else "none")
    return selected


def ensemble_ionization_potential(ensemble):
    """One ensemble's conformer-weighted E(cation) - E(neutral), in eV.

    The same number savefile_creation_fjd/generate_savefiles.py reports, recomputed here
    rather than read back from the JSON it writes. The calculations are cached, so this
    costs only the unpickling, and it cannot go stale against the savefiles actually in
    use -- which a JSON written by an earlier generation very much can.
    """
    ensemble.run_calcs()
    return ensemble.mean_calculated_energy_diff() * conversion_coefficient["au_eV"]


def dump_test_predictions(
    filename,
    test_SMILES,
    test_quantities,
    all_predictions,
    training_set_sizes,
    method_str,
    baselines=None,
):
    """Write the test set predictions to `filename` as a SMILES-keyed JSON dictionary.

    The model returns predictions indexed [training set size][training subset][molecule],
    with the molecule axis in test set order -- which is the order the ensembles were built
    in, so `all_SMILES[training_set_size:]` names it. That layout is what the learning curve
    wants and the wrong way round for looking a molecule up, hence the inversion here.

    Each training set size keeps a LIST of predictions, one per training subset. These runs
    use max_subset_num=1, so those lists have one entry, but nothing in the model requires
    that and collapsing the axis now would silently drop the rest if it ever changes.
    """
    # `baselines` is the delta-ML reference that was subtracted, if any. It is added back
    # here so this file always holds absolute values in the dataset's own units and records
    # the reference beside them -- which keeps a delta-ML run directly comparable with one
    # that learned the quantity outright.
    if baselines is None:
        baselines = np.zeros(len(test_SMILES))

    assert len(test_SMILES) == len(test_quantities)
    assert len(baselines) == len(test_SMILES)
    for subset_predictions in all_predictions:
        for predictions in subset_predictions:
            assert len(predictions) == len(test_SMILES)

    molecules = {
        SMILES: {
            "reference": float(test_quantities[imol] + baselines[imol]),
            "delta_ml_reference": float(baselines[imol]),
            "predictions": {
                str(training_set_size): [
                    float(predictions[imol] + baselines[imol])
                    for predictions in subset_predictions
                ]
                for training_set_size, subset_predictions in zip(
                    training_set_sizes, all_predictions
                )
            },
        }
        for imol, SMILES in enumerate(test_SMILES)
    }

    with open(filename, "w") as f:
        json.dump(
            {
                "method": method_str,
                "training_set_sizes": list(training_set_sizes),
                "molecules": molecules,
            },
            f,
            indent=2,
        )
    print("Test set predictions written to:", filename)


# The grouping the split is built on. Verified non-degenerate for these seeds by
# scaffolds/scaffold_distribution_*.py: four distinct randomized draws, none of which
# reproduces the deterministic one.
SCAFFOLD_ACYCLIC = "skeleton"
SCAFFOLD_INCLUDE_CHIRALITY = False
TRAIN_FRACTION = 0.8


def scaffold_split_mode():
    """Replace the learning curve with a single 80/20 scaffold split, or not.

    --fo_scaffold   frequency-ordered split, deterministic: the reference point, comparable
                    with the scaffold-split literature.
    --rfo_scaffold  same frequency ordering, but same-size groups shuffled with the seed, so
                    several seeds give an ensemble with genuine error bars.

    Stripped from sys.argv like --fjk and --delta-ml, so the positional arguments keep their
    meaning.
    """
    flags = ("--fo_scaffold", "--rfo_scaffold")
    selected = [flag for flag in flags if flag in sys.argv]
    assert len(selected) < 2, "pass at most one of " + ", ".join(flags)
    if not selected:
        return None
    sys.argv = [argument for argument in sys.argv if argument not in selected]
    return selected[0].lstrip("-")


def main():
    scaffold_mode = scaffold_split_mode()
    use_fjk = use_fjk_representation()
    delta_ml = use_delta_ml_reference()
    min_conf = use_min_conformer()
    if len(sys.argv) > 1:
        seed = int(sys.argv[1])
    else:
        seed = 274658

    if len(sys.argv) > 2:
        simple_shifts_str = sys.argv[2]
        assert simple_shifts_str in ["True", "False"]
        simple_shifts = simple_shifts_str == "True"
    else:
        simple_shifts = False

    print("SEED:", seed, "SIMPLE SHIFTS:", simple_shifts, "SCAFFOLD SPLIT:", scaffold_mode)
    if scaffold_mode == "fo_scaffold":
        print("NOTE: the seed does not enter a deterministic split; it only names the job.")

    random.seed(seed)

    containing_folder = os.environ["DATA"] + "/literature_electrochemical_stability"

    r_cut = 0.05
    num_conformers = 32
    solvent = "acetonitrile"

    if use_fjk:
        use_Huckel = True
        basis = "6-311G"  # "sto-3g"
        method_str = f"FJK_pair_Huckel_{str(use_Huckel)}_basis_{basis}"
        max_angular_momentum = 1
        comp_extra_kwargs_base = {
            "use_Huckel": use_Huckel,
            "basis": basis,
            "localization_procedure": "Boys",
        }
        second_calc_type = "UHF"
    else:
        method_str = "FJD_pair_spcation"
        max_angular_momentum = 2
        comp_extra_kwargs_base = {
            "localization_procedure": "Pipek-Mezey",
            "calc_type": "gfn2-xtb",
            "software": "tblite",
        }
        # The cation is spin-polarized: restricted GFN2 cannot describe an open
        # shell as anything but a closed one. The neutral stays restricted, where
        # the two are the same calculation.
        second_calc_type = "spgfn2-xtb"

    savefile_folder = (
        containing_folder
        + f"/savefiles_{method_str}_r_cut_{str(r_cut)}_solvent_{solvent}_nconfs_{str(num_conformers)}"
    )
    # Printed so it can be compared against what savefile_creation_fjd/generate_savefiles.py
    # resolves: if the two disagree, every cached calculation is invisible to this script.
    print("SAVEFILE FOLDER:", savefile_folder)

    try:
        os.mkdir(savefile_folder)
    except FileExistsError:
        print("savefile folder already created")

    # Import all data .
    all_data = get_oxidation_potentials(containing_folder=containing_folder)

    all_SMILES = sorted(list(all_data.keys()))
    assert len(all_SMILES) == 592

    # NOTE: the total number of molecules is 592
    training_set_size = 474
    nfeatures = 32768

    if scaffold_mode is None:
        random.shuffle(all_SMILES)
        training_group_ids = None
    else:
        # The deterministic split breaks ties between equal-size groups by smallest member
        # index, so it is only reproducible against a FIXED input order -- shuffling per seed
        # would make "deterministic" name a different split every time. The SMILES therefore
        # stay sorted, and --rfo_scaffold varies only the order WITHIN blocks of equal-size
        # groups, through its own rng.
        group_ids = scaffold_group_ids(
            all_SMILES,
            acyclic=SCAFFOLD_ACYCLIC,
            include_chirality=SCAFFOLD_INCLUDE_CHIRALITY,
        )
        randomized = scaffold_mode == "rfo_scaffold"
        train_indices, test_indices = frequency_ordered_group_split(
            group_ids,
            int(round(TRAIN_FRACTION * len(all_SMILES))),
            shuffle_ties=randomized,
            rng=np.random.default_rng(seed) if randomized else None,
        )
        # Reorder the dataset so the training molecules come first, which lets everything
        # below keep using the plain [:training_set_size] slicing.
        order = list(train_indices) + list(test_indices)
        all_SMILES = [all_SMILES[index] for index in order]
        group_ids = group_ids[order]
        training_set_size = len(train_indices)
        assert not (
            set(group_ids[:training_set_size].tolist())
            & set(group_ids[training_set_size:].tolist())
        ), "a scaffold group straddles the split, so it cannot partition the training set"
        training_group_ids = group_index_lists(group_ids[:training_set_size])
        print(
            f"SCAFFOLD SPLIT: {scaffold_mode}"
            f" train/test={training_set_size}/{len(all_SMILES) - training_set_size}"
            f" groups_in_train={len(training_group_ids)}"
        )

    # For now running without statistical errors
    comp_extra_kwargs = {
        **comp_extra_kwargs_base,
        # NOTE: with "software": "tblite" this does NOT select SMD. The keyword is passed to
        # tblite's own ALPB model -- calculator.add("alpb-solvation", solvent) in
        # qml2/orb_ml/tblite_interface -- so what these runs used is ALPB, not SMD. A naming
        # oversight, not an attempt at a solvent model tblite does not have; see README.txt note 1.
        "smd_solvent": solvent,
        "second_oml_comp_kwargs": {"charge": 1, "calc_type": second_calc_type},
    }

    ensemble_kwargs = {
        "base_class_name": "OML_Slater_pair",
        "compound_kwargs": comp_extra_kwargs,
        "num_conformers": num_conformers,
        "r_cut": r_cut,
    }

    ensembles = []
    quant_vals = []

    for SMILES in all_SMILES:
        changed_SMILES = SMILES.replace("/", "_")
        ensemble = Ensemble(
            SMILES=SMILES,
            savefile_prefix=savefile_folder + "/" + changed_SMILES,
            **ensemble_kwargs,
        )

        ensembles.append(ensemble)
        quant_vals.append(all_data[SMILES][0])

    print("Number of usable ensembles:", len(ensembles))

    quant_vals = np.array(quant_vals)

    if delta_ml:
        # Computed over the ensembles rather than read from a file, and in parallel because
        # it means unpickling every savefile.
        print(">>>started delta-ML reference:", now())
        baselines = np.array(embarrassingly_parallel(ensemble_ionization_potential, ensembles, ()))
        print(">>>finished delta-ML reference:", now())
        correlation = np.corrcoef(quant_vals, baselines)[0, 1]
        print(f"delta-ML reference vs experiment: Pearson {correlation:+.4f}")
        # The model learns the residual from here on. This leaves the learning curves
        # directly comparable with the runs that do not use a reference: the baseline is a
        # per-molecule constant, so it cancels between a prediction and its reference and
        # the errors are the same whether they are measured on residuals or on absolutes.
        quant_vals = quant_vals - baselines
    else:
        baselines = None

    rep_params = OML_rep_params(
        max_angular_momentum=max_angular_momentum, fjd_coup_mats=not use_fjk
    )

    orb_rep_calculator = FJKRepresentationCalc(oml_rep_params=rep_params)

    if min_conf:
        ensemble_orb_rep_calculator = MinConformerRepresentationCalc(orb_rep_calculator)
    else:
        ensemble_orb_rep_calculator = EnsembleRepresentationCalc(orb_rep_calculator)

    parallel_calculator = ProcessedRepresentationListCalc(ensemble_orb_rep_calculator)

    processed_ensemble_slater_pair_dicts = parallel_calculator(ensembles)

    if min_conf:
        processed_slater_pairs = fjk_comp_conformers_list_dict2data(
            processed_ensemble_slater_pair_dicts
        )
    else:
        processed_slater_pairs = fjk_comp_ensemble_list_dict2datatype(
            processed_ensemble_slater_pair_dicts
        )

    component_bounds = parallel_calculator.component_bounds

    print(component_bounds)

    max_component_bound = parallel_calculator.max_component_bound()
    print(max_component_bound)

    init_size = nfeatures
    assert init_size >= max_component_bound
    print("SORF init_size", init_size)

    nfeature_stacks = nfeatures // init_size

    print("nfeature_stacks:", nfeature_stacks)

    training_slater_pairs = processed_slater_pairs[:training_set_size]
    training_quantities = quant_vals[:training_set_size]

    test_slater_pairs = processed_slater_pairs[training_set_size:]
    test_quantities = quant_vals[training_set_size:]
    # Same order the ensembles were built in, hence the same order as the predictions.
    test_SMILES = all_SMILES[training_set_size:]
    test_baselines = None if baselines is None else baselines[training_set_size:]

    ntransforms = 3

    function_definition_list = [
        "resize",
        "rescaling",
        "unscaled_sorf",
        "weighted_component_sum",
        "normalization",
        "sorf",
        "weighted_component_sum",
        "sorf",
    ]

    parameter_list = [
        {"output_size": init_size},
        {"resc_bounds": parallel_calculator.component_bounds},
        {"nfeature_stacks": nfeature_stacks, "ntransforms": ntransforms},
        {},
        {},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
        {},
        {"nfeature_stacks": 1, "ntransforms": ntransforms},
    ]

    if not min_conf:
        # The conformer level: a weighted sum over the ensemble's conformers.
        # --min_conf keeps one conformer per molecule, so there is nothing to sum.
        function_definition_list.append("weighted_component_sum")
        parameter_list.append({})

    function_definition_list.append("component_sum")
    parameter_list.append({})

    if not min_conf:
        # A final pass into an intensive representation, and ONLY for ensembles, because a
        # weighted sum of intensive vectors is not itself intensive: the Boltzmann sum above
        # produces something that has to be made intensive again before it is used as a
        # feature vector. That is the whole reason the block exists, and it is why it sits
        # after the LAST sum rather than between the two.
        #
        # --min_conf has no weighted sum, so there is nothing to correct and the block is
        # omitted -- the same choice FCHL19_min_conf_LES_full.py made in the May scripts,
        # whose stack ends "component_sum normalization sorf" for the ensemble and plain
        # "component_sum" for the single conformer.
        #
        # NOTE: this is deliberately NOT the stack in
        # CPU_times/kernel_sorf_timing_comparison_LES.py, which reproduces the previous
        # paper's kernels. That one omits the molecule-level "sorf" above; this paper keeps
        # it so the single-conformer and multi-conformer architectures differ only in the
        # conformer level, which is the comparison the paper is making.
        function_definition_list += ["normalization", "sorf"]
        parameter_list += [{}, {"nfeature_stacks": 1, "ntransforms": ntransforms}]

    model = MultilevelSORFModel(
        function_definition_list,
        parameter_list,
        # The quantities are shifted either way now; `simple_shifts` selects HOW the shift
        # is optimized -- fitted directly to the training quantities when True, or against
        # the model's leave-one-out errors when False.
        intensive_quantity_shift=True,
        extensive_quantity_shift=False,
        simple_quantity_shift=simple_shifts,
    )

    training_set_sizes = [50, 100, 200, 400, training_set_size]

    # nperturbations = 4
    # initial_guess_perturbations = (
    #    np.random.random((nperturbations, model.get_nhyperparameters())) - 0.5
    # )
    # initial_guess_perturbations[0, :] = 0.0
    # initial_guess_perturbations = None

    # smallest_training_set_size = training_set_sizes[0]
    # model.assign_training_set(
    # training_slater_pairs[:smallest_training_set_size],
    #    training_quantities[:smallest_training_set_size],
    #    init_thread_assignments=True,
    # )
    # print(">>>started hyperparameter optimization:", now())
    # model.optimize_hyperparameters(initial_guess_perturbations=initial_guess_perturbations)
    # print(">>>finished hyperparameter optimization:", now())

    if scaffold_mode is not None:
        print(">>>started group-based hyperparameter optimization:", now())
        model.assign_training_set(
            training_slater_pairs,
            training_quantities,
            training_group_ids=training_group_ids,
        )
        model.optimize_hyperparameters()
        print(">>>finished group-based hyperparameter optimization:", now())
        model.fit(
            training_slater_pairs,
            training_quantities,
        )
        predictions = model.get_all_predictions(test_slater_pairs)
        errors = predictions - test_quantities
        # Names the run inside the file: collating one number per job across modes, seeds and
        # methods is otherwise guesswork about which directory it came from. The seed is
        # recorded even for the deterministic mode, where it does not enter the split, so that
        # every file has the same fields.
        run_description = (
            f"mode={scaffold_mode} seed={seed} simple_shifts={simple_shifts}"
            f" acyclic={SCAFFOLD_ACYCLIC} include_chirality={SCAFFOLD_INCLUDE_CHIRALITY}"
            f" train={training_set_size} test={len(test_quantities)}"
        )
        for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
            value = float(loss(errors))
            print(f"{loss_name}: {value}")
            with open(f"scaffold_split_{loss_name}.txt", "w") as error_file:
                print(f"# {loss_name} {run_description}", file=error_file)
                print(value, file=error_file)

        # Per-molecule predictions AND references, so the split can be re-analysed (per-scaffold
        # errors, the worst offenders, a parity plot) without rerunning the fit and without a
        # second lookup into the dataset. Keyed by SMILES rather than by index because the index
        # only means something relative to this split's ordering, which the scaffold modes
        # permute; the two maps therefore share their keys.
        test_SMILES = all_SMILES[training_set_size:]
        assert len(test_SMILES) == len(predictions)
        assert len(set(test_SMILES)) == len(test_SMILES), "SMILES keys must be unique"
        predictions_file = "scaffold_split_predictions.json"
        with open(predictions_file, "w") as json_file:
            json.dump(
                {
                    "description": run_description,
                    "predictions": {
                        SMILES: float(value) for SMILES, value in zip(test_SMILES, predictions)
                    },
                    "references": {
                        SMILES: float(value) for SMILES, value in zip(test_SMILES, test_quantities)
                    },
                },
                json_file,
                indent=2,
                sort_keys=True,
            )
        print(f"PREDICTIONS: {predictions_file} ({len(test_SMILES)} molecules)")
        return

    print(">>>started learning curve building:", now())
    all_predictions = model.learning_curve_predictions(
        training_slater_pairs,
        training_quantities,
        test_slater_pairs,
        training_set_sizes,
        max_subset_num=1,
        hyperparameter_reoptimization=True,
        init_thread_assignments=True,
        rng=random,
    )
    print(">>>finished learning curve building:", now())

    dump_test_predictions(
        "test_predictions.json",
        test_SMILES,
        test_quantities,
        all_predictions,
        training_set_sizes,
        method_str,
        baselines=test_baselines,
    )

    for loss, loss_name in [(MAE(), "MAE"), (RMSE(), "RMSE")]:
        mean_MAEs, _ = learning_curve_from_predictions(
            all_predictions, test_quantities, error_loss_function=loss
        )
        with open(f"learning_curve_{loss_name}.txt", "w") as f:
            for ntr, mean_MAE_val in zip(training_set_sizes, mean_MAEs):
                print(ntr, mean_MAE_val, file=f)


if __name__ == "__main__":
    main()
