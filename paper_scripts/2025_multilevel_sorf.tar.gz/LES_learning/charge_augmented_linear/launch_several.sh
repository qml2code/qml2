#!/bin/bash
# Learning curves for FCHL19/aSLATM augmented with GFN2 atomic charges -- LINEAR variant.
#
# "linear" is in every job name because that is the single thing this batch varies against
# charge_augmented/: there, the determinant difference and the conformer average were each
# followed by a `sorf`, i.e. a Gaussian kernel taken at that level. Here neither is, so above the
# per-atom SORF the model is linear in its features. The stack is
#
#   resize / rescaling / unscaled_sorf / element_id_switch / component_sum(atoms)
#   / calculate_representation / weighted_component_sum(determinant signs)
#   / weighted_component_sum(Boltzmann weights) / component_sum(conformer generations)
#
# unscaled_sorf rather than sorf, there and everywhere after a `rescaling`: `sorf` is a
# full_rescaling wrapped around unscaled_sorf, so it carries a sigma of its own, and `rescaling`
# has already given each region one. Only the product reaches the transform, so the second sigma
# is an exactly flat direction in hyperparameter space. See qml2/multilevel_sorf/AGENTS.md.
#
# No single-determinant axis: this variant is double-determinant throughout, and FJD_sdet is where
# one state is studied. --min_conf is still implemented in the script but not launched here -- that
# axis asks what the ensemble buys over its best conformer, which is not what this batch is about.
#
# Four axes, 72 jobs:
#   representation   FCHL19, aSLATM                      (job name)
#   shift            simple, hyperparam                  (job name + directory)
#   delta-ML         off, on                             (job name + directory)
#   split            random learning curve, rfo, fo      (job name + directory)
#
# One number for both the cores and the threads. --CPUs doubles as a MEMORY request on this node
# (CR_Core_Memory, DefMemPerCPU=MaxMemPerCPU=2681), so 16 buys 42 GB and whatever is asked for is
# also what OpenMP gets. Both representations ask for 16: the representation is computed INSIDE
# the parallel loop by multilevel_sorf's calculate_representation level and never stored, which is
# what made aSLATM's old 80-core (210 GB) request unnecessary.

compute_threads=16

script=charge_augmented_linear_LES_full.py

# The deterministic scaffold split does not depend on the seed, so it is submitted on this seed's
# pass only. The other axes still apply to it, which is why it is guarded inside the loops rather
# than hoisted out of them.
fo_seed=274658

for seed in 274658 20786 109790 478390
do
	for rep_name in "FCHL19" "aSLATM"
	do
		if [ "$rep_name" == "aSLATM" ]
		then
			rep_flag=--aslatm
		else
			rep_flag=
		fi

		# Both shift modes, which is the axis this batch adds. The quantities are shifted
		# either way: the positional argument selects HOW the coefficients over the shift
		# basis are optimized.
		#
		# "simple" fits them directly to the training quantities, once, independently of
		# the kernel. "hyperparam" re-optimizes them inside every loss evaluation, for the
		# sigmas being tried -- so the shift is part of what the hyperparameter search
		# explores, which is what the name says.
		#
		# NOT called "loo": which cross-validation that branch uses follows the split.
		# Without group ids it is leave-one-out (error_matrices_for_shifts); the scaffold
		# runs below assign training_group_ids, so theirs is leave-one-GROUP-out
		# (group_error_matrices_for_shifts). Five of every nine jobs here are the latter.
		for shift_name in "simple" "hyperparam"
		do
			if [ "$shift_name" == "simple" ]
			then
				shift_arg=True
			else
				shift_arg=False
			fi

			for dml_name in "" "dml"
			do
				if [ "$dml_name" == "dml" ]
				then
					dml_flag=--delta-ml
					dml_part=_dml
				else
					dml_flag=
					dml_part=
				fi

				tag=${rep_name}_charges_linear_${shift_name}_shifts${dml_part}

				# 1. Random split, the learning curve.
				dir=${shift_name}_shifts${dml_part}
				mkdir -p "$dir"
				cd "$dir"
				spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
					../$script "${tag}_LES_$seed" \
					$rep_flag $dml_flag $seed $shift_arg
				cd ../

				# 2. Randomized frequency-ordered scaffold split: same 80/20 grouping as
				#    below, with same-size groups shuffled by the seed, so it varies with
				#    the seed the way the learning curve does.
				dir=${shift_name}_shifts${dml_part}_rfo_scaffold
				mkdir -p "$dir"
				cd "$dir"
				spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
					../$script "${tag}_rfo_scaffold_LES_$seed" \
					$rep_flag $dml_flag --rfo_scaffold $seed $shift_arg
				cd ../

				# 3. Deterministic frequency-ordered scaffold split: the reference point
				#    comparable with the scaffold-split literature. Seed-independent, so
				#    it is submitted once and carries no seed in its name.
				if [ "$seed" == "$fo_seed" ]
				then
					dir=${shift_name}_shifts${dml_part}_fo_scaffold
					mkdir -p "$dir"
					cd "$dir"
					spython --CPUs=$compute_threads --OMP_NUM_THREADS=$compute_threads \
						../$script "${tag}_fo_scaffold_LES" \
						$rep_flag $dml_flag --fo_scaffold $fo_seed $shift_arg
					cd ../
				fi
			done
		done
	done
done
